import "dotenv/config";
import { readFileSync } from "fs";
import { join } from "path";
import { getDb } from "../api/queries/connection";
import { storage } from "../api/lib/storage";
import {
  agendas,
  banners,
  documents,
  galleryItems,
  news,
  pages,
  settings,
} from "./schema";

const ASSETS = join(process.cwd(), "seed-assets");

async function upload(local: string, dest: string, contentType: string) {
  const bytes = new Uint8Array(readFileSync(join(ASSETS, local)));
  const saved = await storage.uploadFile({
    fileContent: bytes,
    fileName: dest,
    contentType,
  });
  console.log("uploaded", dest, "->", saved.key);
  return saved.key;
}

async function setSetting(db: ReturnType<typeof getDb>, key: string, value: unknown) {
  const v = JSON.stringify(value);
  await db
    .insert(settings)
    .values({ key, value: v })
    .onDuplicateKeyUpdate({ set: { value: v } });
}

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  const existing = await db.query.news.findFirst();
  if (existing) {
    console.log("Database already seeded, skipping.");
    process.exit(0);
  }

  // ---------- Upload aset ----------
  const heroTambora = await upload("hero-tambora.png", "assets/hero-tambora.jpg", "image/jpeg");
  const heroOffice = await upload("hero-office.png", "assets/hero-office.jpg", "image/jpeg");
  const inspektur = await upload("inspektur.png", "assets/inspektur.jpg", "image/jpeg");
  const newsRapat = await upload("news-rapat.png", "assets/news-rapat.jpg", "image/jpeg");
  const newsAudit = await upload("news-audit.png", "assets/news-audit.jpg", "image/jpeg");
  const newsBimtek = await upload("news-bimtek.png", "assets/news-bimtek.jpg", "image/jpeg");
  const newsLapangan = await upload("news-lapangan.png", "assets/news-lapangan.jpg", "image/jpeg");
  let heroService: string | null = null;
  try {
    heroService = await upload("hero-service.png", "assets/hero-service.jpg", "image/jpeg");
  } catch {
    console.log("hero-service belum tersedia, lewati");
  }

  const docFiles: Record<string, string> = {
    "lakip-2025.pdf": "",
    "perjanjian-kinerja-2026.pdf": "",
    "renstra-2021-2026.pdf": "",
    "spi-informasi.pdf": "",
    "formulir-permohonan-informasi.pdf": "",
    "sop-pengaduan.pdf": "",
  };
  for (const f of Object.keys(docFiles)) {
    docFiles[f] = await upload(`docs/${f}`, `dokumen/${f}`, "application/pdf");
  }

  // ---------- Settings ----------
  await setSetting(db, "site", {
    name: "INSPEKTORAT KABUPATEN DOMPU",
    tagline: "Profesional, Integritas, Akuntabilitas",
    primaryColor: "#22264B",
    accentColor: "#C9962E",
    surfaceColor: "#F7F4EC",
    theme: "light",
  });
  await setSetting(db, "sambutan", {
    name: "M. Ichwan Surya, S.STP., M.AP.",
    position: "Inspektur Kabupaten Dompu",
    photoKey: inspektur,
    text: "Assalamu'alaikum warahmatullahi wabarakatuh. Selamat datang di laman resmi Inspektorat Kabupaten Dompu. Laman ini kami hadirkan sebagai wujud komitmen dalam membangun tata kelola pemerintahan daerah yang bersih, akuntabel, dan berintegritas.\n\nMelalui laman ini, masyarakat dapat mengakses informasi pengawasan, menyampaikan pengaduan, serta melaporkan dugaan pelanggaran melalui Whistleblowing System secara aman dan terlindungi. Kami berharap partisipasi aktif seluruh masyarakat Kabupaten Dompu dalam mengawal penyelenggaraan pemerintahan yang baik.",
  });
  await setSetting(db, "kontak", {
    address: "Jl. Soekarno Hatta, Kelurahan Karijawa, Kecamatan Dompu, Kabupaten Dompu, Nusa Tenggara Barat 84211",
    phone: "(0373) 21001",
    email: "inspektorat@dompukab.go.id",
    mapsQuery: "Kantor Bupati Dompu",
    facebook: "https://facebook.com",
    instagram: "https://instagram.com",
    youtube: "https://youtube.com",
  });
  await setSetting(db, "footer", {
    text: "Inspektorat Kabupaten Dompu merupakan Aparat Pengawasan Intern Pemerintah (APIP) yang bertugas melakukan pengawasan intern atas penyelenggaraan pemerintahan daerah di Kabupaten Dompu.",
  });
  await setSetting(db, "struktur", {
    nodes: [
      { id: "inspektur", label: "Inspektur", parent: null },
      { id: "sekretariat", label: "Sekretariat", parent: "inspektur" },
      { id: "irban1", label: "Inspektur Pembantu Wilayah I", parent: "inspektur" },
      { id: "irban2", label: "Inspektur Pembantu Wilayah II", parent: "inspektur" },
      { id: "irban3", label: "Inspektur Pembantu Wilayah III", parent: "inspektur" },
      { id: "jft", label: "Kelompok Jabatan Fungsional", parent: "inspektur" },
    ],
  });

  // ---------- Banners ----------
  await db.insert(banners).values([
    {
      title: "Mewujudkan Tata Kelola Pemerintahan Daerah yang Bersih, Akuntabel dan Berintegritas",
      description: "Inspektorat Kabupaten Dompu berkomitmen mengawal penyelenggaraan pemerintahan yang transparan dan bertanggung jawab.",
      imageKey: heroTambora,
      ctaText: "SELENGKAPNYA",
      ctaLink: "/profil",
      sortOrder: 1,
      active: true,
    },
    {
      title: "Laporkan Dugaan Pelanggaran Melalui Whistleblowing System",
      description: "Saluran pelaporan yang aman, rahasia, dan terlindungi bagi masyarakat dan aparatur.",
      imageKey: heroOffice,
      ctaText: "LAPORKAN DUGAAN PELANGGARAN",
      ctaLink: "/wbs/lapor",
      sortOrder: 2,
      active: true,
    },
    ...(heroService
      ? [
          {
            title: "Pelayanan Informasi Publik yang Transparan",
            description: "Akses dokumen publik, laporan pengawasan, dan informasi kinerja Inspektorat Kabupaten Dompu.",
            imageKey: heroService,
            ctaText: "INFORMASI PUBLIK",
            ctaLink: "/informasi-publik",
            sortOrder: 3,
            active: true,
          },
        ]
      : []),
  ]);

  // ---------- Berita ----------
  const now = Date.now();
  const day = 86400000;
  await db.insert(news).values([
    {
      title: "Inspektorat Kabupaten Dompu Tingkatkan Pengawasan Penyelenggaraan Pemerintahan Daerah",
      slug: "inspektorat-dompu-tingkatkan-pengawasan",
      excerpt: "Inspektorat Kabupaten Dompu memperkuat peran pengawasan intern melalui audit, reviu, dan pendampingan bagi seluruh perangkat daerah.",
      content: "DOMPU — Inspektorat Kabupaten Dompu terus memperkuat peran pengawasan intern atas penyelenggaraan pemerintahan daerah. Melalui program audit, reviu, evaluasi, serta pendampingan, Inspektorat memastikan setiap perangkat daerah menjalankan tugas dan fungsinya sesuai ketentuan peraturan perundang-undangan.\n\nInspektur Kabupaten Dompu menyampaikan bahwa pengawasan intern bukan sekadar mencari kesalahan, melainkan memberikan nilai tambah bagi perbaikan tata kelola. \"Kami hadir sebagai mitra strategis perangkat daerah untuk mewujudkan pemerintahan yang bersih dan akuntabel,\" ujarnya.\n\nPada tahun anggaran berjalan, Inspektorat telah menyelesaikan sejumlah penugasan pengawasan terhadap organisasi perangkat daerah (OPD) dengan fokus pada pengelolaan keuangan, pengadaan barang dan jasa, serta pelayanan publik.",
      category: "Pengawasan",
      imageKey: newsRapat,
      author: "Humas Inspektorat",
      featured: true,
      views: 128,
      publishedAt: new Date(now - 1 * day),
    },
    {
      title: "Rapat Koordinasi Pengawasan Intern Pemerintah Kabupaten Dompu Tahun 2026",
      slug: "rakor-pengawasan-intern-2026",
      excerpt: "Rakor pengawasan intern membahas Program Kerja Pengawasan Tahunan (PKPT) dan penguatan kapabilitas APIP.",
      content: "DOMPU — Inspektorat Kabupaten Dompu menggelar Rapat Koordinasi Pengawasan Intern yang diikuti seluruh pejabat struktural dan auditor. Rapat membahas penyusunan Program Kerja Pengawasan Tahunan (PKPT), pemetaan risiko perangkat daerah, serta rencana peningkatan kapabilitas APIP.\n\nDalam arahannya, Inspektur menekankan pentingnya pengawasan berbasis risiko agar sumber daya pengawasan difokuskan pada area yang paling rentan terhadap penyimpangan.",
      category: "Kegiatan",
      imageKey: newsRapat,
      author: "Humas Inspektorat",
      featured: false,
      views: 86,
      publishedAt: new Date(now - 4 * day),
    },
    {
      title: "Tim Auditor Lakukan Pemeriksaan Dokumen Keuangan Perangkat Daerah",
      slug: "pemeriksaan-dokumen-keuangan-opd",
      excerpt: "Pemeriksaan reguler atas laporan keuangan perangkat daerah untuk memastikan akuntabilitas pengelolaan keuangan daerah.",
      content: "DOMPU — Tim auditor Inspektorat Kabupaten Dompu melaksanakan pemeriksaan atas dokumen pertanggungjawaban keuangan sejumlah perangkat daerah. Pemeriksaan dilakukan untuk memastikan kesesuaian pengelolaan keuangan dengan ketentuan yang berlaku.\n\nHasil pemeriksaan akan dituangkan dalam Laporan Hasil Pengawasan dan ditindaklanjuti melalui pemantauan tindak lanjut rekomendasi.",
      category: "Pengawasan",
      imageKey: newsAudit,
      author: "Humas Inspektorat",
      featured: false,
      views: 64,
      publishedAt: new Date(now - 8 * day),
    },
    {
      title: "Bimtek Peningkatan Kompetensi Auditor dan P2UPD Kabupaten Dompu",
      slug: "bimtek-kompetensi-auditor-2026",
      excerpt: "Bimbingan teknis bagi auditor dan petugas pengawasan penyelenggaraan urusan pemerintahan di daerah.",
      content: "DOMPU — Inspektorat Kabupaten Dompu menyelenggarakan bimbingan teknis peningkatan kompetensi auditor dan P2UPD. Kegiatan ini bertujuan meningkatkan kapasitas sumber daya manusia pengawasan dalam melaksanakan audit dan pengawasan penyelenggaraan urusan pemerintahan di daerah.\n\nMateri bimtek meliputi teknik audit terkini, pengendalian intern, serta pencegahan fraud dalam pengelolaan keuangan daerah.",
      category: "Pelatihan",
      imageKey: newsBimtek,
      author: "Humas Inspektorat",
      featured: false,
      views: 52,
      publishedAt: new Date(now - 12 * day),
    },
    {
      title: "Monitoring Lapangan: Inspektorat Tinjau Proyek Infrastruktur Desa",
      slug: "monitoring-proyek-infrastruktur-desa",
      excerpt: "Tim Inspektorat melakukan monitoring dan evaluasi pelaksanaan proyek infrastruktur di sejumlah desa.",
      content: "DOMPU — Inspektorat Kabupaten Dompu melaksanakan monitoring dan evaluasi terhadap pelaksanaan proyek infrastruktur desa. Kegiatan ini bertujuan memastikan pembangunan berjalan sesuai spesifikasi, tepat mutu, dan tepat waktu.\n\nTemuan di lapangan akan ditindaklanjuti dengan rekomendasi perbaikan kepada perangkat daerah terkait.",
      category: "Pengawasan",
      imageKey: newsLapangan,
      author: "Humas Inspektorat",
      featured: false,
      views: 47,
      publishedAt: new Date(now - 16 * day),
    },
    {
      title: "Pengumuman: Jadwal Layanan Permohonan Informasi Publik PPID Inspektorat",
      slug: "jadwal-layanan-ppid-inspektorat",
      excerpt: "Layanan permohonan informasi publik PPID Inspektorat Kabupaten Dompu dilayani setiap hari kerja pukul 08.00–15.00 WITA.",
      content: "DOMPU — Pejabat Pengelola Informasi dan Dokumentasi (PPID) Inspektorat Kabupaten Dompu melayani permohonan informasi publik setiap hari kerja, Senin sampai Jumat pukul 08.00–15.00 WITA.\n\nPemohon dapat mengajukan permohonan secara langsung dengan mengisi formulir permohonan informasi, atau melalui laman resmi pada menu Informasi Publik.",
      category: "Pengumuman",
      imageKey: heroOffice,
      author: "PPID Inspektorat",
      featured: false,
      views: 39,
      publishedAt: new Date(now - 20 * day),
    },
  ]);

  // ---------- Agenda ----------
  const fmt = (d: Date) => d.toISOString().slice(0, 10);
  await db.insert(agendas).values([
    {
      title: "Rapat Koordinasi Pengawasan Intern Pemerintah Kabupaten Dompu",
      eventDate: fmt(new Date(now + 5 * day)),
      eventTime: "09.00 - 12.00 WITA",
      location: "Aula Inspektorat Kabupaten Dompu",
      description: "Koordinasi penyusunan PKPT dan evaluasi tindak lanjut hasil pengawasan.",
    },
    {
      title: "Entry Meeting Audit Reguler OPD Tahap II",
      eventDate: fmt(new Date(now + 9 * day)),
      eventTime: "08.30 WITA",
      location: "Kantor Dinas Pendidikan dan Kebudayaan",
      description: "Pembukaan penugasan audit reguler terhadap perangkat daerah tahap kedua.",
    },
    {
      title: "Sosialisasi Whistleblowing System kepada Perangkat Daerah",
      eventDate: fmt(new Date(now + 14 * day)),
      eventTime: "10.00 - 12.00 WITA",
      location: "Gedung Serba Guna Kabupaten Dompu",
      description: "Sosialisasi mekanisme pelaporan dugaan pelanggaran melalui WBS.",
    },
    {
      title: "Pemantauan Tindak Lanjut Rekomendasi Hasil Pemeriksaan BPK",
      eventDate: fmt(new Date(now + 21 * day)),
      eventTime: "09.00 WITA",
      location: "Ruang Rapat Inspektorat",
      description: "Pemantauan progres penyelesaian tindak lanjut rekomendasi BPK oleh perangkat daerah.",
    },
  ]);

  // ---------- Dokumen ----------
  const docRows = [
    { title: "Laporan Kinerja (LAKIP) Inspektorat Kabupaten Dompu Tahun 2025", section: "publikasi" as const, category: "Publikasi Kinerja", file: "lakip-2025.pdf", days: 30 },
    { title: "Perjanjian Kinerja Inspektorat Kabupaten Dompu Tahun 2026", section: "publikasi" as const, category: "Publikasi Kinerja", file: "perjanjian-kinerja-2026.pdf", days: 25 },
    { title: "Rencana Strategis (Renstra) Inspektorat Kabupaten Dompu 2021-2026", section: "publikasi" as const, category: "Laporan", file: "renstra-2021-2026.pdf", days: 60 },
    { title: "SOP Penanganan Pengaduan dalam Whistleblowing System", section: "publikasi" as const, category: "SOP", file: "sop-pengaduan.pdf", days: 45 },
    { title: "Standar Pelayanan Informasi PPID Inspektorat Kabupaten Dompu", section: "informasi_publik" as const, category: "Standar Pelayanan Informasi", file: "spi-informasi.pdf", days: 40 },
    { title: "Profil Inspektorat Kabupaten Dompu", section: "informasi_publik" as const, category: "Informasi Berkala", file: "renstra-2021-2026.pdf", days: 50 },
    { title: "Formulir Permohonan Informasi Publik", section: "download" as const, category: "Formulir", file: "formulir-permohonan-informasi.pdf", days: 35 },
    { title: "SOP Penanganan Pengaduan (WBS)", section: "download" as const, category: "SOP", file: "sop-pengaduan.pdf", days: 45 },
    { title: "Laporan Kinerja Inspektorat 2025", section: "download" as const, category: "Laporan", file: "lakip-2025.pdf", days: 30 },
  ];
  await db.insert(documents).values(
    docRows.map((d) => ({
      title: d.title,
      description: `${d.title} — diterbitkan oleh Inspektorat Kabupaten Dompu.`,
      section: d.section,
      category: d.category,
      fileKey: docFiles[d.file],
      fileName: d.file,
      fileType: "application/pdf",
      fileSize: 250000,
      publishedAt: new Date(now - d.days * day),
    })),
  );

  // ---------- Galeri ----------
  const gallerySeed = [
    { title: "Panorama Gunung Tambora, Kabupaten Dompu", file: heroTambora, album: "Kabupaten Dompu" },
    { title: "Kantor Pemerintah Kabupaten Dompu", file: heroOffice, album: "Fasilitas" },
    { title: "Rapat Koordinasi Pengawasan Intern", file: newsRapat, album: "Kegiatan" },
    { title: "Pemeriksaan Dokumen Keuangan OPD", file: newsAudit, album: "Kegiatan" },
    { title: "Bimtek Peningkatan Kompetensi Auditor", file: newsBimtek, album: "Pelatihan" },
    { title: "Monitoring Proyek Infrastruktur Desa", file: newsLapangan, album: "Pengawasan" },
    ...(heroService ? [{ title: "Pelayanan Publik Kabupaten Dompu", file: heroService, album: "Pelayanan" }] : []),
  ];
  await db.insert(galleryItems).values(
    gallerySeed.map((g) => ({ type: "photo" as const, title: g.title, album: g.album, fileKey: g.file })),
  );

  // ---------- Halaman ----------
  const pageRows: { slug: string; title: string; content: string }[] = [
    {
      slug: "tentang",
      title: "Tentang Inspektorat",
      content:
        "Inspektorat Kabupaten Dompu adalah Aparat Pengawasan Intern Pemerintah (APIP) yang berada di bawah dan bertanggung jawab kepada Bupati Dompu. Inspektorat dipimpin oleh seorang Inspektur dan bertugas melakukan pengawasan intern atas penyelenggaraan pemerintahan daerah.\n\n## Kedudukan\nInspektorat Kabupaten Dompu merupakan unsur pengawas penyelenggaraan pemerintahan daerah yang berkedudukan di bawah dan bertanggung jawab kepada Bupati melalui Sekretaris Daerah dalam hal administrasi.\n\n## Wilayah Kerja\nWilayah kerja Inspektorat Kabupaten Dompu meliputi seluruh perangkat daerah di lingkungan Pemerintah Kabupaten Dompu, meliputi sekretariat daerah, sekretariat DPRD, dinas, badan, kecamatan, dan kelurahan.",
    },
    {
      slug: "sejarah",
      title: "Sejarah Inspektorat",
      content:
        "Inspektorat Kabupaten Dompu dibentuk berdasarkan peraturan perundang-undangan tentang pembentukan organisasi perangkat daerah Kabupaten Dompu. Sejak dibentuk, Inspektorat menjalankan fungsi pengawasan intern untuk memastikan penyelenggaraan pemerintahan daerah berjalan sesuai prinsip tata kelola yang baik.\n\nSeiring perkembangan regulasi, pengawasan intern diperkuat melalui Peraturan Pemerintah Nomor 12 Tahun 2017 tentang Pembinaan dan Pengawasan Penyelenggaraan Pemerintahan Daerah serta Peraturan Pemerintah Nomor 60 Tahun 2008 tentang Sistem Pengendalian Intern Pemerintah (SPIP).",
    },
    {
      slug: "tugas-fungsi",
      title: "Tugas dan Fungsi",
      content:
        "## Tugas\nInspektorat mempunyai tugas membantu Bupati membina dan mengawasi pelaksanaan urusan pemerintahan yang menjadi kewenangan daerah dan tugas pembantuan oleh perangkat daerah.\n\n## Fungsi\n- Perumusan kebijakan teknis bidang pengawasan dan pengelolaan pengaduan masyarakat;\n- Pelaksanaan pengawasan intern terhadap kinerja dan keuangan melalui audit, reviu, evaluasi, pemantauan, dan kegiatan pengawasan lainnya;\n- Pelaksanaan pengawasan untuk tujuan tertentu atas penugasan Bupati;\n- Penyusunan laporan hasil pengawasan;\n- Pelaksanaan administrasi Inspektorat; dan\n- Pelaksanaan fungsi lain yang diberikan oleh Bupati terkait tugas dan fungsinya.",
    },
    {
      slug: "visi-misi",
      title: "Visi dan Misi",
      content:
        "## Visi\nTerwujudnya Inspektorat yang profesional, berintegritas, dan akuntabel dalam mengawal tata kelola pemerintahan daerah yang bersih.\n\n## Misi\n- Meningkatkan kualitas pengawasan intern atas penyelenggaraan pemerintahan daerah;\n- Meningkatkan kapabilitas dan profesionalisme aparatur pengawasan;\n- Mendorong terwujudnya pengendalian intern yang efektif di seluruh perangkat daerah;\n- Menyediakan sarana pengaduan masyarakat dan whistleblowing system yang aman dan terpercaya.",
    },
    {
      slug: "maklumat",
      title: "Maklumat Pelayanan",
      content:
        "Dengan ini kami menyatakan sanggup menyelenggarakan pelayanan sesuai standar pelayanan yang telah ditetapkan, dan apabila tidak menepati janji ini, kami siap menerima sanksi sesuai peraturan perundang-undangan yang berlaku.\n\n## Komitmen Kami\n- Memberikan pelayanan pengawasan dan informasi secara profesional dan transparan;\n- Menjaga kerahasiaan identitas pelapor sesuai ketentuan;\n- Menindaklanjuti setiap laporan sesuai prosedur dan kewenangan;\n- Tidak memungut biaya dalam bentuk apa pun atas pelayanan pengaduan.",
    },
    {
      slug: "pengawasan",
      title: "Pengawasan",
      content:
        "Inspektorat Kabupaten Dompu melaksanakan pengawasan intern atas penyelenggaraan pemerintahan daerah melalui berbagai bentuk pengawasan.\n\n## Bentuk Pengawasan\n- Audit: pemeriksaan atas laporan keuangan dan kinerja perangkat daerah;\n- Reviu: penelaahan bukti untuk memberikan keyakinan terbatas;\n- Evaluasi: penilaian atas hasil kebijakan dan program;\n- Pemantauan: pengamatan atas pelaksanaan kegiatan dan tindak lanjut rekomendasi;\n- Pendampingan: asistensi kepada perangkat daerah dalam penerapan SPIP dan tata kelola yang baik.\n\n## Program Kerja Pengawasan\nProgram kerja pengawasan tahunan disusun berbasis risiko dan ditetapkan dalam Program Kerja Pengawasan Tahunan (PKPT).",
    },
    {
      slug: "pengaduan-info",
      title: "Pengaduan Masyarakat",
      content:
        "Masyarakat dapat menyalurkan pengaduan terkait penyelenggaraan pemerintahan daerah di Kabupaten Dompu melalui formulir pengaduan pada laman ini.\n\nSetiap pengaduan akan diberikan nomor tiket dan ditelaah oleh petugas. Untuk laporan dugaan pelanggaran seperti korupsi, gratifikasi, atau penyalahgunaan wewenang, gunakan Whistleblowing System agar identitas pelapor mendapatkan perlindungan kerahasiaan.",
    },
    {
      slug: "wbs-privasi",
      title: "Kebijakan Privasi Whistleblowing System",
      content:
        "## Penggunaan Data Pelapor\nData identitas pelapor hanya digunakan untuk keperluan klarifikasi dan penanganan laporan, serta tidak dibagikan kepada pihak yang tidak berwenang.\n\n## Kerahasiaan Identitas\nPelapor dapat memilih untuk merahasiakan identitasnya atau melapor secara anonim. Identitas pelapor yang memilih kerahasiaan hanya dapat diakses oleh pejabat yang memiliki hak akses.\n\n## Penggunaan Bukti\nBerkas bukti yang diunggah pelapor disimpan secara aman dan tidak ditampilkan kepada publik.\n\n## Hak Pelapor\nPelapor berhak mengetahui status penanganan laporannya melalui nomor registrasi dan kode pelapor.\n\n## Catatan Penting\nPerlindungan terhadap pelapor mengacu pada peraturan perundang-undangan yang berlaku. Kerahasiaan identitas dijaga sesuai mekanisme dan kewenangan yang dimiliki Inspektorat Kabupaten Dompu.",
    },
    {
      slug: "wbs-petunjuk",
      title: "Petunjuk Pelaporan WBS",
      content:
        "## Langkah Melaporkan\n- Klik tombol BUAT LAPORAN pada halaman Whistleblowing System;\n- Isi identitas pelapor atau pilih melapor secara anonim;\n- Isi informasi terlapor dan uraian kronologi dugaan pelanggaran secara jelas;\n- Unggah bukti pendukung jika ada (PDF, gambar, dokumen, atau arsip ZIP, maksimal 5 MB per berkas);\n- Simpan nomor registrasi dan kode pelapor yang ditampilkan setelah laporan terkirim.\n\n## Setelah Melapor\nGunakan nomor registrasi dan kode pelapor untuk memantau status penanganan laporan melalui menu Cek Status Laporan.",
    },
    {
      slug: "wbs-faq",
      title: "Pertanyaan Umum (FAQ) WBS",
      content:
        "## Apakah identitas saya aman?\nAnda dapat memilih opsi identitas dirahasiakan atau melapor secara anonim. Identitas tidak ditampilkan kepada publik.\n\n## Apa itu nomor registrasi dan kode pelapor?\nNomor registrasi adalah nomor unik laporan Anda, sedangkan kode pelapor adalah kode rahasia untuk mengecek status laporan. Simpan keduanya dengan baik.\n\n## Berapa lama laporan diproses?\nSetiap laporan melalui tahap verifikasi administratif dan telaah. Lama penanganan bergantung pada kompleksitas kasus dan kelengkapan bukti.\n\n## Bukti apa yang bisa diunggah?\nDokumen PDF, gambar (JPG/PNG), dokumen Word/Excel, atau arsip ZIP dengan ukuran maksimal 5 MB per berkas.",
    },
  ];
  await db.insert(pages).values(pageRows);

  console.log("Done.");
  process.exit(0);
}

seed().catch((e) => {
  console.error(e);
  process.exit(1);
});

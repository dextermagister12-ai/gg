import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  int,
  boolean,
  index,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin", "admin_wbs", "editor", "viewer"])
    .default("user")
    .notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ===================== CMS =====================

export const banners = mysqlTable("banners", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description"),
  imageKey: varchar("imageKey", { length: 512 }),
  ctaText: varchar("ctaText", { length: 120 }),
  ctaLink: varchar("ctaLink", { length: 500 }),
  sortOrder: int("sortOrder").default(0).notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Banner = typeof banners.$inferSelect;

export const news = mysqlTable(
  "news",
  {
    id: serial("id").primaryKey(),
    title: varchar("title", { length: 500 }).notNull(),
    slug: varchar("slug", { length: 500 }).notNull().unique(),
    excerpt: text("excerpt"),
    content: text("content"),
    category: varchar("category", { length: 120 }).default("Kegiatan").notNull(),
    imageKey: varchar("imageKey", { length: 512 }),
    author: varchar("author", { length: 255 }),
    featured: boolean("featured").default(false).notNull(),
    views: int("views").default(0).notNull(),
    publishedAt: timestamp("publishedAt").defaultNow().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (t) => ({
    catIdx: index("news_category_idx").on(t.category),
    pubIdx: index("news_published_idx").on(t.publishedAt),
  }),
);

export type News = typeof news.$inferSelect;

export const agendas = mysqlTable("agendas", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 500 }).notNull(),
  eventDate: varchar("eventDate", { length: 10 }).notNull(), // YYYY-MM-DD
  eventTime: varchar("eventTime", { length: 20 }),
  location: varchar("location", { length: 500 }),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Agenda = typeof agendas.$inferSelect;

export const documents = mysqlTable(
  "documents",
  {
    id: serial("id").primaryKey(),
    title: varchar("title", { length: 500 }).notNull(),
    description: text("description"),
    section: mysqlEnum("section", [
      "publikasi",
      "informasi_publik",
      "download",
    ])
      .default("publikasi")
      .notNull(),
    category: varchar("category", { length: 120 }).notNull(),
    fileKey: varchar("fileKey", { length: 512 }),
    fileName: varchar("fileName", { length: 500 }),
    fileType: varchar("fileType", { length: 120 }),
    fileSize: int("fileSize"),
    downloads: int("downloads").default(0).notNull(),
    publishedAt: timestamp("publishedAt").defaultNow().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => ({
    secIdx: index("doc_section_idx").on(t.section),
    catIdx: index("doc_category_idx").on(t.category),
  }),
);

export type Document = typeof documents.$inferSelect;

export const galleryItems = mysqlTable("gallery_items", {
  id: serial("id").primaryKey(),
  type: mysqlEnum("type", ["photo", "video"]).default("photo").notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  album: varchar("album", { length: 255 }).default("Umum").notNull(),
  fileKey: varchar("fileKey", { length: 512 }),
  videoUrl: varchar("videoUrl", { length: 1000 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GalleryItem = typeof galleryItems.$inferSelect;

export const pages = mysqlTable("pages", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  title: varchar("title", { length: 500 }).notNull(),
  content: text("content"),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Page = typeof pages.$inferSelect;

export const settings = mysqlTable("settings", {
  key: varchar("key", { length: 120 }).primaryKey(),
  value: text("value"),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export const complaints = mysqlTable("complaints", {
  id: serial("id").primaryKey(),
  ticket: varchar("ticket", { length: 40 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 40 }),
  subject: varchar("subject", { length: 500 }).notNull(),
  message: text("message"),
  status: mysqlEnum("status", ["baru", "diproses", "selesai"])
    .default("baru")
    .notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Complaint = typeof complaints.$inferSelect;

// ===================== WBS =====================

export const reportStatusEnum = mysqlEnum("status", [
  "diterima",
  "verifikasi",
  "telaah",
  "penanganan",
  "info_tambahan",
  "selesai",
  "ditutup",
]);

export const reports = mysqlTable(
  "reports",
  {
    id: serial("id").primaryKey(),
    registrationNumber: varchar("registrationNumber", { length: 40 })
      .notNull()
      .unique(),
    reporterTokenHash: varchar("reporterTokenHash", { length: 128 }),
    // Identitas pelapor (boleh kosong jika anonim)
    reporterName: varchar("reporterName", { length: 255 }),
    reporterNik: varchar("reporterNik", { length: 40 }),
    reporterEmail: varchar("reporterEmail", { length: 320 }),
    reporterPhone: varchar("reporterPhone", { length: 40 }),
    reporterAddress: text("reporterAddress"),
    anonymous: boolean("anonymous").default(false).notNull(),
    confidential: boolean("confidential").default(false).notNull(),
    // Terlapor
    reportedPerson: varchar("reportedPerson", { length: 255 }),
    reportedPosition: varchar("reportedPosition", { length: 255 }),
    reportedAgency: varchar("reportedAgency", { length: 255 }),
    reportedUnit: varchar("reportedUnit", { length: 255 }),
    // Detail pelanggaran
    violationType: varchar("violationType", { length: 120 }).notNull(),
    incidentDate: varchar("incidentDate", { length: 20 }),
    incidentLocation: varchar("incidentLocation", { length: 500 }),
    chronology: text("chronology"),
    partiesInvolved: text("partiesInvolved"),
    estimatedLoss: varchar("estimatedLoss", { length: 255 }),
    status: reportStatusEnum.default("diterima").notNull(),
    priority: mysqlEnum("priority", ["rendah", "normal", "tinggi"])
      .default("normal")
      .notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt")
      .defaultNow()
      .notNull()
      .$onUpdate(() => new Date()),
  },
  (t) => ({
    statusIdx: index("reports_status_idx").on(t.status),
    typeIdx: index("reports_type_idx").on(t.violationType),
    createdIdx: index("reports_created_idx").on(t.createdAt),
  }),
);

export type Report = typeof reports.$inferSelect;

export const reportAttachments = mysqlTable("report_attachments", {
  id: serial("id").primaryKey(),
  reportId: bigint("reportId", { mode: "number", unsigned: true }).notNull(),
  fileKey: varchar("fileKey", { length: 512 }).notNull(),
  fileName: varchar("fileName", { length: 500 }).notNull(),
  fileType: varchar("fileType", { length: 120 }),
  fileSize: int("fileSize"),
  uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
});

export type ReportAttachment = typeof reportAttachments.$inferSelect;

export const reportUpdates = mysqlTable("report_updates", {
  id: serial("id").primaryKey(),
  reportId: bigint("reportId", { mode: "number", unsigned: true }).notNull(),
  status: varchar("status", { length: 40 }).notNull(),
  notes: text("notes"),
  publicNote: text("publicNote"), // catatan yang boleh dilihat pelapor
  updatedBy: varchar("updatedBy", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ReportUpdate = typeof reportUpdates.$inferSelect;

export const auditLogs = mysqlTable(
  "audit_logs",
  {
    id: serial("id").primaryKey(),
    userId: bigint("userId", { mode: "number", unsigned: true }),
    userName: varchar("userName", { length: 255 }),
    action: varchar("action", { length: 255 }).notNull(),
    reportId: bigint("reportId", { mode: "number", unsigned: true }),
    ipAddress: varchar("ipAddress", { length: 64 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (t) => ({
    createdIdx: index("audit_created_idx").on(t.createdAt),
  }),
);

export type AuditLog = typeof auditLogs.$inferSelect;

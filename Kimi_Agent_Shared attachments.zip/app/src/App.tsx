import { useEffect } from "react";
import { Routes, Route, useLocation } from "react-router";
import { Toaster } from "sonner";
import PublicLayout from "./components/PublicLayout";
import Home from "./pages/Home";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import Profil from "./pages/Profil";
import InformasiPublik from "./pages/InformasiPublik";
import Pengawasan from "./pages/Pengawasan";
import Pengaduan from "./pages/Pengaduan";
import Wbs from "./pages/Wbs";
import WbsLapor from "./pages/WbsLapor";
import WbsStatus from "./pages/WbsStatus";
import Berita from "./pages/Berita";
import BeritaDetail from "./pages/BeritaDetail";
import Publikasi from "./pages/Publikasi";
import Galeri from "./pages/Galeri";
import Agenda from "./pages/Agenda";
import Kontak from "./pages/Kontak";
import Download from "./pages/Download";
import Cari from "./pages/Cari";
import AdminLayout from "./pages/admin/AdminLayout";
import AdminDashboard from "./pages/admin/Dashboard";
import { WbsList, WbsDetail } from "./pages/admin/Wbs";
import AdminBerita from "./pages/admin/Berita";
import AdminBanner from "./pages/admin/Banner";
import AdminAgenda from "./pages/admin/Agenda";
import AdminDokumen from "./pages/admin/Dokumen";
import AdminGaleri from "./pages/admin/Galeri";
import AdminHalaman from "./pages/admin/Halaman";
import AdminPengaduan from "./pages/admin/Pengaduan";
import { Pengguna, AuditLog, Pengaturan, Backup } from "./pages/admin/System";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [pathname]);
  return null;
}

export default function App() {
  return (
    <>
      <ScrollToTop />
      <Toaster richColors position="top-center" />
      <Routes>
        <Route element={<PublicLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/profil" element={<Profil />} />
          <Route path="/informasi-publik" element={<InformasiPublik />} />
          <Route path="/pengawasan" element={<Pengawasan />} />
          <Route path="/pengaduan" element={<Pengaduan />} />
          <Route path="/wbs" element={<Wbs />} />
          <Route path="/wbs/lapor" element={<WbsLapor />} />
          <Route path="/wbs/status" element={<WbsStatus />} />
          <Route path="/berita" element={<Berita />} />
          <Route path="/berita/:slug" element={<BeritaDetail />} />
          <Route path="/publikasi" element={<Publikasi />} />
          <Route path="/galeri" element={<Galeri />} />
          <Route path="/agenda" element={<Agenda />} />
          <Route path="/kontak" element={<Kontak />} />
          <Route path="/download" element={<Download />} />
          <Route path="/cari" element={<Cari />} />
        </Route>
        <Route path="/login" element={<Login />} />
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<AdminDashboard />} />
          <Route path="wbs" element={<WbsList />} />
          <Route path="wbs/:id" element={<WbsDetail />} />
          <Route path="berita" element={<AdminBerita />} />
          <Route path="banner" element={<AdminBanner />} />
          <Route path="agenda" element={<AdminAgenda />} />
          <Route path="dokumen" element={<AdminDokumen />} />
          <Route path="galeri" element={<AdminGaleri />} />
          <Route path="halaman" element={<AdminHalaman />} />
          <Route path="pengaduan" element={<AdminPengaduan />} />
          <Route path="pengguna" element={<Pengguna />} />
          <Route path="audit" element={<AuditLog />} />
          <Route path="pengaturan" element={<Pengaturan />} />
          <Route path="backup" element={<Backup />} />
        </Route>
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}

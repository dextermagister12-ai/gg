import { useState } from "react";
import { Image as ImageIcon, PlayCircle, X } from "lucide-react";
import PageHero from "@/components/PageHero";
import { trpc } from "@/providers/trpc";
import { useReveal } from "@/lib/site";

export default function Galeri() {
  const [tab, setTab] = useState<"photo" | "video">("photo");
  const [lightbox, setLightbox] = useState<{ url: string; title: string } | null>(null);
  useReveal();
  const items = trpc.cms.gallery.useQuery({ type: tab });

  return (
    <div>
      <PageHero title="Galeri" subtitle="Dokumentasi kegiatan Inspektorat Kabupaten Dompu." />
      <section className="py-12 lg:py-16">
        <div className="container-site">
          <div className="mb-8 flex gap-2">
            {(
              [
                { v: "photo", l: "Galeri Foto" },
                { v: "video", l: "Galeri Video" },
              ] as const
            ).map((t) => (
              <button
                key={t.v}
                onClick={() => setTab(t.v)}
                className={`min-h-[44px] rounded-full border px-6 text-sm font-semibold ${
                  tab === t.v ? "border-brand bg-brand text-white" : "bg-white text-brand hover:border-gold"
                }`}
              >
                {t.l}
              </button>
            ))}
          </div>

          {items.isLoading ? (
            <div className="columns-2 gap-4 sm:columns-3 lg:columns-4">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="mb-4 h-48 animate-pulse break-inside-avoid rounded-xl bg-muted" />
              ))}
            </div>
          ) : (items.data?.length ?? 0) === 0 ? (
            <div className="flex flex-col items-center gap-2 rounded-xl border bg-white p-12 text-center text-muted-foreground">
              <ImageIcon className="h-10 w-10 opacity-40" />
              <p className="text-sm">Belum ada {tab === "photo" ? "foto" : "video"}.</p>
            </div>
          ) : (
            <div className="columns-2 gap-4 sm:columns-3 lg:columns-4">
              {items.data?.map((g) => (
                <figure key={g.id} className="reveal group relative mb-4 break-inside-avoid overflow-hidden rounded-xl border bg-white shadow-sm">
                  {tab === "photo" ? (
                    <button
                      className="block w-full"
                      onClick={() => g.fileUrl && setLightbox({ url: g.fileUrl, title: g.title })}
                      aria-label={`Perbesar foto ${g.title}`}
                    >
                      {g.fileUrl ? (
                        <img src={g.fileUrl} alt={g.title} loading="lazy" className="w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                      ) : (
                        <div className="flex aspect-[4/3] items-center justify-center bg-muted">
                          <ImageIcon className="h-8 w-8 text-muted-foreground/40" />
                        </div>
                      )}
                    </button>
                  ) : (
                    <a href={g.videoUrl ?? "#"} target="_blank" rel="noreferrer" className="relative block">
                      {g.fileUrl ? (
                        <img src={g.fileUrl} alt={g.title} loading="lazy" className="w-full object-cover" />
                      ) : (
                        <div className="flex aspect-video items-center justify-center bg-brand/10">
                          <PlayCircle className="h-10 w-10 text-brand/40" />
                        </div>
                      )}
                      <span className="absolute inset-0 flex items-center justify-center bg-black/25">
                        <PlayCircle className="h-12 w-12 text-white drop-shadow" />
                      </span>
                    </a>
                  )}
                  <figcaption className="flex items-center justify-between gap-2 p-3">
                    <span className="line-clamp-1 text-xs font-semibold text-brand">{g.title}</span>
                    <span className="rounded-full bg-gold/15 px-2 py-0.5 text-[10px] font-medium text-gold">{g.album}</span>
                  </figcaption>
                </figure>
              ))}
            </div>
          )}
        </div>
      </section>

      {lightbox && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/85 p-4"
          onClick={() => setLightbox(null)}
          role="dialog"
          aria-label={lightbox.title}
        >
          <button className="absolute right-4 top-4 rounded-full bg-white/15 p-3 text-white min-h-[44px] min-w-[44px]" aria-label="Tutup">
            <X className="h-5 w-5" />
          </button>
          <img src={lightbox.url} alt={lightbox.title} className="max-h-[85vh] max-w-full rounded-lg object-contain" />
        </div>
      )}
    </div>
  );
}

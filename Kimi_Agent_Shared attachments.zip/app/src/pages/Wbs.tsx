import { Link } from "react-router";
import { ShieldAlert, FilePlus2, SearchCheck, BookOpen, HelpCircle, Lock } from "lucide-react";
import PageHero from "@/components/PageHero";
import { trpc } from "@/providers/trpc";
import { PageContent, useReveal } from "@/lib/site";

export default function Wbs() {
  useReveal();
  const petunjuk = trpc.cms.page.useQuery({ slug: "wbs-petunjuk" }, { staleTime: 60_000 });
  const faq = trpc.cms.page.useQuery({ slug: "wbs-faq" }, { staleTime: 60_000 });
  const privasi = trpc.cms.page.useQuery({ slug: "wbs-privasi" }, { staleTime: 60_000 });

  const ACTIONS = [
    { icon: FilePlus2, title: "Buat Laporan", desc: "Sampaikan laporan dugaan pelanggaran melalui formulir daring.", to: "/wbs/lapor", primary: true },
    { icon: SearchCheck, title: "Cek Status Laporan", desc: "Pantau perkembangan penanganan laporan dengan nomor registrasi.", to: "/wbs/status", primary: false },
    { icon: BookOpen, title: "Petunjuk Pelaporan", desc: "Pelajari tata cara melapor yang benar dan lengkap.", to: "#petunjuk", primary: false },
    { icon: HelpCircle, title: "FAQ", desc: "Pertanyaan yang sering diajukan seputar WBS.", to: "#faq", primary: false },
  ];

  return (
    <div>
      <PageHero
        title="Whistleblowing System"
        subtitle="Whistleblowing System merupakan sarana bagi masyarakat, pegawai, dan pihak lainnya untuk menyampaikan laporan mengenai dugaan pelanggaran atau penyimpangan yang terjadi di lingkungan Pemerintah Kabupaten Dompu."
      />

      <section className="py-12 lg:py-16">
        <div className="container-site">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {ACTIONS.map((a) => {
              const inner = (
                <div
                  className={`reveal flex h-full flex-col rounded-2xl border p-6 shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg ${
                    a.primary ? "border-gold bg-brand text-white" : "bg-white"
                  }`}
                >
                  <a.icon className={`h-9 w-9 ${a.primary ? "text-gold" : "text-gold"}`} />
                  <h2 className={`mt-4 font-display text-base font-extrabold uppercase tracking-wide ${a.primary ? "text-white" : "text-brand"}`}>
                    {a.title}
                  </h2>
                  <p className={`mt-2 text-sm ${a.primary ? "text-white/75" : "text-muted-foreground"}`}>{a.desc}</p>
                </div>
              );
              return a.to.startsWith("#") ? (
                <a key={a.title} href={a.to}>
                  {inner}
                </a>
              ) : (
                <Link key={a.title} to={a.to}>
                  {inner}
                </Link>
              );
            })}
          </div>

          <div className="reveal mt-8 flex items-start gap-3 rounded-xl border border-gold/50 bg-gold/10 p-5">
            <Lock className="mt-0.5 h-5 w-5 shrink-0 text-gold" />
            <p className="text-sm text-foreground/85">
              <strong>Perlindungan Pelapor.</strong> Anda dapat memilih untuk merahasiakan identitas atau melapor secara
              anonim. Identitas pelapor tidak ditampilkan kepada publik dan hanya dapat diakses oleh pejabat yang
              berwenang. Baca{" "}
              <a href="#privasi" className="font-semibold text-brand underline decoration-gold underline-offset-2">
                Kebijakan Privasi WBS
              </a>
              .
            </p>
          </div>

          <div id="petunjuk" className="mt-14 grid gap-8 lg:grid-cols-2">
            <div className="reveal rounded-2xl border bg-white p-6 shadow-sm lg:p-8">
              <h2 className="mb-5 font-display text-xl font-extrabold uppercase tracking-wide text-brand">
                Petunjuk Pelaporan
              </h2>
              <PageContent content={petunjuk.data?.content} />
            </div>
            <div id="faq" className="reveal rounded-2xl border bg-white p-6 shadow-sm lg:p-8">
              <h2 className="mb-5 font-display text-xl font-extrabold uppercase tracking-wide text-brand">
                Pertanyaan Umum (FAQ)
              </h2>
              <PageContent content={faq.data?.content} />
            </div>
          </div>

          <div id="privasi" className="reveal mt-8 rounded-2xl border bg-white p-6 shadow-sm lg:p-8">
            <h2 className="mb-5 font-display text-xl font-extrabold uppercase tracking-wide text-brand">
              Kebijakan Privasi Whistleblowing System
            </h2>
            <PageContent content={privasi.data?.content} />
          </div>

          <div className="mt-12 rounded-2xl bg-gradient-to-br from-brand to-brand-ink p-8 text-center text-white lg:p-12">
            <ShieldAlert className="mx-auto h-11 w-11 text-gold" />
            <h2 className="mt-4 font-display text-2xl font-extrabold uppercase tracking-wide">Siap Melaporkan?</h2>
            <p className="mx-auto mt-2 max-w-lg text-sm text-white/75">
              Laporan Anda sangat berarti untuk mewujudkan pemerintahan Kabupaten Dompu yang bersih dan berintegritas.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Link
                to="/wbs/lapor"
                className="inline-flex h-12 items-center rounded-md bg-gold px-8 font-bold uppercase tracking-wide text-white transition-colors hover:bg-[#a87c22]"
              >
                Buat Laporan
              </Link>
              <Link
                to="/wbs/status"
                className="inline-flex h-12 items-center rounded-md border-2 border-white/60 px-8 font-bold uppercase tracking-wide text-white transition-colors hover:bg-white hover:text-brand"
              >
                Cek Status Laporan
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

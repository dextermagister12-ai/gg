import { useState } from "react";
import { SearchCheck } from "lucide-react";
import PageHero from "@/components/PageHero";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatDateTime, formatDate } from "@/lib/site";
import { reportStatusLabel } from "@contracts/wbs";

export default function WbsStatus() {
  const [reg, setReg] = useState("");
  const [token, setToken] = useState("");
  const [query, setQuery] = useState<{ registrationNumber: string; token: string } | null>(null);

  const status = trpc.wbs.checkStatus.useQuery(query ?? { registrationNumber: "", token: "" }, {
    enabled: !!query,
    retry: false,
  });

  return (
    <div>
      <PageHero
        title="Cek Status Laporan"
        crumb={[{ label: "WBS", to: "/wbs" }]}
        subtitle="Masukkan nomor registrasi dan kode pelapor untuk memantau penanganan laporan Anda."
      />
      <section className="py-12 lg:py-16">
        <div className="container-site max-w-2xl">
          <form
            className="rounded-2xl border bg-white p-6 shadow-sm lg:p-8"
            onSubmit={(e) => {
              e.preventDefault();
              setQuery({ registrationNumber: reg.trim(), token: token.trim() });
            }}
          >
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="s-reg">Nomor Registrasi *</Label>
                <Input
                  id="s-reg"
                  required
                  value={reg}
                  onChange={(e) => setReg(e.target.value)}
                  placeholder="Contoh: WBS-DMP-2026-000001"
                  className="h-11 font-mono"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="s-token">Kode Pelapor *</Label>
                <Input
                  id="s-token"
                  required
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  placeholder="Kode rahasia yang diberikan saat melapor"
                  className="h-11 font-mono"
                />
              </div>
              <Button type="submit" className="h-11 w-full bg-brand text-white hover:bg-brand-ink" disabled={status.isFetching}>
                <SearchCheck className="mr-2 h-4 w-4" /> {status.isFetching ? "Memeriksa..." : "Periksa Status"}
              </Button>
            </div>
          </form>

          {status.isError && (
            <div className="mt-6 rounded-xl border border-destructive/40 bg-destructive/10 p-5 text-sm text-destructive">
              {status.error.message}
            </div>
          )}

          {status.data && (
            <div className="mt-8 rounded-2xl border bg-white p-6 shadow-sm lg:p-8 animate-fade-slide">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b pb-4">
                <div>
                  <div className="font-mono text-sm font-bold text-brand">{status.data.registrationNumber}</div>
                  <div className="mt-0.5 text-xs text-muted-foreground">
                    Dilaporkan pada {formatDateTime(status.data.createdAt)} · {status.data.violationType}
                  </div>
                </div>
                <span className="rounded-full bg-gold/15 px-4 py-1.5 text-xs font-bold uppercase tracking-wide text-gold">
                  {reportStatusLabel(status.data.status)}
                </span>
              </div>

              <h3 className="mt-5 font-display text-sm font-extrabold uppercase tracking-wide text-brand">
                Riwayat Penanganan
              </h3>
              <ol className="relative mt-4 space-y-5 border-l-2 border-gold/50 pl-6">
                {[...status.data.timeline].reverse().map((t, i) => (
                  <li key={i} className="relative">
                    <span className="absolute -left-[31px] top-1 h-3.5 w-3.5 rounded-full border-2 border-gold bg-white" />
                    <div className="text-sm font-semibold text-brand">{reportStatusLabel(t.status)}</div>
                    <div className="text-xs text-muted-foreground">{formatDate(t.createdAt)}</div>
                    {t.note && <p className="mt-1 text-sm text-foreground/80">{t.note}</p>}
                  </li>
                ))}
              </ol>
              <p className="mt-6 rounded-lg bg-paper p-4 text-xs text-muted-foreground">
                Demi keamanan, sistem tidak menampilkan informasi sensitif laporan. Jika petugas memerlukan informasi
                tambahan, catatan akan muncul pada riwayat di atas.
              </p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

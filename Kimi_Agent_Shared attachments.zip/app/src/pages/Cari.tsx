import { useSearchParams, Link } from "react-router";
import { FileText, Newspaper, BookOpen } from "lucide-react";
import PageHero from "@/components/PageHero";
import { trpc } from "@/providers/trpc";
import { formatDate } from "@/lib/site";

export default function Cari() {
  const [params] = useSearchParams();
  const q = params.get("q") ?? "";
  const result = trpc.cms.search.useQuery({ q }, { enabled: q.length >= 2 });
  const r = result.data;
  const empty =
    r && r.news.length === 0 && r.documents.length === 0 && r.pages.length === 0;

  return (
    <div>
      <PageHero title="Hasil Pencarian" subtitle={q ? `Kata kunci: "${q}"` : undefined} />
      <section className="py-12 lg:py-16">
        <div className="container-site max-w-4xl space-y-10">
          {result.isLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-16 animate-pulse rounded-xl bg-muted" />
              ))}
            </div>
          ) : !r || empty ? (
            <p className="rounded-xl border bg-white p-10 text-center text-sm text-muted-foreground">
              Tidak ditemukan hasil untuk kata kunci tersebut.
            </p>
          ) : (
            <>
              {r.news.length > 0 && (
                <div>
                  <h2 className="mb-4 flex items-center gap-2 font-display text-lg font-extrabold uppercase tracking-wide text-brand">
                    <Newspaper className="h-5 w-5 text-gold" /> Berita
                  </h2>
                  <ul className="space-y-2">
                    {r.news.map((n) => (
                      <li key={n.id}>
                        <Link to={`/berita/${n.slug}`} className="block rounded-xl border bg-white p-4 shadow-sm transition-colors hover:border-gold">
                          <div className="font-semibold text-brand">{n.title}</div>
                          <div className="mt-1 text-xs text-muted-foreground">{formatDate(n.publishedAt)}</div>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {r.documents.length > 0 && (
                <div>
                  <h2 className="mb-4 flex items-center gap-2 font-display text-lg font-extrabold uppercase tracking-wide text-brand">
                    <FileText className="h-5 w-5 text-gold" /> Dokumen
                  </h2>
                  <ul className="space-y-2">
                    {r.documents.map((d) => (
                      <li key={d.id}>
                        <Link
                          to={d.section === "informasi_publik" ? "/informasi-publik" : d.section === "download" ? "/download" : "/publikasi"}
                          className="block rounded-xl border bg-white p-4 shadow-sm transition-colors hover:border-gold"
                        >
                          <div className="font-semibold text-brand">{d.title}</div>
                          <div className="mt-1 text-xs text-muted-foreground">{d.category}</div>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {r.pages.length > 0 && (
                <div>
                  <h2 className="mb-4 flex items-center gap-2 font-display text-lg font-extrabold uppercase tracking-wide text-brand">
                    <BookOpen className="h-5 w-5 text-gold" /> Halaman
                  </h2>
                  <ul className="space-y-2">
                    {r.pages.map((p) => (
                      <li key={p.id}>
                        <Link to="/profil" className="block rounded-xl border bg-white p-4 shadow-sm transition-colors hover:border-gold">
                          <div className="font-semibold text-brand">{p.title}</div>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}
        </div>
      </section>
    </div>
  );
}

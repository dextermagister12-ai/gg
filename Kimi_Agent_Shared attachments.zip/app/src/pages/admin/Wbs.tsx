import { useEffect, useState } from "react";
import { Link, useParams } from "react-router";
import { Download, Eye, FileDown, Printer, Search } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { formatDate, formatDateTime } from "@/lib/site";
import { REPORT_STATUSES, VIOLATION_TYPES, reportStatusLabel } from "@contracts/wbs";
import { toast } from "sonner";

const STATUS_COLOR: Record<string, string> = {
  diterima: "bg-sky-100 text-sky-800",
  verifikasi: "bg-amber-100 text-amber-800",
  telaah: "bg-violet-100 text-violet-800",
  penanganan: "bg-blue-100 text-blue-800",
  info_tambahan: "bg-orange-100 text-orange-800",
  selesai: "bg-green-100 text-green-800",
  ditutup: "bg-slate-200 text-slate-700",
};

function Badge({ status }: { status: string }) {
  return (
    <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide ${STATUS_COLOR[status] ?? "bg-muted"}`}>
      {reportStatusLabel(status)}
    </span>
  );
}

// ===================== DAFTAR LAPORAN =====================
export function WbsList() {
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<string>("");
  const [type, setType] = useState<string>("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [page, setPage] = useState(1);

  const list = trpc.wbs.list.useQuery({
    search: search || undefined,
    status: status || undefined,
    violationType: type || undefined,
    dateFrom: dateFrom || undefined,
    dateTo: dateTo || undefined,
    page,
  });

  const canManage = user && ["admin", "admin_wbs"].includes(user.role);
  const exportQ = trpc.wbs.exportData.useQuery(
    { status: status || undefined, violationType: type || undefined, dateFrom: dateFrom || undefined, dateTo: dateTo || undefined },
    { enabled: false },
  );

  const doExport = async (kind: "csv" | "print") => {
    const res = await exportQ.refetch();
    const rows = res.data ?? [];
    if (kind === "csv") {
      const header = ["Nomor Laporan", "Jenis Pelanggaran", "Terlapor", "OPD", "Tanggal", "Status", "Prioritas"];
      const lines = rows.map((r) =>
        [
          r.registrationNumber,
          r.violationType,
          r.reportedPerson ?? "",
          r.reportedAgency ?? "",
          formatDate(r.createdAt),
          reportStatusLabel(r.status),
          r.priority,
        ]
          .map((v) => `"${String(v).replace(/"/g, '""')}"`)
          .join(","),
      );
      const blob = new Blob([`\uFEFF${header.join(",")}\n${lines.join("\n")}`], {
        type: "text/csv;charset=utf-8",
      });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `laporan-wbs-${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      toast.success(`Berhasil mengekspor ${rows.length} laporan (CSV, dapat dibuka di Excel)`);
    } else {
      const win = window.open("", "_blank");
      if (!win) return;
      win.document.write(`<html><head><title>Laporan WBS</title><style>
        body{font-family:sans-serif;font-size:12px} table{border-collapse:collapse;width:100%}
        td,th{border:1px solid #999;padding:6px;text-align:left} th{background:#22264b;color:#fff}
        h1{font-size:16px}</style></head><body>
        <h1>Data Laporan WBS — Inspektorat Kabupaten Dompu</h1>
        <table><tr><th>Nomor</th><th>Jenis</th><th>Terlapor</th><th>OPD</th><th>Tanggal</th><th>Status</th></tr>
        ${rows.map((r) => `<tr><td>${r.registrationNumber}</td><td>${r.violationType}</td><td>${r.reportedPerson ?? ""}</td><td>${r.reportedAgency ?? ""}</td><td>${formatDate(r.createdAt)}</td><td>${reportStatusLabel(r.status)}</td></tr>`).join("")}
        </table></body></html>`);
      win.document.close();
      win.print();
    }
  };

  const totalPages = Math.max(1, Math.ceil((list.data?.total ?? 0) / 10));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-2xl font-extrabold uppercase tracking-wide text-brand">Laporan WBS</h1>
        {canManage && (
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => doExport("csv")} disabled={exportQ.isFetching}>
              <FileDown className="mr-2 h-4 w-4" /> Export Excel/CSV
            </Button>
            <Button variant="outline" onClick={() => doExport("print")} disabled={exportQ.isFetching}>
              <Printer className="mr-2 h-4 w-4" /> Cetak / PDF
            </Button>
          </div>
        )}
      </div>

      {/* Filter */}
      <div className="grid gap-3 rounded-xl border bg-white p-4 shadow-sm sm:grid-cols-2 lg:grid-cols-5">
        <div className="relative lg:col-span-2">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            placeholder="Cari nomor / terlapor / OPD..."
            className="h-10 pl-9"
            aria-label="Cari laporan"
          />
        </div>
        <Select value={status} onValueChange={(v) => { setStatus(v === "all" ? "" : v); setPage(1); }}>
          <SelectTrigger className="h-10" aria-label="Filter status">
            <SelectValue placeholder="Semua Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Semua Status</SelectItem>
            {REPORT_STATUSES.map((s) => (
              <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={type} onValueChange={(v) => { setType(v === "all" ? "" : v); setPage(1); }}>
          <SelectTrigger className="h-10" aria-label="Filter jenis pelanggaran">
            <SelectValue placeholder="Semua Jenis" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Semua Jenis</SelectItem>
            {VIOLATION_TYPES.map((v) => (
              <SelectItem key={v} value={v}>{v}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex gap-2">
          <Input type="date" value={dateFrom} onChange={(e) => { setDateFrom(e.target.value); setPage(1); }} className="h-10" aria-label="Dari tanggal" />
          <Input type="date" value={dateTo} onChange={(e) => { setDateTo(e.target.value); setPage(1); }} className="h-10" aria-label="Sampai tanggal" />
        </div>
      </div>

      {/* Tabel */}
      <div className="overflow-x-auto rounded-xl border bg-white shadow-sm">
        <table className="w-full min-w-[760px] text-sm">
          <thead>
            <tr className="border-b bg-brand text-left text-white">
              <th className="px-4 py-3 text-xs font-bold uppercase">No</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Nomor Laporan</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Jenis</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Terlapor</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">OPD</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Tanggal</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Status</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {list.isLoading ? (
              <tr>
                <td colSpan={8} className="p-8 text-center text-muted-foreground">Memuat data...</td>
              </tr>
            ) : (list.data?.data.length ?? 0) === 0 ? (
              <tr>
                <td colSpan={8} className="p-8 text-center text-muted-foreground">Tidak ada laporan.</td>
              </tr>
            ) : (
              list.data?.data.map((r, i) => (
                <tr key={r.id} className="border-b last:border-0 hover:bg-paper/60">
                  <td className="px-4 py-3">{(page - 1) * 10 + i + 1}</td>
                  <td className="px-4 py-3 font-mono text-xs font-semibold">{r.registrationNumber}</td>
                  <td className="px-4 py-3">{r.violationType}</td>
                  <td className="px-4 py-3">{r.reportedPerson}</td>
                  <td className="px-4 py-3 text-xs">{r.reportedAgency ?? "-"}</td>
                  <td className="px-4 py-3 text-xs">{formatDate(r.createdAt)}</td>
                  <td className="px-4 py-3"><Badge status={r.status} /></td>
                  <td className="px-4 py-3">
                    <Button asChild size="sm" variant="outline" className="h-9">
                      <Link to={`/admin/wbs/${r.id}`}>
                        <Eye className="mr-1 h-3.5 w-3.5" /> Detail
                      </Link>
                    </Button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <Button variant="outline" disabled={page <= 1} onClick={() => setPage(page - 1)}>Sebelumnya</Button>
          <span className="text-sm text-muted-foreground">Halaman {page} dari {totalPages}</span>
          <Button variant="outline" disabled={page >= totalPages} onClick={() => setPage(page + 1)}>Berikutnya</Button>
        </div>
      )}
    </div>
  );
}

// ===================== DETAIL LAPORAN =====================
export function WbsDetail() {
  const { id } = useParams<{ id: string }>();
  const reportId = Number(id);
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const detail = trpc.wbs.detail.useQuery({ id: reportId }, { enabled: !!reportId });
  const canManage = user && ["admin", "admin_wbs"].includes(user.role);

  const [newStatus, setNewStatus] = useState("");
  const [notes, setNotes] = useState("");
  const [publicNote, setPublicNote] = useState("");
  const [noteOnly, setNoteOnly] = useState("");

  const updateMut = trpc.wbs.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Status laporan diperbarui");
      setNewStatus("");
      setNotes("");
      setPublicNote("");
      utils.wbs.detail.invalidate({ id: reportId });
    },
    onError: (e) => toast.error(e.message),
  });
  const noteMut = trpc.wbs.addNote.useMutation({
    onSuccess: () => {
      toast.success("Catatan ditambahkan");
      setNoteOnly("");
      utils.wbs.detail.invalidate({ id: reportId });
    },
    onError: (e) => toast.error(e.message),
  });
  const [attTarget, setAttTarget] = useState<number | null>(null);
  const attQuery = trpc.wbs.attachmentUrl.useQuery(
    { reportId, attachmentId: attTarget ?? 0 },
    { enabled: !!attTarget, staleTime: 0, retry: false },
  );
  useEffect(() => {
    if (attQuery.data && attTarget) {
      window.open(attQuery.data.url, "_blank", "noopener");
      setAttTarget(null);
    }
    if (attQuery.isError && attTarget) {
      toast.error(attQuery.error.message);
      setAttTarget(null);
    }
  }, [attQuery.data, attQuery.isError, attQuery.error, attTarget]);

  const r = detail.data?.report;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <Link to="/admin/wbs" className="text-sm text-muted-foreground hover:text-gold">← Kembali ke daftar</Link>
          <h1 className="mt-1 font-display text-2xl font-extrabold uppercase tracking-wide text-brand">
            {r?.registrationNumber ?? "Detail Laporan"}
          </h1>
        </div>
        {r && <Badge status={r.status} />}
      </div>

      {detail.isLoading ? (
        <div className="h-64 animate-pulse rounded-xl bg-muted" />
      ) : !r ? (
        <p className="text-muted-foreground">Laporan tidak ditemukan.</p>
      ) : (
        <div className="grid gap-6 lg:grid-cols-2">
          <div className="space-y-6">
            <section className="rounded-xl border bg-white p-5 shadow-sm">
              <h2 className="mb-4 border-b-2 border-gold pb-2 font-display text-sm font-extrabold uppercase tracking-wide text-brand">
                Informasi Pelapor
              </h2>
              <dl className="grid grid-cols-1 gap-2 text-sm sm:grid-cols-2">
                <div><dt className="text-xs text-muted-foreground">Nama</dt><dd className="font-medium">{r.reporterName ?? "Anonim"}</dd></div>
                <div><dt className="text-xs text-muted-foreground">NIK</dt><dd>{r.reporterNik ?? "-"}</dd></div>
                <div><dt className="text-xs text-muted-foreground">Email</dt><dd>{r.reporterEmail ?? "-"}</dd></div>
                <div><dt className="text-xs text-muted-foreground">Telepon</dt><dd>{r.reporterPhone ?? "-"}</dd></div>
                <div className="sm:col-span-2"><dt className="text-xs text-muted-foreground">Alamat</dt><dd>{r.reporterAddress ?? "-"}</dd></div>
                <div><dt className="text-xs text-muted-foreground">Anonim</dt><dd>{r.anonymous ? "Ya" : "Tidak"}</dd></div>
                <div><dt className="text-xs text-muted-foreground">Identitas dirahasiakan</dt><dd>{r.confidential ? "Ya" : "Tidak"}</dd></div>
              </dl>
            </section>

            <section className="rounded-xl border bg-white p-5 shadow-sm">
              <h2 className="mb-4 border-b-2 border-gold pb-2 font-display text-sm font-extrabold uppercase tracking-wide text-brand">
                Informasi Terlapor
              </h2>
              <dl className="grid grid-cols-1 gap-2 text-sm sm:grid-cols-2">
                <div><dt className="text-xs text-muted-foreground">Nama</dt><dd className="font-medium">{r.reportedPerson}</dd></div>
                <div><dt className="text-xs text-muted-foreground">Jabatan</dt><dd>{r.reportedPosition ?? "-"}</dd></div>
                <div><dt className="text-xs text-muted-foreground">Instansi/OPD</dt><dd>{r.reportedAgency ?? "-"}</dd></div>
                <div><dt className="text-xs text-muted-foreground">Unit Kerja</dt><dd>{r.reportedUnit ?? "-"}</dd></div>
              </dl>
            </section>

            <section className="rounded-xl border bg-white p-5 shadow-sm">
              <h2 className="mb-4 border-b-2 border-gold pb-2 font-display text-sm font-extrabold uppercase tracking-wide text-brand">
                Detail Pelanggaran
              </h2>
              <dl className="space-y-2 text-sm">
                <div><dt className="text-xs text-muted-foreground">Jenis Pelanggaran</dt><dd className="font-medium">{r.violationType}</dd></div>
                <div className="grid grid-cols-2 gap-2">
                  <div><dt className="text-xs text-muted-foreground">Tanggal Kejadian</dt><dd>{r.incidentDate ?? "-"}</dd></div>
                  <div><dt className="text-xs text-muted-foreground">Lokasi</dt><dd>{r.incidentLocation ?? "-"}</dd></div>
                </div>
                <div><dt className="text-xs text-muted-foreground">Kronologi</dt><dd className="whitespace-pre-line leading-relaxed">{r.chronology}</dd></div>
                {r.partiesInvolved && <div><dt className="text-xs text-muted-foreground">Pihak Terlibat</dt><dd className="whitespace-pre-line">{r.partiesInvolved}</dd></div>}
                {r.estimatedLoss && <div><dt className="text-xs text-muted-foreground">Perkiraan Kerugian</dt><dd>{r.estimatedLoss}</dd></div>}
              </dl>
            </section>

            <section className="rounded-xl border bg-white p-5 shadow-sm">
              <h2 className="mb-4 border-b-2 border-gold pb-2 font-display text-sm font-extrabold uppercase tracking-wide text-brand">
                Bukti ({detail.data?.attachments.length ?? 0})
              </h2>
              {(detail.data?.attachments.length ?? 0) === 0 ? (
                <p className="text-sm text-muted-foreground">Tidak ada bukti terlampir.</p>
              ) : (
                <ul className="space-y-2">
                  {detail.data?.attachments.map((a) => (
                    <li key={a.id} className="flex items-center justify-between rounded-lg border px-4 py-2.5 text-sm">
                      <span className="truncate">{a.fileName}</span>
                      {canManage && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-9 shrink-0"
                          disabled={attQuery.isFetching}
                          onClick={() => setAttTarget(a.id)}
                        >
                          <Download className="mr-1 h-3.5 w-3.5" /> Unduh
                        </Button>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </div>

          <div className="space-y-6">
            {canManage && (
              <section className="rounded-xl border-2 border-gold/60 bg-white p-5 shadow-sm">
                <h2 className="mb-4 border-b-2 border-gold pb-2 font-display text-sm font-extrabold uppercase tracking-wide text-brand">
                  Ubah Status / Tindak Lanjut
                </h2>
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <Label>Status Baru</Label>
                    <Select value={newStatus} onValueChange={setNewStatus}>
                      <SelectTrigger className="h-11" aria-label="Status baru">
                        <SelectValue placeholder="Pilih status" />
                      </SelectTrigger>
                      <SelectContent>
                        {REPORT_STATUSES.map((s) => (
                          <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label>Catatan Pemeriksa (intern)</Label>
                    <Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} />
                  </div>
                  <div className="space-y-1.5">
                    <Label>Catatan untuk Pelapor (tampil di cek status)</Label>
                    <Textarea rows={2} value={publicNote} onChange={(e) => setPublicNote(e.target.value)} />
                  </div>
                  <Button
                    className="w-full bg-brand text-white hover:bg-brand-ink"
                    disabled={!newStatus || updateMut.isPending}
                    onClick={() =>
                      updateMut.mutate({
                        id: reportId,
                        status: newStatus as (typeof REPORT_STATUSES)[number]["value"],
                        notes: notes || undefined,
                        publicNote: publicNote || undefined,
                      })
                    }
                  >
                    {updateMut.isPending ? "Menyimpan..." : "Ubah Status"}
                  </Button>
                </div>

                <div className="mt-6 space-y-3 border-t pt-5">
                  <Label>Tambah Catatan (tanpa mengubah status)</Label>
                  <Textarea rows={2} value={noteOnly} onChange={(e) => setNoteOnly(e.target.value)} />
                  <Button
                    variant="outline"
                    className="w-full"
                    disabled={!noteOnly.trim() || noteMut.isPending}
                    onClick={() => noteMut.mutate({ id: reportId, notes: noteOnly })}
                  >
                    Tambah Catatan
                  </Button>
                </div>
              </section>
            )}

            <section className="rounded-xl border bg-white p-5 shadow-sm">
              <h2 className="mb-4 border-b-2 border-gold pb-2 font-display text-sm font-extrabold uppercase tracking-wide text-brand">
                Riwayat Penanganan
              </h2>
              <ol className="relative space-y-4 border-l-2 border-gold/40 pl-5">
                {(detail.data?.updates ?? []).map((u) => (
                  <li key={u.id} className="relative">
                    <span className="absolute -left-[27px] top-1 h-3 w-3 rounded-full border-2 border-gold bg-white" />
                    <div className="text-sm font-semibold text-brand">{reportStatusLabel(u.status)}</div>
                    <div className="text-xs text-muted-foreground">
                      {formatDateTime(u.createdAt)} · oleh {u.updatedBy ?? "-"}
                    </div>
                    {u.notes && <p className="mt-1 rounded bg-muted/60 p-2 text-xs">{u.notes}</p>}
                    {u.publicNote && (
                      <p className="mt-1 rounded bg-gold/10 p-2 text-xs text-foreground/80">
                        <span className="font-semibold text-gold">Untuk pelapor:</span> {u.publicNote}
                      </p>
                    )}
                  </li>
                ))}
              </ol>
            </section>

            <Button variant="outline" className="w-full" onClick={() => window.print()}>
              <Printer className="mr-2 h-4 w-4" /> Cetak Laporan
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

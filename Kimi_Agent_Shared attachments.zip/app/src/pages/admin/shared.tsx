import { useState } from "react";
import { ImagePlus, Loader2, X } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { toast } from "sonner";

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(",")[1]);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

export function ImagePicker({
  value,
  onChange,
  label = "Gambar",
}: {
  value?: string | null;
  onChange: (key: string | null, previewUrl: string | null) => void;
  label?: string;
}) {
  const [busy, setBusy] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const upload = trpc.cms.adminUpload.useMutation({
    onError: (e) => toast.error(e.message),
  });

  return (
    <div className="space-y-2">
      <span className="text-sm font-medium">{label}</span>
      <div className="flex items-center gap-3">
        {(preview || value) && (
          <div className="relative h-20 w-32 overflow-hidden rounded-lg border bg-muted">
            {preview ? (
              <img src={preview} alt="Pratinjau" className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full items-center justify-center text-[10px] text-muted-foreground">tersimpan</div>
            )}
            <button
              type="button"
              onClick={() => {
                onChange(null, null);
                setPreview(null);
              }}
              className="absolute right-1 top-1 rounded-full bg-black/60 p-1 text-white"
              aria-label="Hapus gambar"
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        )}
        <label className="flex min-h-[44px] cursor-pointer items-center gap-2 rounded-lg border border-dashed border-brand/40 px-4 text-sm text-brand hover:border-gold">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4" />}
          {busy ? "Mengunggah..." : "Pilih Gambar"}
          <input
            type="file"
            accept=".jpg,.jpeg,.png,.webp"
            className="hidden"
            disabled={busy}
            onChange={async (e) => {
              const f = e.target.files?.[0];
              e.target.value = "";
              if (!f) return;
              if (f.size > 8 * 1024 * 1024) {
                toast.error("Ukuran gambar maksimal 8 MB");
                return;
              }
              setBusy(true);
              try {
                const b64 = await fileToBase64(f);
                const res = await upload.mutateAsync({
                  name: f.name,
                  contentBase64: b64,
                  contentType: f.type || undefined,
                  folder: "cms",
                  kind: "image",
                });
                setPreview(URL.createObjectURL(f));
                onChange(res.key, null);
                toast.success("Gambar terunggah");
              } catch {
                /* error di-toast */
              } finally {
                setBusy(false);
              }
            }}
          />
        </label>
      </div>
    </div>
  );
}

export function FilePicker({
  onPicked,
}: {
  onPicked: (f: { key: string; fileName: string; fileType: string; fileSize: number }) => void;
}) {
  const [busy, setBusy] = useState(false);
  const upload = trpc.cms.adminUpload.useMutation({
    onError: (e) => toast.error(e.message),
  });
  return (
    <label className="flex min-h-[44px] w-fit cursor-pointer items-center gap-2 rounded-lg border border-dashed border-brand/40 px-4 text-sm text-brand hover:border-gold">
      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ImagePlus className="h-4 w-4" />}
      {busy ? "Mengunggah..." : "Unggah Berkas (PDF/DOC/XLS/JPG/PNG, maks 15 MB)"}
      <input
        type="file"
        accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png"
        className="hidden"
        disabled={busy}
        onChange={async (e) => {
          const f = e.target.files?.[0];
          e.target.value = "";
          if (!f) return;
          if (f.size > 15 * 1024 * 1024) {
            toast.error("Ukuran berkas maksimal 15 MB");
            return;
          }
          setBusy(true);
          try {
            const b64 = await fileToBase64(f);
            const res = await upload.mutateAsync({
              name: f.name,
              contentBase64: b64,
              contentType: f.type || undefined,
              folder: "dokumen",
              kind: "document",
            });
            onPicked({ key: res.key, fileName: res.fileName, fileType: res.fileType, fileSize: res.size });
            toast.success("Berkas terunggah");
          } catch {
            /* error di-toast */
          } finally {
            setBusy(false);
          }
        }}
      />
    </label>
  );
}

export function AdminHeader({ title, children }: { title: string; children?: React.ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
      <h1 className="font-display text-2xl font-extrabold uppercase tracking-wide text-brand">{title}</h1>
      {children}
    </div>
  );
}

import { useEffect, useState } from "react";
import { DatabaseBackup, Download } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { formatDateTime } from "@/lib/site";
import { USER_ROLES } from "@contracts/wbs";
import { AdminHeader, ImagePicker } from "./shared";
import { toast } from "sonner";

// ===================== PENGGUNA =====================
export function Pengguna() {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  const list = trpc.admin.userList.useQuery();
  const setRole = trpc.admin.userSetRole.useMutation({
    onSuccess: (d) => {
      if (d.ok) toast.success("Peran pengguna diperbarui");
      else toast.error(d.message ?? "Gagal");
      utils.admin.userList.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div>
      <AdminHeader title="Manajemen Pengguna" />
      <div className="overflow-x-auto rounded-xl border bg-white shadow-sm">
        <table className="w-full min-w-[640px] text-sm">
          <thead>
            <tr className="border-b bg-brand text-left text-white">
              <th className="px-4 py-3 text-xs font-bold uppercase">Nama</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Email</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Login Terakhir</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Peran (RBAC)</th>
            </tr>
          </thead>
          <tbody>
            {(list.data ?? []).map((u) => (
              <tr key={u.id} className="border-b last:border-0 hover:bg-paper/60">
                <td className="px-4 py-3 font-medium">{u.name ?? "-"}</td>
                <td className="px-4 py-3 text-xs">{u.email ?? "-"}</td>
                <td className="px-4 py-3 text-xs">{formatDateTime(u.lastSignInAt)}</td>
                <td className="px-4 py-3">
                  <Select
                    value={u.role}
                    disabled={u.id === user?.id}
                    onValueChange={(v) => setRole.mutate({ id: u.id, role: v as typeof u.role })}
                  >
                    <SelectTrigger className="h-9 w-44" aria-label={`Peran ${u.name}`}>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {USER_ROLES.map((r) => (
                        <SelectItem key={r.value} value={r.value}>
                          {r.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </td>
              </tr>
            ))}
            {(list.data?.length ?? 0) === 0 && (
              <tr>
                <td colSpan={4} className="p-8 text-center text-muted-foreground">
                  {list.isLoading ? "Memuat..." : "Belum ada pengguna."}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-xs text-muted-foreground">
        Pengguna baru otomatis terdaftar saat pertama kali masuk melalui tombol Login (Sign in with Kimi). Berikan peran
        sesuai kewenangan: Admin WBS mengelola laporan, Editor mengelola konten, Viewer hanya melihat.
      </p>
    </div>
  );
}

// ===================== AUDIT LOG =====================
export function AuditLog() {
  const [page, setPage] = useState(1);
  const list = trpc.admin.auditList.useQuery({ page });

  return (
    <div>
      <AdminHeader title="Audit Log" />
      <div className="overflow-x-auto rounded-xl border bg-white shadow-sm">
        <table className="w-full min-w-[640px] text-sm">
          <thead>
            <tr className="border-b bg-brand text-left text-white">
              <th className="px-4 py-3 text-xs font-bold uppercase">Waktu</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Pengguna</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Aktivitas</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">IP</th>
            </tr>
          </thead>
          <tbody>
            {(list.data ?? []).map((l) => (
              <tr key={l.id} className="border-b last:border-0">
                <td className="whitespace-nowrap px-4 py-3 text-xs">{formatDateTime(l.createdAt)}</td>
                <td className="px-4 py-3 text-xs">{l.userName ?? "Publik/Sistem"}</td>
                <td className="px-4 py-3">{l.action}</td>
                <td className="px-4 py-3 font-mono text-xs">{l.ipAddress ?? "-"}</td>
              </tr>
            ))}
            {(list.data?.length ?? 0) === 0 && (
              <tr>
                <td colSpan={4} className="p-8 text-center text-muted-foreground">
                  {list.isLoading ? "Memuat..." : "Belum ada aktivitas tercatat."}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="mt-4 flex items-center justify-center gap-2">
        <Button variant="outline" disabled={page <= 1} onClick={() => setPage(page - 1)}>Sebelumnya</Button>
        <span className="text-sm text-muted-foreground">Halaman {page}</span>
        <Button variant="outline" disabled={(list.data?.length ?? 0) < 30} onClick={() => setPage(page + 1)}>Berikutnya</Button>
      </div>
    </div>
  );
}

// ===================== PENGATURAN TAMPILAN =====================
type SettingsState = {
  site: { name: string; tagline: string; primaryColor: string; accentColor: string; surfaceColor: string; logoKey: string | null; theme: string };
  sambutan: { name: string; position: string; photoKey: string | null; text: string };
  kontak: { address: string; phone: string; email: string; mapsQuery: string; facebook: string; instagram: string; youtube: string };
  footer: { text: string };
  struktur: string; // JSON text
};

export function Pengaturan() {
  const utils = trpc.useUtils();
  const q = trpc.cms.getSettings.useQuery();
  const save = trpc.cms.saveSettings.useMutation({
    onSuccess: () => {
      toast.success("Pengaturan disimpan");
      utils.cms.getSettings.invalidate();
      utils.cms.publicSettings.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const [s, setS] = useState<SettingsState | null>(null);
  useEffect(() => {
    if (q.data && !s) {
      const d = q.data as Record<string, Record<string, unknown> | null>;
      setS({
        site: {
          name: String(d.site?.name ?? ""),
          tagline: String(d.site?.tagline ?? ""),
          primaryColor: String(d.site?.primaryColor ?? "#22264b"),
          accentColor: String(d.site?.accentColor ?? "#c9962e"),
          surfaceColor: String(d.site?.surfaceColor ?? "#f7f4ec"),
          logoKey: (d.site?.logoKey as string) ?? null,
          theme: String(d.site?.theme ?? "light"),
        },
        sambutan: {
          name: String(d.sambutan?.name ?? ""),
          position: String(d.sambutan?.position ?? ""),
          photoKey: (d.sambutan?.photoKey as string) ?? null,
          text: String(d.sambutan?.text ?? ""),
        },
        kontak: {
          address: String(d.kontak?.address ?? ""),
          phone: String(d.kontak?.phone ?? ""),
          email: String(d.kontak?.email ?? ""),
          mapsQuery: String(d.kontak?.mapsQuery ?? ""),
          facebook: String(d.kontak?.facebook ?? ""),
          instagram: String(d.kontak?.instagram ?? ""),
          youtube: String(d.kontak?.youtube ?? ""),
        },
        footer: { text: String(d.footer?.text ?? "") },
        struktur: JSON.stringify(d.struktur ?? { nodes: [] }, null, 2),
      });
    }
  }, [q.data, s]);

  if (!s) return <div className="h-64 animate-pulse rounded-xl bg-muted" />;

  const saveSection = (key: "site" | "sambutan" | "kontak" | "footer" | "struktur", value: unknown) =>
    save.mutate({ key, value });

  return (
    <div className="space-y-6">
      <AdminHeader title="Pengaturan Tampilan & Konten" />

      {/* Identitas & Warna */}
      <section className="rounded-xl border bg-white p-6 shadow-sm">
        <h2 className="mb-4 border-b-2 border-gold pb-2 font-display text-sm font-extrabold uppercase tracking-wide text-brand">
          Identitas & Tema Website
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label>Nama Website</Label>
            <Input value={s.site.name} onChange={(e) => setS({ ...s, site: { ...s.site, name: e.target.value } })} />
          </div>
          <div className="space-y-1.5">
            <Label>Tagline</Label>
            <Input value={s.site.tagline} onChange={(e) => setS({ ...s, site: { ...s.site, tagline: e.target.value } })} />
          </div>
          <div className="space-y-1.5">
            <Label>Warna Utama</Label>
            <div className="flex items-center gap-2">
              <input type="color" value={s.site.primaryColor} onChange={(e) => setS({ ...s, site: { ...s.site, primaryColor: e.target.value } })} className="h-11 w-16 cursor-pointer rounded border" aria-label="Warna utama" />
              <Input value={s.site.primaryColor} onChange={(e) => setS({ ...s, site: { ...s.site, primaryColor: e.target.value } })} className="font-mono" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Warna Aksen</Label>
            <div className="flex items-center gap-2">
              <input type="color" value={s.site.accentColor} onChange={(e) => setS({ ...s, site: { ...s.site, accentColor: e.target.value } })} className="h-11 w-16 cursor-pointer rounded border" aria-label="Warna aksen" />
              <Input value={s.site.accentColor} onChange={(e) => setS({ ...s, site: { ...s.site, accentColor: e.target.value } })} className="font-mono" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Warna Latar (Background Section)</Label>
            <div className="flex items-center gap-2">
              <input type="color" value={s.site.surfaceColor} onChange={(e) => setS({ ...s, site: { ...s.site, surfaceColor: e.target.value } })} className="h-11 w-16 cursor-pointer rounded border" aria-label="Warna latar" />
              <Input value={s.site.surfaceColor} onChange={(e) => setS({ ...s, site: { ...s.site, surfaceColor: e.target.value } })} className="font-mono" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Tema</Label>
            <Select value={s.site.theme} onValueChange={(v) => setS({ ...s, site: { ...s.site, theme: v } })}>
              <SelectTrigger aria-label="Tema"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="light">Light (Government Professional)</SelectItem>
                <SelectItem value="dark">Dark</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="mt-4">
          <ImagePicker label="Logo Website (opsional, kosongkan untuk emblem bawaan)" value={s.site.logoKey} onChange={(key) => setS({ ...s, site: { ...s.site, logoKey: key } })} />
        </div>
        <Button className="mt-4 bg-brand text-white hover:bg-brand-ink" disabled={save.isPending} onClick={() => saveSection("site", s.site)}>
          Simpan Identitas & Tema
        </Button>
      </section>

      {/* Sambutan */}
      <section className="rounded-xl border bg-white p-6 shadow-sm">
        <h2 className="mb-4 border-b-2 border-gold pb-2 font-display text-sm font-extrabold uppercase tracking-wide text-brand">
          Sambutan Inspektur
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label>Nama Inspektur</Label>
            <Input value={s.sambutan.name} onChange={(e) => setS({ ...s, sambutan: { ...s.sambutan, name: e.target.value } })} />
          </div>
          <div className="space-y-1.5">
            <Label>Jabatan</Label>
            <Input value={s.sambutan.position} onChange={(e) => setS({ ...s, sambutan: { ...s.sambutan, position: e.target.value } })} />
          </div>
        </div>
        <div className="mt-4 space-y-1.5">
          <Label>Isi Sambutan</Label>
          <Textarea rows={6} value={s.sambutan.text} onChange={(e) => setS({ ...s, sambutan: { ...s.sambutan, text: e.target.value } })} />
        </div>
        <div className="mt-4">
          <ImagePicker label="Foto Inspektur" value={s.sambutan.photoKey} onChange={(key) => setS({ ...s, sambutan: { ...s.sambutan, photoKey: key } })} />
        </div>
        <Button className="mt-4 bg-brand text-white hover:bg-brand-ink" disabled={save.isPending} onClick={() => saveSection("sambutan", s.sambutan)}>
          Simpan Sambutan
        </Button>
      </section>

      {/* Kontak */}
      <section className="rounded-xl border bg-white p-6 shadow-sm">
        <h2 className="mb-4 border-b-2 border-gold pb-2 font-display text-sm font-extrabold uppercase tracking-wide text-brand">
          Kontak & Media Sosial
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5 sm:col-span-2">
            <Label>Alamat Kantor</Label>
            <Textarea rows={2} value={s.kontak.address} onChange={(e) => setS({ ...s, kontak: { ...s.kontak, address: e.target.value } })} />
          </div>
          <div className="space-y-1.5">
            <Label>Telepon</Label>
            <Input value={s.kontak.phone} onChange={(e) => setS({ ...s, kontak: { ...s.kontak, phone: e.target.value } })} />
          </div>
          <div className="space-y-1.5">
            <Label>Email Resmi</Label>
            <Input value={s.kontak.email} onChange={(e) => setS({ ...s, kontak: { ...s.kontak, email: e.target.value } })} />
          </div>
          <div className="space-y-1.5">
            <Label>Kata Kunci Google Maps</Label>
            <Input value={s.kontak.mapsQuery} onChange={(e) => setS({ ...s, kontak: { ...s.kontak, mapsQuery: e.target.value } })} />
          </div>
          <div className="space-y-1.5">
            <Label>Facebook</Label>
            <Input value={s.kontak.facebook} onChange={(e) => setS({ ...s, kontak: { ...s.kontak, facebook: e.target.value } })} />
          </div>
          <div className="space-y-1.5">
            <Label>Instagram</Label>
            <Input value={s.kontak.instagram} onChange={(e) => setS({ ...s, kontak: { ...s.kontak, instagram: e.target.value } })} />
          </div>
          <div className="space-y-1.5">
            <Label>YouTube</Label>
            <Input value={s.kontak.youtube} onChange={(e) => setS({ ...s, kontak: { ...s.kontak, youtube: e.target.value } })} />
          </div>
        </div>
        <Button className="mt-4 bg-brand text-white hover:bg-brand-ink" disabled={save.isPending} onClick={() => saveSection("kontak", s.kontak)}>
          Simpan Kontak
        </Button>
      </section>

      {/* Footer */}
      <section className="rounded-xl border bg-white p-6 shadow-sm">
        <h2 className="mb-4 border-b-2 border-gold pb-2 font-display text-sm font-extrabold uppercase tracking-wide text-brand">
          Teks Footer
        </h2>
        <Textarea rows={3} value={s.footer.text} onChange={(e) => setS({ ...s, footer: { text: e.target.value } })} />
        <Button className="mt-4 bg-brand text-white hover:bg-brand-ink" disabled={save.isPending} onClick={() => saveSection("footer", s.footer)}>
          Simpan Footer
        </Button>
      </section>

      {/* Struktur Organisasi */}
      <section className="rounded-xl border bg-white p-6 shadow-sm">
        <h2 className="mb-4 border-b-2 border-gold pb-2 font-display text-sm font-extrabold uppercase tracking-wide text-brand">
          Struktur Organisasi (JSON)
        </h2>
        <p className="mb-3 text-xs text-muted-foreground">
          Format: {`{"nodes":[{"id":"unik","label":"Nama Jabatan","parent":null|"id-induk"}]}`}
        </p>
        <Textarea rows={10} value={s.struktur} onChange={(e) => setS({ ...s, struktur: e.target.value })} className="font-mono text-xs" />
        <Button
          className="mt-4 bg-brand text-white hover:bg-brand-ink"
          disabled={save.isPending}
          onClick={() => {
            try {
              saveSection("struktur", JSON.parse(s.struktur));
            } catch {
              toast.error("Format JSON struktur tidak valid");
            }
          }}
        >
          Simpan Struktur
        </Button>
      </section>
    </div>
  );
}

// ===================== BACKUP =====================
export function Backup() {
  const backup = trpc.admin.backup.useMutation({
    onSuccess: (dump) => {
      const blob = new Blob([JSON.stringify(dump, null, 2)], { type: "application/json" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `backup-inspektorat-dompu-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      toast.success("Backup database berhasil diunduh");
    },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div>
      <AdminHeader title="Backup Database" />
      <div className="max-w-xl rounded-xl border bg-white p-6 shadow-sm">
        <DatabaseBackup className="h-10 w-10 text-gold" />
        <h2 className="mt-3 font-display text-lg font-extrabold uppercase tracking-wide text-brand">
          Cadangkan Seluruh Data
        </h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Mengunduh seluruh isi database (pengguna, konten, laporan WBS, pengaturan, audit log) dalam format JSON.
          Simpan berkas backup di tempat yang aman karena memuat data sensitif.
        </p>
        <Button className="mt-5 bg-brand text-white hover:bg-brand-ink" disabled={backup.isPending} onClick={() => backup.mutate()}>
          <Download className="mr-2 h-4 w-4" /> {backup.isPending ? "Menyiapkan..." : "Backup & Download"}
        </Button>
        <p className="mt-4 text-xs text-muted-foreground">
          Disarankan melakukan backup berkala, minimal seminggu sekali, dan sebelum pembaruan sistem.
        </p>
      </div>
    </div>
  );
}

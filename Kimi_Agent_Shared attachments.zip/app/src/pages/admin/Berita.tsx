import { useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { formatDate } from "@/lib/site";
import { NEWS_CATEGORIES } from "@contracts/wbs";
import { AdminHeader, ImagePicker } from "./shared";
import { toast } from "sonner";

type NewsForm = {
  id?: number;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  imageKey: string | null;
  featured: boolean;
  publishedAt: string;
};

const EMPTY: NewsForm = {
  title: "",
  excerpt: "",
  content: "",
  category: "Kegiatan",
  imageKey: null,
  featured: false,
  publishedAt: "",
};

export default function Berita() {
  const utils = trpc.useUtils();
  const list = trpc.cms.newsAdminList.useQuery({});
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<NewsForm>(EMPTY);
  const [search, setSearch] = useState("");

  const save = trpc.cms.newsSave.useMutation({
    onSuccess: () => {
      toast.success("Berita disimpan");
      setOpen(false);
      utils.cms.newsAdminList.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });
  const del = trpc.cms.newsDelete.useMutation({
    onSuccess: () => {
      toast.success("Berita dihapus");
      utils.cms.newsAdminList.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const rows = (list.data ?? []).filter((n) =>
    search ? n.title.toLowerCase().includes(search.toLowerCase()) : true,
  );

  return (
    <div>
      <AdminHeader title="Kelola Berita">
        <div className="flex gap-2">
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari berita..."
            className="h-10 w-48"
            aria-label="Cari berita"
          />
          <Button
            className="bg-brand text-white hover:bg-brand-ink"
            onClick={() => {
              setForm(EMPTY);
              setOpen(true);
            }}
          >
            <Plus className="mr-2 h-4 w-4" /> Buat Berita
          </Button>
        </div>
      </AdminHeader>

      <div className="overflow-x-auto rounded-xl border bg-white shadow-sm">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="border-b bg-brand text-left text-white">
              <th className="px-4 py-3 text-xs font-bold uppercase">Judul</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Kategori</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Tanggal</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Unggulan</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((n) => (
              <tr key={n.id} className="border-b last:border-0 hover:bg-paper/60">
                <td className="max-w-xs px-4 py-3">
                  <div className="line-clamp-2 font-medium">{n.title}</div>
                  <div className="text-xs text-muted-foreground">{n.views} kali dibaca</div>
                </td>
                <td className="px-4 py-3">{n.category}</td>
                <td className="px-4 py-3 text-xs">{formatDate(n.publishedAt)}</td>
                <td className="px-4 py-3">{n.featured ? "Ya" : "-"}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-9"
                      onClick={() => {
                        setForm({
                          id: n.id,
                          title: n.title,
                          excerpt: n.excerpt ?? "",
                          content: n.content ?? "",
                          category: n.category,
                          imageKey: n.imageKey,
                          featured: n.featured,
                          publishedAt: n.publishedAt ? new Date(n.publishedAt).toISOString().slice(0, 16) : "",
                        });
                        setOpen(true);
                      }}
                      aria-label={`Edit ${n.title}`}
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-9 text-destructive"
                      onClick={() => {
                        if (confirm(`Hapus berita "${n.title}"?`)) del.mutate({ id: n.id });
                      }}
                      aria-label={`Hapus ${n.title}`}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={5} className="p-8 text-center text-muted-foreground">
                  {list.isLoading ? "Memuat..." : "Belum ada berita."}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="font-display uppercase tracking-wide text-brand">
              {form.id ? "Edit Berita" : "Buat Berita"}
            </DialogTitle>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              save.mutate({
                id: form.id,
                title: form.title,
                excerpt: form.excerpt || undefined,
                content: form.content || undefined,
                category: form.category,
                imageKey: form.imageKey,
                featured: form.featured,
                publishedAt: form.publishedAt || undefined,
              });
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="b-judul">Judul *</Label>
              <Input id="b-judul" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="b-ringkas">Ringkasan</Label>
              <Textarea id="b-ringkas" rows={2} value={form.excerpt} onChange={(e) => setForm({ ...form, excerpt: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="b-isi">Isi Berita</Label>
              <Textarea id="b-isi" rows={10} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Kategori</Label>
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                  <SelectTrigger aria-label="Kategori berita"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {NEWS_CATEGORIES.map((c) => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="b-tgl">Jadwal Publikasi</Label>
                <Input id="b-tgl" type="datetime-local" value={form.publishedAt} onChange={(e) => setForm({ ...form, publishedAt: e.target.value })} />
              </div>
            </div>
            <ImagePicker label="Gambar Utama" value={form.imageKey} onChange={(key) => setForm({ ...form, imageKey: key })} />
            <label className="flex items-center gap-2 text-sm">
              <Checkbox checked={form.featured} onCheckedChange={(v) => setForm({ ...form, featured: v === true })} />
              Jadikan berita unggulan
            </label>
            <Button type="submit" className="w-full bg-brand text-white hover:bg-brand-ink" disabled={save.isPending}>
              {save.isPending ? "Menyimpan..." : "Simpan Berita"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

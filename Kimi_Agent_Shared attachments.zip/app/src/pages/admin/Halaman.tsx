import { useState } from "react";
import { Pencil, Plus } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { AdminHeader } from "./shared";
import { toast } from "sonner";

export default function Halaman() {
  const utils = trpc.useUtils();
  const list = trpc.cms.pageList.useQuery();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ slug: "", title: "", content: "" });
  const [isNew, setIsNew] = useState(false);

  const save = trpc.cms.pageSave.useMutation({
    onSuccess: () => {
      toast.success("Halaman disimpan");
      setOpen(false);
      utils.cms.pageList.invalidate();
      utils.cms.page.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div>
      <AdminHeader title="Kelola Halaman">
        <Button
          className="bg-brand text-white hover:bg-brand-ink"
          onClick={() => {
            setForm({ slug: "", title: "", content: "" });
            setIsNew(true);
            setOpen(true);
          }}
        >
          <Plus className="mr-2 h-4 w-4" /> Halaman Baru
        </Button>
      </AdminHeader>

      <div className="rounded-xl border bg-white p-4 shadow-sm">
        <p className="mb-4 text-xs text-muted-foreground">
          Format konten: baris diawali <code className="rounded bg-muted px-1">##</code> menjadi subjudul, baris diawali{" "}
          <code className="rounded bg-muted px-1">-</code> menjadi daftar poin, sisanya paragraf.
        </p>
        <ul className="divide-y">
          {(list.data ?? []).map((p) => (
            <li key={p.id} className="flex items-center justify-between gap-3 py-3">
              <div>
                <div className="font-medium text-brand">{p.title}</div>
                <div className="font-mono text-xs text-muted-foreground">/{p.slug}</div>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="h-9"
                onClick={() => {
                  setForm({ slug: p.slug, title: p.title, content: p.content ?? "" });
                  setIsNew(false);
                  setOpen(true);
                }}
              >
                <Pencil className="mr-1 h-3.5 w-3.5" /> Edit
              </Button>
            </li>
          ))}
        </ul>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="font-display uppercase tracking-wide text-brand">
              {isNew ? "Halaman Baru" : `Edit: ${form.title}`}
            </DialogTitle>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              save.mutate(form);
            }}
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="h-slug">Slug (URL) *</Label>
                <Input id="h-slug" required disabled={!isNew} value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} placeholder="contoh: tentang" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="h-judul">Judul *</Label>
                <Input id="h-judul" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="h-konten">Konten</Label>
              <Textarea id="h-konten" rows={16} value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} className="font-mono text-xs" />
            </div>
            <Button type="submit" className="w-full bg-brand text-white hover:bg-brand-ink" disabled={save.isPending}>
              {save.isPending ? "Menyimpan..." : "Simpan Halaman"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

import { useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AdminHeader, ImagePicker } from "./shared";
import { toast } from "sonner";

type GalleryForm = {
  id?: number;
  type: "photo" | "video";
  title: string;
  album: string;
  fileKey: string | null;
  videoUrl: string;
};

const EMPTY: GalleryForm = { type: "photo", title: "", album: "Umum", fileKey: null, videoUrl: "" };

export default function GaleriAdmin() {
  const utils = trpc.useUtils();
  const list = trpc.cms.gallery.useQuery({});
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<GalleryForm>(EMPTY);

  const save = trpc.cms.gallerySave.useMutation({
    onSuccess: () => {
      toast.success("Item galeri disimpan");
      setOpen(false);
      utils.cms.gallery.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });
  const del = trpc.cms.galleryDelete.useMutation({
    onSuccess: () => {
      toast.success("Item dihapus");
      utils.cms.gallery.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const albums = [...new Set((list.data ?? []).map((g) => g.album))];

  return (
    <div>
      <AdminHeader title="Kelola Galeri">
        <Button
          className="bg-brand text-white hover:bg-brand-ink"
          onClick={() => {
            setForm(EMPTY);
            setOpen(true);
          }}
        >
          <Plus className="mr-2 h-4 w-4" /> Tambah Foto / Video
        </Button>
      </AdminHeader>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {(list.data ?? []).map((g) => (
          <div key={g.id} className="overflow-hidden rounded-xl border bg-white shadow-sm">
            <div className="relative aspect-[4/3] bg-muted">
              {g.fileUrl ? (
                <img src={g.fileUrl} alt={g.title} className="h-full w-full object-cover" loading="lazy" />
              ) : (
                <div className="flex h-full items-center justify-center text-xs text-muted-foreground">Video</div>
              )}
              <span className="absolute left-2 top-2 rounded-full bg-black/60 px-2 py-0.5 text-[10px] font-bold uppercase text-white">
                {g.type === "photo" ? "Foto" : "Video"}
              </span>
            </div>
            <div className="p-3">
              <div className="line-clamp-1 text-xs font-semibold text-brand">{g.title}</div>
              <div className="mt-2 flex items-center justify-between">
                <span className="rounded-full bg-gold/15 px-2 py-0.5 text-[10px] text-gold">{g.album}</span>
                <div className="flex gap-1">
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8"
                    onClick={() => {
                      setForm({ id: g.id, type: g.type, title: g.title, album: g.album, fileKey: g.fileKey, videoUrl: g.videoUrl ?? "" });
                      setOpen(true);
                    }}
                    aria-label="Edit item galeri"
                  >
                    <Pencil className="h-3 w-3" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8 text-destructive"
                    onClick={() => {
                      if (confirm("Hapus item ini?")) del.mutate({ id: g.id });
                    }}
                    aria-label="Hapus item galeri"
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      {(list.data?.length ?? 0) === 0 && (
        <p className="rounded-xl border bg-white p-8 text-center text-sm text-muted-foreground">Belum ada item galeri.</p>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display uppercase tracking-wide text-brand">
              {form.id ? "Edit Item" : "Tambah Item Galeri"}
            </DialogTitle>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              save.mutate({ ...form, videoUrl: form.videoUrl || null });
            }}
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Jenis</Label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v as "photo" | "video" })}>
                  <SelectTrigger aria-label="Jenis item"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="photo">Foto</SelectItem>
                    <SelectItem value="video">Video</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="g-album">Album</Label>
                <Input id="g-album" list="album-list" value={form.album} onChange={(e) => setForm({ ...form, album: e.target.value })} />
                <datalist id="album-list">
                  {albums.map((a) => (
                    <option key={a} value={a} />
                  ))}
                </datalist>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="g-judul">Judul *</Label>
              <Input id="g-judul" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>
            {form.type === "photo" ? (
              <ImagePicker label="Foto" value={form.fileKey} onChange={(key) => setForm({ ...form, fileKey: key })} />
            ) : (
              <>
                <div className="space-y-1.5">
                  <Label htmlFor="g-video">URL Video (YouTube/dll)</Label>
                  <Input id="g-video" value={form.videoUrl} onChange={(e) => setForm({ ...form, videoUrl: e.target.value })} placeholder="https://youtube.com/watch?v=..." />
                </div>
                <ImagePicker label="Thumbnail (opsional)" value={form.fileKey} onChange={(key) => setForm({ ...form, fileKey: key })} />
              </>
            )}
            <Button type="submit" className="w-full bg-brand text-white hover:bg-brand-ink" disabled={save.isPending}>
              {save.isPending ? "Menyimpan..." : "Simpan"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

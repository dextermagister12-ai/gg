import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { formatDateTime } from "@/lib/site";
import { AdminHeader } from "./shared";
import { toast } from "sonner";

const STATUS_LABEL: Record<string, string> = { baru: "Baru", diproses: "Diproses", selesai: "Selesai" };

export default function PengaduanAdmin() {
  const utils = trpc.useUtils();
  const list = trpc.cms.complaintList.useQuery();
  const setStatus = trpc.cms.complaintSetStatus.useMutation({
    onSuccess: () => {
      toast.success("Status diperbarui");
      utils.cms.complaintList.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div>
      <AdminHeader title="Pengaduan Masyarakat" />
      <div className="space-y-3">
        {(list.data ?? []).map((c) => (
          <div key={c.id} className="rounded-xl border bg-white p-5 shadow-sm">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="font-mono text-xs text-muted-foreground">{c.ticket}</div>
                <div className="mt-1 font-semibold text-brand">{c.subject}</div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {c.name} · {c.email || "-"} · {c.phone || "-"} · {formatDateTime(c.createdAt)}
                </div>
              </div>
              <div className="flex gap-1">
                {(["baru", "diproses", "selesai"] as const).map((s) => (
                  <Button
                    key={s}
                    size="sm"
                    variant={c.status === s ? "default" : "outline"}
                    className={`h-9 text-xs ${c.status === s ? "bg-brand text-white" : ""}`}
                    onClick={() => setStatus.mutate({ id: c.id, status: s })}
                  >
                    {STATUS_LABEL[s]}
                  </Button>
                ))}
              </div>
            </div>
            <p className="mt-3 whitespace-pre-line rounded-lg bg-muted/50 p-3 text-sm">{c.message}</p>
          </div>
        ))}
        {(list.data?.length ?? 0) === 0 && (
          <p className="rounded-xl border bg-white p-8 text-center text-sm text-muted-foreground">
            {list.isLoading ? "Memuat..." : "Belum ada pengaduan masuk."}
          </p>
        )}
      </div>
    </div>
  );
}

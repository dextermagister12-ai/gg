import { NavLink, Outlet, Navigate, Link } from "react-router";
import {
  LayoutDashboard,
  ShieldAlert,
  FileText,
  Newspaper,
  CalendarDays,
  FolderOpen,
  Image as ImageIcon,
  BookOpen,
  Megaphone,
  Users,
  ScrollText,
  Settings,
  DatabaseBackup,
  LogOut,
  PanelTop,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Emblem } from "@/lib/site";

type MenuItem = { to: string; label: string; icon: typeof LayoutDashboard; roles: string[] };

const MENU: MenuItem[] = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard, roles: ["admin", "admin_wbs", "editor", "viewer"] },
  { to: "/admin/wbs", label: "Laporan WBS", icon: ShieldAlert, roles: ["admin", "admin_wbs", "viewer"] },
  { to: "/admin/berita", label: "Berita", icon: Newspaper, roles: ["admin", "editor"] },
  { to: "/admin/banner", label: "Banner / Slider", icon: PanelTop, roles: ["admin", "editor"] },
  { to: "/admin/agenda", label: "Agenda", icon: CalendarDays, roles: ["admin", "editor"] },
  { to: "/admin/dokumen", label: "Publikasi & Dokumen", icon: FolderOpen, roles: ["admin", "editor"] },
  { to: "/admin/galeri", label: "Galeri", icon: ImageIcon, roles: ["admin", "editor"] },
  { to: "/admin/halaman", label: "Halaman", icon: BookOpen, roles: ["admin", "editor"] },
  { to: "/admin/pengaduan", label: "Pengaduan", icon: Megaphone, roles: ["admin", "admin_wbs", "editor", "viewer"] },
  { to: "/admin/pengguna", label: "Pengguna", icon: Users, roles: ["admin"] },
  { to: "/admin/audit", label: "Audit Log", icon: ScrollText, roles: ["admin"] },
  { to: "/admin/pengaturan", label: "Pengaturan Tampilan", icon: Settings, roles: ["admin", "editor"] },
  { to: "/admin/backup", label: "Backup", icon: DatabaseBackup, roles: ["admin"] },
];

export const ROLE_LABEL: Record<string, string> = {
  admin: "Super Admin",
  admin_wbs: "Admin WBS",
  editor: "Editor",
  viewer: "Viewer",
  user: "Pengguna Biasa",
};

export default function AdminLayout() {
  const { user, isLoading, logout } = useAuth({ redirectOnUnauthenticated: true });

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-muted">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-brand border-t-gold" />
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  if (!["admin", "admin_wbs", "editor", "viewer"].includes(user.role)) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-muted p-6 text-center">
        <ShieldAlert className="h-12 w-12 text-gold" />
        <h1 className="font-display text-xl font-bold text-brand">Akses Terbatas</h1>
        <p className="max-w-md text-sm text-muted-foreground">
          Akun Anda ({user.email}) belum memiliki hak akses pengelola. Hubungi Super Admin untuk diberikan peran Admin
          WBS, Editor, atau Viewer.
        </p>
        <Button asChild variant="outline">
          <Link to="/">Kembali ke Beranda</Link>
        </Button>
      </div>
    );
  }

  const items = MENU.filter((m) => m.roles.includes(user.role));

  return (
    <div className="flex min-h-screen bg-muted/40">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col bg-brand text-white lg:flex">
        <Link to="/" className="flex items-center gap-3 border-b border-white/10 p-5">
          <Emblem className="h-9 w-9" />
          <div>
            <div className="font-display text-xs font-extrabold uppercase leading-tight">Inspektorat</div>
            <div className="text-[10px] text-white/60">Kabupaten Dompu</div>
          </div>
        </Link>
        <nav className="flex-1 space-y-1 overflow-y-auto p-3" aria-label="Menu admin">
          {items.map((m) => (
            <NavLink
              key={m.to}
              to={m.to}
              end={m.to === "/admin"}
              className={({ isActive }) =>
                `flex min-h-[44px] items-center gap-3 rounded-lg px-4 py-2.5 text-sm font-medium transition-colors ${
                  isActive ? "bg-gold text-white" : "text-white/80 hover:bg-white/10"
                }`
              }
            >
              <m.icon className="h-4 w-4 shrink-0" />
              {m.label}
            </NavLink>
          ))}
        </nav>
        <div className="border-t border-white/10 p-4">
          <div className="mb-1 truncate text-sm font-semibold">{user.name ?? "Admin"}</div>
          <div className="mb-3 text-xs text-gold">{ROLE_LABEL[user.role] ?? user.role}</div>
          <Button variant="outline" size="sm" onClick={logout} className="w-full border-white/30 bg-transparent text-white hover:bg-white/10">
            <LogOut className="mr-2 h-4 w-4" /> Keluar
          </Button>
        </div>
      </aside>

      <div className="flex min-h-screen flex-1 flex-col lg:pl-64">
        {/* Topbar mobile */}
        <div className="sticky top-0 z-30 flex items-center justify-between border-b bg-brand p-3 text-white lg:hidden">
          <Link to="/" className="flex items-center gap-2">
            <Emblem className="h-8 w-8" />
            <span className="font-display text-xs font-extrabold uppercase">Admin Inspektorat</span>
          </Link>
          <Button variant="ghost" size="sm" onClick={logout} className="text-white">
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
        <nav className="flex gap-1 overflow-x-auto border-b bg-white p-2 lg:hidden" aria-label="Menu admin mobile">
          {items.map((m) => (
            <NavLink
              key={m.to}
              to={m.to}
              end={m.to === "/admin"}
              className={({ isActive }) =>
                `flex min-h-[40px] shrink-0 items-center gap-2 rounded-lg px-3 text-xs font-medium ${
                  isActive ? "bg-brand text-white" : "text-brand"
                }`
              }
            >
              <m.icon className="h-3.5 w-3.5" />
              {m.label}
            </NavLink>
          ))}
        </nav>
        <main className="flex-1 p-4 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

export { FileText as _FileTextIcon };

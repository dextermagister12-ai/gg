import { useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { formatDate } from "@/lib/site";
import {
  DOWNLOAD_CATEGORIES,
  INFO_PUBLIK_CATEGORIES,
  PUBLIKASI_CATEGORIES,
} from "@contracts/wbs";
import { AdminHeader, FilePicker } from "./shared";
import { toast } from "sonner";

type DocForm = {
  id?: number;
  title: string;
  description: string;
  section: "publikasi" | "informasi_publik" | "download";
  category: string;
  fileKey: string | null;
  fileName: string | null;
  fileType: string | null;
  fileSize: number | null;
};

const EMPTY: DocForm = {
  title: "",
  description: "",
  section: "publikasi",
  category: "Laporan",
  fileKey: null,
  fileName: null,
  fileType: null,
  fileSize: null,
};

const SECTION_CATEGORIES: Record<string, readonly string[]> = {
  publikasi: PUBLIKASI_CATEGORIES,
  informasi_publik: INFO_PUBLIK_CATEGORIES,
  download: DOWNLOAD_CATEGORIES,
};

export default function Dokumen() {
  const utils = trpc.useUtils();
  const [section, setSection] = useState<string>("");
  const list = trpc.cms.documentAdminList.useQuery({ section: section || undefined });
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<DocForm>(EMPTY);

  const save = trpc.cms.documentSave.useMutation({
    onSuccess: () => {
      toast.success("Dokumen disimpan");
      setOpen(false);
      utils.cms.documentAdminList.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });
  const del = trpc.cms.documentDelete.useMutation({
    onSuccess: () => {
      toast.success("Dokumen dihapus");
      utils.cms.documentAdminList.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const sectionLabel: Record<string, string> = {
    publikasi: "Publikasi",
    informasi_publik: "Informasi Publik",
    download: "Pusat Download",
  };

  return (
    <div>
      <AdminHeader title="Publikasi & Dokumen">
        <div className="flex gap-2">
          <Select value={section} onValueChange={(v) => setSection(v === "all" ? "" : v)}>
            <SelectTrigger className="h-10 w-44" aria-label="Filter bagian">
              <SelectValue placeholder="Semua Bagian" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Bagian</SelectItem>
              <SelectItem value="publikasi">Publikasi</SelectItem>
              <SelectItem value="informasi_publik">Informasi Publik</SelectItem>
              <SelectItem value="download">Pusat Download</SelectItem>
            </SelectContent>
          </Select>
          <Button
            className="bg-brand text-white hover:bg-brand-ink"
            onClick={() => {
              setForm(EMPTY);
              setOpen(true);
            }}
          >
            <Plus className="mr-2 h-4 w-4" /> Tambah Dokumen
          </Button>
        </div>
      </AdminHeader>

      <div className="overflow-x-auto rounded-xl border bg-white shadow-sm">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="border-b bg-brand text-left text-white">
              <th className="px-4 py-3 text-xs font-bold uppercase">Judul</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Bagian</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Kategori</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Berkas</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Tanggal</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {(list.data ?? []).map((d) => (
              <tr key={d.id} className="border-b last:border-0 hover:bg-paper/60">
                <td className="max-w-xs px-4 py-3">
                  <div className="line-clamp-2 font-medium">{d.title}</div>
                  <div className="text-xs text-muted-foreground">{d.downloads} unduhan</div>
                </td>
                <td className="px-4 py-3 text-xs">{sectionLabel[d.section]}</td>
                <td className="px-4 py-3 text-xs">{d.category}</td>
                <td className="max-w-[140px] truncate px-4 py-3 text-xs">{d.fileName ?? "-"}</td>
                <td className="px-4 py-3 text-xs">{formatDate(d.publishedAt)}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-9"
                      onClick={() => {
                        setForm({
                          id: d.id,
                          title: d.title,
                          description: d.description ?? "",
                          section: d.section,
                          category: d.category,
                          fileKey: d.fileKey,
                          fileName: d.fileName,
                          fileType: d.fileType,
                          fileSize: d.fileSize,
                        });
                        setOpen(true);
                      }}
                      aria-label="Edit dokumen"
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-9 text-destructive"
                      onClick={() => {
                        if (confirm("Hapus dokumen ini?")) del.mutate({ id: d.id });
                      }}
                      aria-label="Hapus dokumen"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {(list.data?.length ?? 0) === 0 && (
              <tr>
                <td colSpan={6} className="p-8 text-center text-muted-foreground">
                  {list.isLoading ? "Memuat..." : "Belum ada dokumen."}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
          <DialogHeader>
            <DialogTitle className="font-display uppercase tracking-wide text-brand">
              {form.id ? "Edit Dokumen" : "Tambah Dokumen"}
            </DialogTitle>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              save.mutate(form);
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="d-judul">Judul Dokumen *</Label>
              <Input id="d-judul" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="d-desk">Deskripsi</Label>
              <Textarea id="d-desk" rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Bagian</Label>
                <Select
                  value={form.section}
                  onValueChange={(v) =>
                    setForm({ ...form, section: v as DocForm["section"], category: SECTION_CATEGORIES[v][0] })
                  }
                >
                  <SelectTrigger aria-label="Bagian dokumen"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="publikasi">Publikasi</SelectItem>
                    <SelectItem value="informasi_publik">Informasi Publik</SelectItem>
                    <SelectItem value="download">Pusat Download</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Kategori</Label>
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                  <SelectTrigger aria-label="Kategori dokumen"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {SECTION_CATEGORIES[form.section].map((c) => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Berkas Dokumen</Label>
              {form.fileName && (
                <p className="rounded-lg border bg-paper px-3 py-2 text-xs">Tersimpan: {form.fileName}</p>
              )}
              <FilePicker onPicked={(f) => setForm({ ...form, fileKey: f.key, fileName: f.fileName, fileType: f.fileType, fileSize: f.fileSize })} />
            </div>
            <Button type="submit" className="w-full bg-brand text-white hover:bg-brand-ink" disabled={save.isPending}>
              {save.isPending ? "Menyimpan..." : "Simpan Dokumen"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

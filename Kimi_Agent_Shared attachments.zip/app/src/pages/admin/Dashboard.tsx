import { Link } from "react-router";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import { trpc } from "@/providers/trpc";
import { useAuth } from "@/hooks/useAuth";
import { reportStatusLabel } from "@contracts/wbs";

const COLORS = ["#22264b", "#c9962e", "#4a5a9e", "#8a6a1d", "#6b7bc4", "#a39473", "#3d4470", "#d9b45c", "#252d8f", "#e0c98f", "#55619c"];

export default function AdminDashboard() {
  const { user } = useAuth();
  const canWbs = user && ["admin", "admin_wbs", "viewer"].includes(user.role);
  const stats = trpc.wbs.stats.useQuery(undefined, { enabled: !!canWbs });
  const site = trpc.cms.publicStats.useQuery();

  const s = stats.data;
  const statusMap = Object.fromEntries((s?.byStatus ?? []).map((x) => [x.status, x.n]));
  const cards = [
    { label: "Total Laporan", value: s?.total ?? 0 },
    { label: "Laporan Baru", value: statusMap["diterima"] ?? 0 },
    { label: "Dalam Verifikasi", value: (statusMap["verifikasi"] ?? 0) + (statusMap["telaah"] ?? 0) },
    { label: "Dalam Penanganan", value: statusMap["penanganan"] ?? 0 },
    { label: "Selesai", value: statusMap["selesai"] ?? 0 },
    { label: "Ditutup", value: statusMap["ditutup"] ?? 0 },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl font-extrabold uppercase tracking-wide text-brand">Dashboard</h1>
        <p className="text-sm text-muted-foreground">
          Selamat datang, {user?.name ?? user?.email}. Ringkasan aktivitas Inspektorat Kabupaten Dompu.
        </p>
      </div>

      {/* Statistik website */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: "Berita", value: site.data?.news ?? 0 },
          { label: "Dokumen", value: site.data?.documents ?? 0 },
          { label: "Galeri", value: site.data?.gallery ?? 0 },
          { label: "Agenda", value: site.data?.agendas ?? 0 },
        ].map((c) => (
          <div key={c.label} className="rounded-xl border bg-white p-4 shadow-sm">
            <div className="font-display text-2xl font-extrabold text-brand">{c.value}</div>
            <div className="text-xs uppercase tracking-wide text-muted-foreground">{c.label}</div>
          </div>
        ))}
      </div>

      {canWbs && (
        <>
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-extrabold uppercase tracking-wide text-brand">
              Statistik Whistleblowing System
            </h2>
            <Link to="/admin/wbs" className="text-sm font-semibold text-gold hover:underline">
              Kelola Laporan →
            </Link>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {cards.map((c) => (
              <div key={c.label} className="rounded-xl border bg-white p-4 shadow-sm">
                <div className="font-display text-2xl font-extrabold text-brand">{c.value}</div>
                <div className="text-[11px] uppercase tracking-wide text-muted-foreground">{c.label}</div>
              </div>
            ))}
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <div className="rounded-xl border bg-white p-5 shadow-sm">
              <h3 className="mb-4 font-display text-sm font-bold uppercase tracking-wide text-brand">
                Laporan per Bulan
              </h3>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={s?.byMonth ?? []}>
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="n" name="Laporan" fill="#22264b" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="rounded-xl border bg-white p-5 shadow-sm">
              <h3 className="mb-4 font-display text-sm font-bold uppercase tracking-wide text-brand">
                Berdasarkan Status
              </h3>
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie
                    data={(s?.byStatus ?? []).map((x) => ({ name: reportStatusLabel(x.status), value: x.n }))}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={50}
                    outerRadius={85}
                    paddingAngle={2}
                  >
                    {(s?.byStatus ?? []).map((_, i) => (
                      <Cell key={i} fill={COLORS[i % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="rounded-xl border bg-white p-5 shadow-sm">
              <h3 className="mb-4 font-display text-sm font-bold uppercase tracking-wide text-brand">
                Berdasarkan Jenis Pelanggaran
              </h3>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={s?.byType ?? []} layout="vertical" margin={{ left: 8 }}>
                  <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11 }} />
                  <YAxis type="category" dataKey="type" width={130} tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Bar dataKey="n" name="Laporan" fill="#c9962e" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="rounded-xl border bg-white p-5 shadow-sm">
              <h3 className="mb-4 font-display text-sm font-bold uppercase tracking-wide text-brand">
                Berdasarkan OPD Terlapor
              </h3>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={s?.byOpd ?? []} layout="vertical" margin={{ left: 8 }}>
                  <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11 }} />
                  <YAxis type="category" dataKey="opd" width={130} tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Bar dataKey="n" name="Laporan" fill="#4a5a9e" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

import { useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { formatDate } from "@/lib/site";
import { AdminHeader } from "./shared";
import { toast } from "sonner";

type AgendaForm = {
  id?: number;
  title: string;
  eventDate: string;
  eventTime: string;
  location: string;
  description: string;
};

const EMPTY: AgendaForm = { title: "", eventDate: "", eventTime: "", location: "", description: "" };

export default function AgendaAdmin() {
  const utils = trpc.useUtils();
  const list = trpc.cms.agendaList.useQuery({ upcoming: false });
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<AgendaForm>(EMPTY);

  const save = trpc.cms.agendaSave.useMutation({
    onSuccess: () => {
      toast.success("Agenda disimpan");
      setOpen(false);
      utils.cms.agendaList.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });
  const del = trpc.cms.agendaDelete.useMutation({
    onSuccess: () => {
      toast.success("Agenda dihapus");
      utils.cms.agendaList.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div>
      <AdminHeader title="Kelola Agenda">
        <Button
          className="bg-brand text-white hover:bg-brand-ink"
          onClick={() => {
            setForm(EMPTY);
            setOpen(true);
          }}
        >
          <Plus className="mr-2 h-4 w-4" /> Tambah Agenda
        </Button>
      </AdminHeader>

      <div className="overflow-x-auto rounded-xl border bg-white shadow-sm">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="border-b bg-brand text-left text-white">
              <th className="px-4 py-3 text-xs font-bold uppercase">Kegiatan</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Tanggal</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Waktu</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Lokasi</th>
              <th className="px-4 py-3 text-xs font-bold uppercase">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {(list.data ?? []).map((a) => (
              <tr key={a.id} className="border-b last:border-0 hover:bg-paper/60">
                <td className="max-w-xs px-4 py-3 font-medium">{a.title}</td>
                <td className="px-4 py-3 text-xs">{formatDate(a.eventDate)}</td>
                <td className="px-4 py-3 text-xs">{a.eventTime ?? "-"}</td>
                <td className="px-4 py-3 text-xs">{a.location ?? "-"}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-9"
                      onClick={() => {
                        setForm({
                          id: a.id,
                          title: a.title,
                          eventDate: a.eventDate,
                          eventTime: a.eventTime ?? "",
                          location: a.location ?? "",
                          description: a.description ?? "",
                        });
                        setOpen(true);
                      }}
                      aria-label="Edit agenda"
                    >
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-9 text-destructive"
                      onClick={() => {
                        if (confirm("Hapus agenda ini?")) del.mutate({ id: a.id });
                      }}
                      aria-label="Hapus agenda"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {(list.data?.length ?? 0) === 0 && (
              <tr>
                <td colSpan={5} className="p-8 text-center text-muted-foreground">
                  {list.isLoading ? "Memuat..." : "Belum ada agenda."}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display uppercase tracking-wide text-brand">
              {form.id ? "Edit Agenda" : "Tambah Agenda"}
            </DialogTitle>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              save.mutate({ ...form, eventTime: form.eventTime || undefined, location: form.location || undefined, description: form.description || undefined });
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="a-judul">Nama Kegiatan *</Label>
              <Input id="a-judul" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="a-tgl">Tanggal *</Label>
                <Input id="a-tgl" type="date" required value={form.eventDate} onChange={(e) => setForm({ ...form, eventDate: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="a-waktu">Waktu</Label>
                <Input id="a-waktu" value={form.eventTime} onChange={(e) => setForm({ ...form, eventTime: e.target.value })} placeholder="09.00 - 12.00 WITA" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="a-lokasi">Lokasi</Label>
              <Input id="a-lokasi" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="a-desk">Deskripsi</Label>
              <Textarea id="a-desk" rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <Button type="submit" className="w-full bg-brand text-white hover:bg-brand-ink" disabled={save.isPending}>
              {save.isPending ? "Menyimpan..." : "Simpan Agenda"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

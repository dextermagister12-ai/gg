import { useState } from "react";
import { ArrowDown, ArrowUp, Pencil, Plus, Trash2 } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { AdminHeader, ImagePicker } from "./shared";
import { toast } from "sonner";

type BannerForm = {
  id?: number;
  title: string;
  description: string;
  imageKey: string | null;
  ctaText: string;
  ctaLink: string;
  sortOrder: number;
  active: boolean;
};

const EMPTY: BannerForm = {
  title: "",
  description: "",
  imageKey: null,
  ctaText: "SELENGKAPNYA",
  ctaLink: "/profil",
  sortOrder: 0,
  active: true,
};

export default function Banner() {
  const utils = trpc.useUtils();
  const list = trpc.cms.bannerList.useQuery();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<BannerForm>(EMPTY);

  const save = trpc.cms.bannerSave.useMutation({
    onSuccess: () => {
      toast.success("Banner disimpan");
      setOpen(false);
      utils.cms.bannerList.invalidate();
      utils.cms.banners.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });
  const del = trpc.cms.bannerDelete.useMutation({
    onSuccess: () => {
      toast.success("Banner dihapus");
      utils.cms.bannerList.invalidate();
      utils.cms.banners.invalidate();
    },
    onError: (e) => toast.error(e.message),
  });

  const move = (id: number, dir: -1 | 1) => {
    const items = [...(list.data ?? [])];
    const idx = items.findIndex((b) => b.id === id);
    const swap = idx + dir;
    if (idx < 0 || swap < 0 || swap >= items.length) return;
    const a = items[idx];
    const b = items[swap];
    save.mutate({ id: a.id, title: a.title, description: a.description ?? "", imageKey: a.imageKey, ctaText: a.ctaText ?? "", ctaLink: a.ctaLink ?? "", sortOrder: b.sortOrder, active: a.active });
    save.mutate({ id: b.id, title: b.title, description: b.description ?? "", imageKey: b.imageKey, ctaText: b.ctaText ?? "", ctaLink: b.ctaLink ?? "", sortOrder: a.sortOrder, active: b.active });
  };

  return (
    <div>
      <AdminHeader title="Banner / Slider Beranda">
        <Button
          className="bg-brand text-white hover:bg-brand-ink"
          onClick={() => {
            setForm({ ...EMPTY, sortOrder: (list.data?.length ?? 0) + 1 });
            setOpen(true);
          }}
        >
          <Plus className="mr-2 h-4 w-4" /> Tambah Banner
        </Button>
      </AdminHeader>

      <div className="grid gap-4 md:grid-cols-2">
        {(list.data ?? []).map((b) => (
          <div key={b.id} className="overflow-hidden rounded-xl border bg-white shadow-sm">
            <div className="relative aspect-[16/6] bg-muted">
              {b.imageUrl && <img src={b.imageUrl} alt={b.title} className="h-full w-full object-cover" />}
              {!b.active && (
                <span className="absolute right-2 top-2 rounded-full bg-black/70 px-3 py-1 text-[10px] font-bold uppercase text-white">
                  Nonaktif
                </span>
              )}
            </div>
            <div className="space-y-2 p-4">
              <div className="line-clamp-2 font-semibold text-brand">{b.title}</div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Urutan: {b.sortOrder}</span>
                <div className="flex gap-1">
                  <Button size="sm" variant="outline" className="h-9" onClick={() => move(b.id, -1)} aria-label="Naikkan urutan">
                    <ArrowUp className="h-3.5 w-3.5" />
                  </Button>
                  <Button size="sm" variant="outline" className="h-9" onClick={() => move(b.id, 1)} aria-label="Turunkan urutan">
                    <ArrowDown className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-9"
                    onClick={() => {
                      setForm({
                        id: b.id,
                        title: b.title,
                        description: b.description ?? "",
                        imageKey: b.imageKey,
                        ctaText: b.ctaText ?? "",
                        ctaLink: b.ctaLink ?? "",
                        sortOrder: b.sortOrder,
                        active: b.active,
                      });
                      setOpen(true);
                    }}
                    aria-label="Edit banner"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-9 text-destructive"
                    onClick={() => {
                      if (confirm("Hapus banner ini?")) del.mutate({ id: b.id });
                    }}
                    aria-label="Hapus banner"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ))}
        {(list.data?.length ?? 0) === 0 && (
          <p className="rounded-xl border bg-white p-8 text-center text-sm text-muted-foreground md:col-span-2">
            Belum ada banner.
          </p>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
          <DialogHeader>
            <DialogTitle className="font-display uppercase tracking-wide text-brand">
              {form.id ? "Edit Banner" : "Tambah Banner"}
            </DialogTitle>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              save.mutate(form);
            }}
          >
            <div className="space-y-1.5">
              <Label htmlFor="bn-judul">Judul *</Label>
              <Input id="bn-judul" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="bn-desk">Deskripsi</Label>
              <Textarea id="bn-desk" rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            </div>
            <ImagePicker label="Gambar Banner" value={form.imageKey} onChange={(key) => setForm({ ...form, imageKey: key })} />
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="bn-cta">Teks Tombol</Label>
                <Input id="bn-cta" value={form.ctaText} onChange={(e) => setForm({ ...form, ctaText: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="bn-link">Tautan Tombol</Label>
                <Input id="bn-link" value={form.ctaLink} onChange={(e) => setForm({ ...form, ctaLink: e.target.value })} />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="bn-order">Urutan</Label>
              <Input id="bn-order" type="number" value={form.sortOrder} onChange={(e) => setForm({ ...form, sortOrder: Number(e.target.value) })} />
            </div>
            <label className="flex items-center gap-2 text-sm">
              <Checkbox checked={form.active} onCheckedChange={(v) => setForm({ ...form, active: v === true })} />
              Banner aktif (ditampilkan di beranda)
            </label>
            <Button type="submit" className="w-full bg-brand text-white hover:bg-brand-ink" disabled={save.isPending}>
              {save.isPending ? "Menyimpan..." : "Simpan Banner"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

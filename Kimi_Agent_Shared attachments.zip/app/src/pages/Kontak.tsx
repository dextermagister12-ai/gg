import { useState } from "react";
import { Mail, MapPin, Phone, Send } from "lucide-react";
import PageHero from "@/components/PageHero";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { usePublicSettings } from "@/lib/site";
import { toast } from "sonner";

export default function Kontak() {
  const { kontak } = usePublicSettings();
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "", message: "" });
  const submit = trpc.cms.submitComplaint.useMutation({
    onSuccess: (d) => {
      toast.success(`Pesan Anda terkirim. Nomor tiket: ${d.ticket}`);
      setForm({ name: "", email: "", phone: "", subject: "", message: "" });
    },
    onError: (e) => toast.error(e.message),
  });

  const mapsQuery = kontak.mapsQuery || "Kabupaten Dompu";

  return (
    <div>
      <PageHero title="Hubungi Kami" subtitle="Inspektorat Kabupaten Dompu siap melayani masyarakat." />
      <section className="py-12 lg:py-16">
        <div className="container-site grid gap-10 lg:grid-cols-2">
          <div>
            <h2 className="font-display text-xl font-extrabold uppercase tracking-wide text-brand">
              Inspektorat Kabupaten Dompu
            </h2>
            <ul className="mt-6 space-y-4">
              {kontak.address && (
                <li className="flex gap-3 rounded-xl border bg-white p-4 shadow-sm">
                  <MapPin className="h-5 w-5 shrink-0 text-gold" />
                  <div>
                    <div className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Alamat</div>
                    <div className="text-sm">{kontak.address}</div>
                  </div>
                </li>
              )}
              {kontak.phone && (
                <li className="flex gap-3 rounded-xl border bg-white p-4 shadow-sm">
                  <Phone className="h-5 w-5 shrink-0 text-gold" />
                  <div>
                    <div className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Telepon</div>
                    <div className="text-sm">{kontak.phone}</div>
                  </div>
                </li>
              )}
              {kontak.email && (
                <li className="flex gap-3 rounded-xl border bg-white p-4 shadow-sm">
                  <Mail className="h-5 w-5 shrink-0 text-gold" />
                  <div>
                    <div className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Email</div>
                    <div className="text-sm">{kontak.email}</div>
                  </div>
                </li>
              )}
            </ul>
            <div className="mt-6 overflow-hidden rounded-xl border shadow-sm">
              <iframe
                title="Peta lokasi Inspektorat Kabupaten Dompu"
                src={`https://www.google.com/maps?q=${encodeURIComponent(mapsQuery)}&output=embed`}
                className="h-72 w-full border-0"
                loading="lazy"
              />
            </div>
          </div>

          <div className="rounded-2xl border bg-white p-6 shadow-sm lg:p-8">
            <h2 className="font-display text-xl font-extrabold uppercase tracking-wide text-brand">Formulir Kontak</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Sampaikan pertanyaan atau pesan Anda. Untuk laporan pelanggaran, gunakan WBS.
            </p>
            <form
              className="mt-6 space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                submit.mutate(form);
              }}
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="k-nama">Nama Lengkap *</Label>
                  <Input id="k-nama" required minLength={2} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="h-11" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="k-email">Email</Label>
                  <Input id="k-email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="h-11" />
                </div>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="k-hp">Nomor HP</Label>
                  <Input id="k-hp" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="h-11" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="k-subjek">Subjek *</Label>
                  <Input id="k-subjek" required minLength={4} value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} className="h-11" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="k-pesan">Pesan *</Label>
                <Textarea id="k-pesan" required minLength={10} rows={5} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
              </div>
              <Button type="submit" disabled={submit.isPending} className="h-11 bg-brand text-white hover:bg-brand-ink">
                <Send className="mr-2 h-4 w-4" /> {submit.isPending ? "Mengirim..." : "Kirim Pesan"}
              </Button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
}

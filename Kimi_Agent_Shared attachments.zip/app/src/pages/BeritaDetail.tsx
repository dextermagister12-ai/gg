import { Link, useParams } from "react-router";
import { CalendarDays, Eye, Share2, User } from "lucide-react";
import PageHero from "@/components/PageHero";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { formatDate } from "@/lib/site";
import { toast } from "sonner";

export default function BeritaDetail() {
  const { slug } = useParams<{ slug: string }>();
  const detail = trpc.cms.newsDetail.useQuery({ slug: slug ?? "" }, { enabled: !!slug });
  const latest = trpc.cms.newsLatest.useQuery({ limit: 4 });
  const n = detail.data;

  const share = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({ title: n?.title, url });
      } catch {
        /* dibatalkan pengguna */
      }
    } else {
      await navigator.clipboard.writeText(url);
      toast.success("Tautan berita disalin ke clipboard");
    }
  };

  return (
    <div>
      <PageHero title="Berita" crumb={[{ label: "Berita", to: "/berita" }]} subtitle={n?.title} />
      <section className="py-12 lg:py-16">
        <div className="container-site grid gap-10 lg:grid-cols-[1fr_320px]">
          <article className="min-w-0">
            {detail.isLoading ? (
              <div className="space-y-4">
                <div className="h-8 w-2/3 animate-pulse rounded bg-muted" />
                <div className="aspect-video animate-pulse rounded-xl bg-muted" />
              </div>
            ) : !n ? (
              <p className="text-muted-foreground">Berita tidak ditemukan.</p>
            ) : (
              <>
                <div className="flex flex-wrap items-center gap-2 text-xs uppercase tracking-wide">
                  <span className="rounded-full bg-gold/15 px-2.5 py-1 font-semibold text-gold">{n.category}</span>
                </div>
                <h1 className="mt-3 font-display text-2xl font-extrabold leading-tight text-brand lg:text-3xl">
                  {n.title}
                </h1>
                <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1.5">
                    <CalendarDays className="h-4 w-4" /> {formatDate(n.publishedAt)}
                  </span>
                  {n.author && (
                    <span className="flex items-center gap-1.5">
                      <User className="h-4 w-4" /> {n.author}
                    </span>
                  )}
                  <span className="flex items-center gap-1.5">
                    <Eye className="h-4 w-4" /> {n.views + 1} kali dibaca
                  </span>
                  <Button variant="ghost" size="sm" onClick={share} className="h-9 text-brand hover:text-gold">
                    <Share2 className="mr-1.5 h-4 w-4" /> Bagikan
                  </Button>
                </div>
                {n.imageUrl && (
                  <img src={n.imageUrl} alt={n.title} className="mt-6 w-full rounded-xl border object-cover shadow-sm" />
                )}
                <div className="prose-sm mt-8 max-w-none whitespace-pre-line leading-relaxed text-foreground/90">
                  {n.content}
                </div>
              </>
            )}
          </article>

          <aside>
            <div className="rounded-xl border bg-white p-5 shadow-sm">
              <h3 className="border-b-2 border-gold pb-2 font-display text-sm font-extrabold uppercase tracking-wide text-brand">
                Berita Terbaru
              </h3>
              <ul className="mt-4 space-y-4">
                {(latest.data ?? [])
                  .filter((l) => l.slug !== slug)
                  .map((l) => (
                    <li key={l.id}>
                      <Link to={`/berita/${l.slug}`} className="group flex gap-3">
                        <div className="h-16 w-20 shrink-0 overflow-hidden rounded-md bg-muted">
                          {l.imageUrl && <img src={l.imageUrl} alt="" loading="lazy" className="h-full w-full object-cover" />}
                        </div>
                        <div className="line-clamp-2 text-sm font-semibold leading-snug text-brand group-hover:text-gold">
                          {l.title}
                        </div>
                      </Link>
                    </li>
                  ))}
              </ul>
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
}

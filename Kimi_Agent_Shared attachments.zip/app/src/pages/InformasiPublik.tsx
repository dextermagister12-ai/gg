import PageHero from "@/components/PageHero";
import DocList from "@/components/DocList";
import { INFO_PUBLIK_CATEGORIES } from "@contracts/wbs";

export default function InformasiPublik() {
  return (
    <div>
      <PageHero
        title="Informasi Publik"
        subtitle="Layanan informasi publik Inspektorat Kabupaten Dompu sesuai UU No. 14 Tahun 2008 tentang Keterbukaan Informasi Publik."
      />
      <section className="bg-paper py-10">
        <div className="container-site grid gap-6 md:grid-cols-3">
          <div className="rounded-xl border bg-white p-6 shadow-sm">
            <h3 className="font-display text-base font-bold uppercase tracking-wide text-brand">Permohonan Informasi</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Permohonan informasi publik dapat diajukan kepada PPID Inspektorat Kabupaten Dompu setiap hari kerja
              pukul 08.00–15.00 WITA, atau dengan mengunduh formulir pada Pusat Download.
            </p>
          </div>
          <div className="rounded-xl border bg-white p-6 shadow-sm">
            <h3 className="font-display text-base font-bold uppercase tracking-wide text-brand">Standar Pelayanan</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Permohonan informasi ditanggapi paling lambat 10 hari kerja sejak permohonan diterima, sesuai standar
              pelayanan informasi publik.
            </p>
          </div>
          <div className="rounded-xl border bg-white p-6 shadow-sm">
            <h3 className="font-display text-base font-bold uppercase tracking-wide text-brand">Informasi Dikecualikan</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Informasi yang dikecualikan — termasuk data laporan WBS dan identitas pelapor — tidak dapat diakses
              publik sesuai ketentuan peraturan perundang-undangan.
            </p>
          </div>
        </div>
      </section>
      <section className="py-12 lg:py-16">
        <div className="container-site">
          <h2 className="mb-6 font-display text-xl font-extrabold uppercase tracking-wide text-brand">
            Daftar Informasi Publik
          </h2>
          <DocList section="informasi_publik" categories={INFO_PUBLIK_CATEGORIES} />
        </div>
      </section>
    </div>
  );
}

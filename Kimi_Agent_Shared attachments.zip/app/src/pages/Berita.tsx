import { useState } from "react";
import { Link } from "react-router";
import { Newspaper, Search } from "lucide-react";
import PageHero from "@/components/PageHero";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatDate } from "@/lib/site";
import { NEWS_CATEGORIES } from "@contracts/wbs";

export default function Berita() {
  const [category, setCategory] = useState<string | undefined>();
  const [search, setSearch] = useState("");
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const list = trpc.cms.newsList.useQuery({ category, search: q || undefined, page });
  const popular = trpc.cms.newsPopular.useQuery();

  const totalPages = Math.max(1, Math.ceil((list.data?.total ?? 0) / 9));

  return (
    <div>
      <PageHero title="Berita" subtitle="Berita dan kegiatan terkini Inspektorat Kabupaten Dompu." />
      <section className="py-12 lg:py-16">
        <div className="container-site grid gap-10 lg:grid-cols-[1fr_320px]">
          <div>
            <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => {
                    setCategory(undefined);
                    setPage(1);
                  }}
                  className={`min-h-[40px] rounded-full border px-4 text-xs font-semibold ${!category ? "border-brand bg-brand text-white" : "bg-white text-brand hover:border-gold"}`}
                >
                  Semua
                </button>
                {NEWS_CATEGORIES.map((c) => (
                  <button
                    key={c}
                    onClick={() => {
                      setCategory(c);
                      setPage(1);
                    }}
                    className={`min-h-[40px] rounded-full border px-4 text-xs font-semibold ${category === c ? "border-brand bg-brand text-white" : "bg-white text-brand hover:border-gold"}`}
                  >
                    {c}
                  </button>
                ))}
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setQ(search);
                  setPage(1);
                }}
                className="flex gap-2"
              >
                <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Cari berita..." className="h-11" aria-label="Cari berita" />
                <Button type="submit" className="h-11 bg-brand text-white hover:bg-brand-ink" aria-label="Cari">
                  <Search className="h-4 w-4" />
                </Button>
              </form>
            </div>

            {list.isLoading ? (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="h-64 animate-pulse rounded-xl bg-muted" />
                ))}
              </div>
            ) : (list.data?.data.length ?? 0) === 0 ? (
              <div className="flex flex-col items-center gap-2 rounded-xl border bg-white p-12 text-center text-muted-foreground">
                <Newspaper className="h-10 w-10 opacity-40" />
                <p className="text-sm">Tidak ada berita yang cocok.</p>
              </div>
            ) : (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {list.data?.data.map((n) => (
                  <Link
                    key={n.id}
                    to={`/berita/${n.slug}`}
                    className="group overflow-hidden rounded-xl border bg-white shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg"
                  >
                    <div className="aspect-[16/9] overflow-hidden bg-muted">
                      {n.imageUrl ? (
                        <img src={n.imageUrl} alt={n.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                      ) : (
                        <div className="flex h-full items-center justify-center">
                          <Newspaper className="h-10 w-10 text-muted-foreground/40" />
                        </div>
                      )}
                    </div>
                    <div className="p-4">
                      <div className="flex items-center gap-2 text-[11px] uppercase tracking-wide">
                        <span className="rounded-full bg-gold/15 px-2 py-0.5 font-semibold text-gold">{n.category}</span>
                        <span className="text-muted-foreground">{formatDate(n.publishedAt)}</span>
                      </div>
                      <h2 className="mt-2 line-clamp-2 font-display text-sm font-bold leading-snug text-brand group-hover:text-gold">
                        {n.title}
                      </h2>
                      {n.excerpt && <p className="mt-2 line-clamp-2 text-xs text-muted-foreground">{n.excerpt}</p>}
                    </div>
                  </Link>
                ))}
              </div>
            )}

            {totalPages > 1 && (
              <div className="mt-8 flex items-center justify-center gap-2">
                <Button variant="outline" disabled={page <= 1} onClick={() => setPage(page - 1)} className="h-10">
                  Sebelumnya
                </Button>
                <span className="text-sm text-muted-foreground">
                  Halaman {page} dari {totalPages}
                </span>
                <Button variant="outline" disabled={page >= totalPages} onClick={() => setPage(page + 1)} className="h-10">
                  Berikutnya
                </Button>
              </div>
            )}
          </div>

          <aside className="space-y-6">
            <div className="rounded-xl border bg-white p-5 shadow-sm">
              <h3 className="border-b-2 border-gold pb-2 font-display text-sm font-extrabold uppercase tracking-wide text-brand">
                Berita Populer
              </h3>
              <ul className="mt-4 space-y-4">
                {(popular.data ?? []).map((p, i) => (
                  <li key={p.id}>
                    <Link to={`/berita/${p.slug}`} className="group flex gap-3">
                      <span className="font-display text-2xl font-extrabold text-gold/60">{String(i + 1).padStart(2, "0")}</span>
                      <div>
                        <div className="line-clamp-2 text-sm font-semibold leading-snug text-brand group-hover:text-gold">
                          {p.title}
                        </div>
                        <div className="mt-1 text-xs text-muted-foreground">{formatDate(p.publishedAt)}</div>
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </aside>
        </div>
      </section>
    </div>
  );
}

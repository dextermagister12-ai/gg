import { useState } from "react";
import PageHero from "@/components/PageHero";
import { trpc } from "@/providers/trpc";
import { PageContent, useReveal } from "@/lib/site";
import { Users, Landmark } from "lucide-react";

const TABS = [
  { slug: "tentang", label: "Tentang" },
  { slug: "sejarah", label: "Sejarah" },
  { slug: "tugas-fungsi", label: "Tugas & Fungsi" },
  { slug: "visi-misi", label: "Visi & Misi" },
  { slug: "struktur", label: "Struktur Organisasi" },
  { slug: "maklumat", label: "Maklumat Pelayanan" },
] as const;

type OrgNode = { id: string; label: string; parent: string | null };

const DEFAULT_TREE: OrgNode[] = [
  { id: "inspektur", label: "Inspektur", parent: null },
  { id: "sekretariat", label: "Sekretariat", parent: "inspektur" },
  { id: "irban1", label: "Inspektur Pembantu Wilayah I", parent: "inspektur" },
  { id: "irban2", label: "Inspektur Pembantu Wilayah II", parent: "inspektur" },
  { id: "irban3", label: "Inspektur Pembantu Wilayah III", parent: "inspektur" },
  { id: "jft", label: "Kelompok Jabatan Fungsional", parent: "inspektur" },
];

function OrgTree({ nodes }: { nodes: OrgNode[] }) {
  const root = nodes.filter((n) => !n.parent);
  const childrenOf = (id: string) => nodes.filter((n) => n.parent === id);
  return (
    <div className="flex flex-col items-center overflow-x-auto pb-4" role="tree" aria-label="Struktur organisasi">
      {root.map((r) => (
        <div key={r.id} className="flex flex-col items-center">
          <div className="rounded-xl border-2 border-gold bg-brand px-8 py-4 text-center shadow-lg">
            <Landmark className="mx-auto mb-1 h-5 w-5 text-gold" />
            <div className="font-display text-sm font-extrabold uppercase tracking-wide text-white">{r.label}</div>
          </div>
          <div className="h-6 w-0.5 bg-gold" />
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {childrenOf(r.id).map((c) => (
              <div key={c.id} className="flex flex-col items-center">
                <div className="h-4 w-0.5 bg-gold" />
                <div className="w-full max-w-[180px] rounded-lg border bg-white px-3 py-3 text-center shadow-sm transition-all hover:-translate-y-0.5 hover:border-gold">
                  <Users className="mx-auto mb-1 h-4 w-4 text-gold" />
                  <div className="text-xs font-semibold leading-tight text-brand">{c.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

export default function Profil() {
  const [tab, setTab] = useState<(typeof TABS)[number]["slug"]>("tentang");
  useReveal();
  const settings = trpc.cms.publicSettings.useQuery(undefined, { staleTime: 60_000 });
  const page = trpc.cms.page.useQuery(
    { slug: tab === "struktur" ? "tentang" : tab },
    { enabled: tab !== "struktur", staleTime: 60_000 },
  );

  const struktur = settings.data?.struktur as { nodes?: OrgNode[] } | undefined;
  const tree = struktur?.nodes?.length ? struktur.nodes : DEFAULT_TREE;

  return (
    <div>
      <PageHero
        title="Profil Inspektorat"
        subtitle="Mengenal lebih dekat Inspektorat Kabupaten Dompu: kedudukan, tugas, fungsi, dan struktur organisasi."
      />
      <section className="py-12 lg:py-16">
        <div className="container-site">
          <div className="mb-8 flex flex-wrap gap-2" role="tablist" aria-label="Menu profil">
            {TABS.map((t) => (
              <button
                key={t.slug}
                role="tab"
                aria-selected={tab === t.slug}
                onClick={() => setTab(t.slug)}
                className={`min-h-[44px] rounded-full border px-5 py-2 text-sm font-semibold transition-colors ${
                  tab === t.slug
                    ? "border-brand bg-brand text-white"
                    : "border-border bg-white text-brand hover:border-gold hover:text-gold"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="rounded-2xl border bg-white p-6 shadow-sm lg:p-10">
            {tab === "struktur" ? (
              <>
                <h2 className="mb-8 font-display text-2xl font-extrabold uppercase tracking-wide text-brand">
                  Struktur Organisasi
                </h2>
                <OrgTree nodes={tree} />
              </>
            ) : page.isLoading ? (
              <div className="space-y-3">
                <div className="h-5 w-1/3 animate-pulse rounded bg-muted" />
                <div className="h-4 w-full animate-pulse rounded bg-muted" />
                <div className="h-4 w-2/3 animate-pulse rounded bg-muted" />
              </div>
            ) : (
              <>
                <h2 className="mb-6 font-display text-2xl font-extrabold uppercase tracking-wide text-brand">
                  {page.data?.title}
                </h2>
                <PageContent content={page.data?.content} />
              </>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}

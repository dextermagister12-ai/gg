import { useEffect, useRef, useState } from "react";
import { Link } from "react-router";
import useEmblaCarousel from "embla-carousel-react";
import {
  ShieldAlert,
  Megaphone,
  FileText,
  Scale,
  ClipboardList,
  Phone,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  Newspaper,
  CalendarDays,
  MapPin,
  Clock,
  Image as ImageIcon,
} from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { formatDate, usePublicSettings, useReveal } from "@/lib/site";

const QUICK_ACCESS = [
  { icon: ShieldAlert, title: "WBS", desc: "Laporkan dugaan pelanggaran secara aman dan terlindungi.", to: "/wbs" },
  { icon: Megaphone, title: "Pengaduan Masyarakat", desc: "Salurkan pengaduan terkait penyelenggaraan pemerintahan.", to: "/pengaduan" },
  { icon: FileText, title: "Informasi Publik", desc: "Informasi publik Inspektorat Kabupaten Dompu.", to: "/informasi-publik" },
  { icon: Scale, title: "Regulasi", desc: "Peraturan dan dasar hukum pengawasan.", to: "/publikasi" },
  { icon: ClipboardList, title: "Laporan Pengawasan", desc: "Publikasi informasi dan laporan pengawasan.", to: "/pengawasan" },
  { icon: Phone, title: "Kontak", desc: "Hubungi Inspektorat Kabupaten Dompu.", to: "/kontak" },
];

const TRANSPARANSI = [
  "Program Kerja Pengawasan",
  "Laporan Hasil Pengawasan",
  "Laporan Kinerja",
  "Perjanjian Kinerja",
  "Renstra",
  "Renja",
  "IKU",
  "Evaluasi Kinerja",
  "Informasi Publik",
];

function Counter({ value }: { value: number }) {
  const [n, setN] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (!e.isIntersecting) return;
        io.disconnect();
        const start = performance.now();
        const dur = 1200;
        const tick = (t: number) => {
          const p = Math.min(1, (t - start) / dur);
          setN(Math.round(value * (1 - Math.pow(1 - p, 3))));
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      },
      { threshold: 0.4 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [value]);
  return <span ref={ref}>{n.toLocaleString("id-ID")}</span>;
}

export default function Home() {
  const { sambutan } = usePublicSettings();
  useReveal();
  const banners = trpc.cms.banners.useQuery();
  const latest = trpc.cms.newsLatest.useQuery({ limit: 4 });
  const agendas = trpc.cms.agendaList.useQuery({ upcoming: true });
  const stats = trpc.cms.publicStats.useQuery();
  const gallery = trpc.cms.gallery.useQuery({ type: "photo" });

  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true });
  const [slide, setSlide] = useState(0);

  useEffect(() => {
    if (!emblaApi) return;
    const onSelect = () => setSlide(emblaApi.selectedScrollSnap());
    emblaApi.on("select", onSelect);
    const t = setInterval(() => emblaApi.scrollNext(), 7000);
    return () => {
      emblaApi.off("select", onSelect);
      clearInterval(t);
    };
  }, [emblaApi]);

  const items = banners.data ?? [];

  return (
    <div>
      {/* ================= HERO ================= */}
      <section className="relative bg-brand-ink text-white" aria-label="Banner utama">
        <div className="overflow-hidden" ref={emblaRef}>
          <div className="flex">
            {items.map((b, i) => (
              <div key={b.id} className="relative min-w-0 flex-[0_0_100%]">
                <div className="relative h-[480px] sm:h-[540px] lg:h-[620px]">
                  {b.imageUrl && (
                    <img
                      src={b.imageUrl}
                      alt={b.title}
                      className="absolute inset-0 h-full w-full object-cover"
                      loading={i === 0 ? "eager" : "lazy"}
                    />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-r from-brand-ink/90 via-brand-ink/60 to-brand-ink/20" />
                  <div className="container-site relative flex h-full items-center">
                    <div className="max-w-2xl animate-fade-slide" key={slide}>
                      <div className="mb-4 inline-block border-y-2 border-gold px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.25em] text-gold">
                        Inspektorat Kabupaten Dompu
                      </div>
                      <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold uppercase leading-tight tracking-wide">
                        {b.title}
                      </h1>
                      {b.description && (
                        <p className="mt-4 max-w-xl text-sm sm:text-base text-white/80 leading-relaxed">
                          {b.description}
                        </p>
                      )}
                      <div className="mt-8 flex flex-wrap gap-3">
                        {b.ctaText && (
                          <Button asChild size="lg" className="h-12 bg-gold hover:bg-[#a87c22] text-white font-bold uppercase tracking-wide">
                            <Link to={b.ctaLink ?? "/profil"}>{b.ctaText}</Link>
                          </Button>
                        )}
                        <Button
                          asChild
                          size="lg"
                          variant="outline"
                          className="h-12 border-2 border-white/70 bg-transparent text-white hover:bg-white hover:text-brand font-bold uppercase tracking-wide"
                        >
                          <Link to="/wbs/lapor">
                            <ShieldAlert className="mr-2 h-5 w-5" /> Laporkan Dugaan Pelanggaran
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            {items.length === 0 && (
              <div className="relative min-w-0 flex-[0_0_100%]">
                <div className="flex h-[420px] items-center bg-gradient-to-br from-brand to-brand-ink">
                  <div className="container-site">
                    <h1 className="font-display text-4xl font-extrabold uppercase">
                      Inspektorat Kabupaten Dompu
                    </h1>
                    <p className="mt-3 text-white/75">Profesional, Integritas, Akuntabilitas</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        {items.length > 1 && (
          <>
            <button
              onClick={() => emblaApi?.scrollPrev()}
              aria-label="Slide sebelumnya"
              className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/15 p-3 backdrop-blur hover:bg-gold transition-colors min-h-[44px] min-w-[44px]"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              onClick={() => emblaApi?.scrollNext()}
              aria-label="Slide berikutnya"
              className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/15 p-3 backdrop-blur hover:bg-gold transition-colors min-h-[44px] min-w-[44px]"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
            <div className="absolute bottom-5 left-1/2 flex -translate-x-1/2 gap-2">
              {items.map((_, i) => (
                <button
                  key={i}
                  aria-label={`Ke slide ${i + 1}`}
                  onClick={() => emblaApi?.scrollTo(i)}
                  className={`h-2 rounded-full transition-all ${i === slide ? "w-8 bg-gold" : "w-2 bg-white/50"}`}
                />
              ))}
            </div>
          </>
        )}
      </section>

      {/* ================= QUICK ACCESS ================= */}
      <section className="relative z-10 -mt-14 pb-6" aria-label="Akses cepat">
        <div className="container-site grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6 lg:gap-4">
          {QUICK_ACCESS.map((q, i) => (
            <Link
              key={q.title}
              to={q.to}
              className="reveal group rounded-xl border border-border bg-white p-4 lg:p-5 shadow-lg shadow-brand/5 transition-all hover:-translate-y-1 hover:border-gold hover:shadow-xl"
              style={{ transitionDelay: `${i * 40}ms` }}
            >
              <q.icon className="h-8 w-8 text-gold transition-transform group-hover:scale-110" />
              <div className="mt-3 font-display text-sm font-bold uppercase tracking-wide text-brand">
                {q.title}
              </div>
              <p className="mt-1 hidden text-xs text-muted-foreground lg:block">{q.desc}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* ================= SAMBUTAN ================= */}
      <section className="bg-paper py-16 lg:py-24" aria-label="Sambutan Inspektur">
        <div className="container-site grid items-center gap-10 lg:grid-cols-[320px_1fr]">
          <div className="reveal mx-auto w-full max-w-xs">
            <div className="rounded-2xl border-4 border-gold/70 bg-white p-2 shadow-xl">
              {sambutan.photoUrl ? (
                <img src={sambutan.photoUrl} alt={`Foto ${sambutan.name ?? "Inspektur"}`} className="aspect-[3/4] w-full rounded-xl object-cover" loading="lazy" />
              ) : (
                <div className="aspect-[3/4] w-full rounded-xl bg-brand/10" />
              )}
            </div>
          </div>
          <div className="reveal">
            <div className="border-y-2 border-brand/20 py-2 text-xs font-bold uppercase tracking-[0.25em] text-gold">
              Sambutan Inspektur Kabupaten Dompu
            </div>
            <h2 className="mt-4 font-display text-2xl font-extrabold uppercase tracking-wide text-brand lg:text-3xl">
              {sambutan.name ?? "Inspektur Kabupaten Dompu"}
            </h2>
            <div className="text-sm font-semibold text-muted-foreground">{sambutan.position}</div>
            <p className="mt-5 whitespace-pre-line leading-relaxed text-foreground/85">
              {sambutan.text}
            </p>
            <Button asChild variant="outline" className="mt-6 border-brand text-brand hover:bg-brand hover:text-white">
              <Link to="/profil">
                Profil Inspektorat <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* ================= STATISTIK ================= */}
      <section className="bg-brand py-14 text-white" aria-label="Statistik">
        <div className="container-site grid grid-cols-2 gap-6 text-center sm:grid-cols-3 lg:grid-cols-5">
          {[
            { label: "Berita", value: stats.data?.news ?? 0 },
            { label: "Publikasi & Dokumen", value: stats.data?.documents ?? 0 },
            { label: "Foto Kegiatan", value: stats.data?.gallery ?? 0 },
            { label: "Agenda Kegiatan", value: stats.data?.agendas ?? 0 },
            { label: "Laporan WBS Diterima", value: stats.data?.reports ?? 0 },
          ].map((s) => (
            <div key={s.label}>
              <div className="font-display text-3xl lg:text-4xl font-extrabold text-gold">
                <Counter value={s.value} />
              </div>
              <div className="mt-1 text-xs uppercase tracking-wider text-white/70">{s.label}</div>
            </div>
          ))}
        </div>
        <p className="container-site mt-4 text-center text-[11px] text-white/50">
          Statistik WBS hanya menampilkan data agregat tanpa informasi yang dapat mengidentifikasi pelapor maupun laporan.
        </p>
      </section>

      {/* ================= BERITA ================= */}
      <section className="py-16 lg:py-20" aria-label="Berita terbaru">
        <div className="container-site">
          <div className="reveal mb-8 flex items-end justify-between gap-4">
            <div>
              <div className="border-y-2 border-brand/20 py-1.5 text-xs font-bold uppercase tracking-[0.25em] text-gold">
                Kabar Terkini
              </div>
              <h2 className="mt-3 font-display text-2xl font-extrabold uppercase tracking-wide text-brand lg:text-3xl">
                Berita & Kegiatan
              </h2>
            </div>
            <Button asChild variant="ghost" className="text-brand hover:text-gold">
              <Link to="/berita">
                Semua Berita <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {(latest.data ?? []).map((n) => (
              <Link
                key={n.id}
                to={`/berita/${n.slug}`}
                className="reveal group overflow-hidden rounded-xl border bg-white shadow-sm transition-all hover:-translate-y-1 hover:shadow-lg"
              >
                <div className="aspect-[16/9] overflow-hidden bg-muted">
                  {n.imageUrl ? (
                    <img src={n.imageUrl} alt={n.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                  ) : (
                    <div className="flex h-full items-center justify-center">
                      <Newspaper className="h-10 w-10 text-muted-foreground/40" />
                    </div>
                  )}
                </div>
                <div className="p-4">
                  <div className="flex items-center gap-2 text-[11px] uppercase tracking-wide">
                    <span className="rounded-full bg-gold/15 px-2 py-0.5 font-semibold text-gold">{n.category}</span>
                    <span className="text-muted-foreground">{formatDate(n.publishedAt)}</span>
                  </div>
                  <h3 className="mt-2 line-clamp-2 font-display text-sm font-bold leading-snug text-brand group-hover:text-gold">
                    {n.title}
                  </h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ================= AGENDA & TRANSPARANSI ================= */}
      <section className="bg-paper py-16 lg:py-20" aria-label="Agenda dan transparansi">
        <div className="container-site grid gap-12 lg:grid-cols-2">
          <div className="reveal">
            <div className="border-y-2 border-brand/20 py-1.5 text-xs font-bold uppercase tracking-[0.25em] text-gold">
              Agenda Inspektorat
            </div>
            <h2 className="mt-3 font-display text-2xl font-extrabold uppercase tracking-wide text-brand">
              Agenda Terdekat
            </h2>
            <div className="mt-6 space-y-4">
              {(agendas.data ?? []).slice(0, 4).map((a) => (
                <div key={a.id} className="flex gap-4 rounded-xl border bg-white p-4 shadow-sm">
                  <div className="flex h-16 w-16 shrink-0 flex-col items-center justify-center rounded-lg bg-brand text-white">
                    <span className="font-display text-2xl font-extrabold leading-none text-gold">
                      {new Date(a.eventDate).getDate()}
                    </span>
                    <span className="text-[10px] uppercase">
                      {new Date(a.eventDate).toLocaleDateString("id-ID", { month: "short" })}
                    </span>
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-display text-sm font-bold leading-snug text-brand">{a.title}</h3>
                    <div className="mt-1.5 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      {a.eventTime && (
                        <span className="flex items-center gap-1">
                          <Clock className="h-3.5 w-3.5" /> {a.eventTime}
                        </span>
                      )}
                      {a.location && (
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3.5 w-3.5" /> {a.location}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <Button asChild variant="outline" className="mt-5 border-brand text-brand hover:bg-brand hover:text-white">
              <Link to="/agenda">
                <CalendarDays className="mr-2 h-4 w-4" /> Lihat Semua Agenda
              </Link>
            </Button>
          </div>

          <div className="reveal">
            <div className="border-y-2 border-brand/20 py-1.5 text-xs font-bold uppercase tracking-[0.25em] text-gold">
              Transparansi dan Akuntabilitas
            </div>
            <h2 className="mt-3 font-display text-2xl font-extrabold uppercase tracking-wide text-brand">
              Dokumen Kinerja
            </h2>
            <div className="mt-6 grid grid-cols-1 gap-2 sm:grid-cols-2">
              {TRANSPARANSI.map((t) => (
                <Link
                  key={t}
                  to="/publikasi"
                  className="flex items-center justify-between rounded-lg border bg-white px-4 py-3 text-sm font-medium text-brand shadow-sm transition-colors hover:border-gold hover:text-gold"
                >
                  {t}
                  <ChevronRight className="h-4 w-4 text-gold" />
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ================= GALERI PREVIEW ================= */}
      <section className="py-16 lg:py-20" aria-label="Galeri">
        <div className="container-site">
          <div className="reveal mb-8 flex items-end justify-between gap-4">
            <div>
              <div className="border-y-2 border-brand/20 py-1.5 text-xs font-bold uppercase tracking-[0.25em] text-gold">
                Dokumentasi
              </div>
              <h2 className="mt-3 font-display text-2xl font-extrabold uppercase tracking-wide text-brand">
                Galeri Kegiatan
              </h2>
            </div>
            <Button asChild variant="ghost" className="text-brand hover:text-gold">
              <Link to="/galeri">
                Semua Galeri <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {(gallery.data ?? []).slice(0, 4).map((g) => (
              <Link key={g.id} to="/galeri" className="reveal group relative aspect-[4/3] overflow-hidden rounded-xl bg-muted">
                {g.fileUrl ? (
                  <img src={g.fileUrl} alt={g.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                ) : (
                  <div className="flex h-full items-center justify-center">
                    <ImageIcon className="h-8 w-8 text-muted-foreground/40" />
                  </div>
                )}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-brand-ink/90 to-transparent p-3 pt-8">
                  <p className="text-xs font-semibold text-white line-clamp-1">{g.title}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ================= CTA WBS ================= */}
      <section className="bg-gradient-to-br from-brand to-brand-ink py-16 text-white" aria-label="Ajakan melapor">
        <div className="container-site text-center">
          <ShieldAlert className="mx-auto h-12 w-12 text-gold" />
          <h2 className="mx-auto mt-4 max-w-2xl font-display text-2xl font-extrabold uppercase tracking-wide lg:text-3xl">
            Saksikan Pelanggaran? Laporkan Melalui WBS
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-sm text-white/75">
            Whistleblowing System adalah sarana bagi masyarakat dan aparatur untuk menyampaikan dugaan pelanggaran secara aman. Identitas pelapor dapat dirahasiakan.
          </p>
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <Button asChild size="lg" className="h-12 bg-gold hover:bg-[#a87c22] font-bold uppercase tracking-wide text-white">
              <Link to="/wbs/lapor">Buat Laporan</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="h-12 border-2 border-white/60 bg-transparent text-white hover:bg-white hover:text-brand font-bold uppercase tracking-wide">
              <Link to="/wbs/status">Cek Status Laporan</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}

import { useState } from "react";
import { Link } from "react-router";
import { Megaphone, ShieldAlert, Send } from "lucide-react";
import PageHero from "@/components/PageHero";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { PageContent } from "@/lib/site";
import { toast } from "sonner";

export default function Pengaduan() {
  const info = trpc.cms.page.useQuery({ slug: "pengaduan-info" }, { staleTime: 60_000 });
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "", message: "" });
  const [ticket, setTicket] = useState<string | null>(null);
  const submit = trpc.cms.submitComplaint.useMutation({
    onSuccess: (d) => {
      setTicket(d.ticket);
      setForm({ name: "", email: "", phone: "", subject: "", message: "" });
    },
    onError: (e) => toast.error(e.message),
  });

  return (
    <div>
      <PageHero title="Pengaduan Masyarakat" subtitle="Salurkan pengaduan terkait penyelenggaraan pemerintahan daerah di Kabupaten Dompu." />
      <section className="py-12 lg:py-16">
        <div className="container-site grid gap-10 lg:grid-cols-2">
          <div>
            <div className="rounded-2xl border bg-white p-6 shadow-sm lg:p-8">
              <PageContent content={info.data?.content} />
            </div>
            <div className="mt-6 rounded-2xl border-2 border-gold/60 bg-brand p-6 text-white shadow-sm lg:p-8">
              <ShieldAlert className="h-9 w-9 text-gold" />
              <h3 className="mt-3 font-display text-lg font-extrabold uppercase tracking-wide">
                Melaporkan Dugaan Pelanggaran?
              </h3>
              <p className="mt-2 text-sm text-white/80">
                Untuk laporan dugaan korupsi, gratifikasi, penyalahgunaan wewenang, dan pelanggaran lainnya, gunakan
                Whistleblowing System agar identitas Anda terlindungi.
              </p>
              <Button asChild className="mt-5 bg-gold text-white hover:bg-[#a87c22]">
                <Link to="/wbs">Buka Whistleblowing System</Link>
              </Button>
            </div>
          </div>

          <div className="rounded-2xl border bg-white p-6 shadow-sm lg:p-8">
            <div className="flex items-center gap-3">
              <Megaphone className="h-6 w-6 text-gold" />
              <h2 className="font-display text-xl font-extrabold uppercase tracking-wide text-brand">
                Formulir Pengaduan
              </h2>
            </div>
            {ticket ? (
              <div className="mt-6 rounded-xl border border-green-300 bg-green-50 p-6 text-center">
                <p className="font-semibold text-green-800">Terima kasih. Pengaduan Anda telah diterima.</p>
                <p className="mt-2 text-sm text-green-700">Nomor tiket pengaduan Anda:</p>
                <p className="mt-1 font-mono text-lg font-bold text-green-900">{ticket}</p>
                <Button variant="outline" className="mt-5" onClick={() => setTicket(null)}>
                  Kirim Pengaduan Lain
                </Button>
              </div>
            ) : (
              <form
                className="mt-6 space-y-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  submit.mutate(form);
                }}
              >
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="p-nama">Nama Lengkap *</Label>
                    <Input id="p-nama" required minLength={2} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="h-11" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="p-hp">Nomor HP</Label>
                    <Input id="p-hp" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="h-11" />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="p-email">Email</Label>
                  <Input id="p-email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="h-11" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="p-subjek">Subjek Pengaduan *</Label>
                  <Input id="p-subjek" required minLength={4} value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} className="h-11" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="p-isi">Uraian Pengaduan *</Label>
                  <Textarea id="p-isi" required minLength={10} rows={6} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="Uraikan pengaduan Anda secara jelas..." />
                </div>
                <Button type="submit" disabled={submit.isPending} className="h-11 bg-brand text-white hover:bg-brand-ink">
                  <Send className="mr-2 h-4 w-4" /> {submit.isPending ? "Mengirim..." : "Kirim Pengaduan"}
                </Button>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}

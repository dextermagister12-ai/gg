import PageHero from "@/components/PageHero";
import DocList from "@/components/DocList";
import { PUBLIKASI_CATEGORIES } from "@contracts/wbs";

export default function Publikasi() {
  return (
    <div>
      <PageHero
        title="Publikasi"
        subtitle="Pusat publikasi Inspektorat Kabupaten Dompu: laporan, regulasi, pedoman, SOP, surat edaran, dan dokumen pengawasan."
      />
      <section className="py-12 lg:py-16">
        <div className="container-site">
          <DocList section="publikasi" categories={PUBLIKASI_CATEGORIES} />
        </div>
      </section>
    </div>
  );
}

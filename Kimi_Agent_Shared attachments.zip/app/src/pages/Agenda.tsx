import { CalendarDays, Clock, MapPin } from "lucide-react";
import PageHero from "@/components/PageHero";
import { trpc } from "@/providers/trpc";
import { formatDate } from "@/lib/site";

export default function Agenda() {
  const list = trpc.cms.agendaList.useQuery({ upcoming: false });

  return (
    <div>
      <PageHero title="Agenda Inspektorat" subtitle="Jadwal kegiatan Inspektorat Kabupaten Dompu." />
      <section className="py-12 lg:py-16">
        <div className="container-site max-w-4xl">
          {list.isLoading ? (
            <div className="space-y-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="h-24 animate-pulse rounded-xl bg-muted" />
              ))}
            </div>
          ) : (list.data?.length ?? 0) === 0 ? (
            <p className="rounded-xl border bg-white p-10 text-center text-sm text-muted-foreground">
              Belum ada agenda terjadwal.
            </p>
          ) : (
            <ol className="relative space-y-6 border-l-2 border-gold/50 pl-6">
              {list.data?.map((a) => (
                <li key={a.id} className="relative">
                  <span className="absolute -left-[31px] top-1.5 h-3.5 w-3.5 rounded-full border-2 border-gold bg-white" />
                  <div className="rounded-xl border bg-white p-5 shadow-sm">
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1.5 font-semibold text-gold">
                        <CalendarDays className="h-4 w-4" /> {formatDate(a.eventDate)}
                      </span>
                      {a.eventTime && (
                        <span className="flex items-center gap-1.5">
                          <Clock className="h-4 w-4" /> {a.eventTime}
                        </span>
                      )}
                      {a.location && (
                        <span className="flex items-center gap-1.5">
                          <MapPin className="h-4 w-4" /> {a.location}
                        </span>
                      )}
                    </div>
                    <h2 className="mt-2 font-display text-base font-bold text-brand">{a.title}</h2>
                    {a.description && <p className="mt-1.5 text-sm text-muted-foreground">{a.description}</p>}
                  </div>
                </li>
              ))}
            </ol>
          )}
        </div>
      </section>
    </div>
  );
}

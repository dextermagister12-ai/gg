import { useEffect, useState } from "react";
import { Link } from "react-router";
import { CheckCircle2, ChevronLeft, ChevronRight, Copy, FileUp, ShieldAlert, Trash2 } from "lucide-react";
import PageHero from "@/components/PageHero";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { VIOLATION_TYPES, EVIDENCE_MAX_FILES } from "@contracts/wbs";
import { formatDateTime } from "@/lib/site";
import { toast } from "sonner";

type Uploaded = { key: string; fileName: string; size: number; fileType: string };

const STEPS = ["Identitas Pelapor", "Informasi Terlapor", "Detail Pelanggaran", "Bukti & Kirim"];

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(",")[1]);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

export default function WbsLapor() {
  const [step, setStep] = useState(0);
  const [anonymous, setAnonymous] = useState(false);
  const [confidential, setConfidential] = useState(false);
  const [reporter, setReporter] = useState({ name: "", nik: "", email: "", phone: "", address: "" });
  const [reported, setReported] = useState({ person: "", position: "", agency: "", unit: "" });
  const [detail, setDetail] = useState({
    violationType: "",
    incidentDate: "",
    incidentLocation: "",
    chronology: "",
    partiesInvolved: "",
    estimatedLoss: "",
  });
  const [files, setFiles] = useState<Uploaded[]>([]);
  const [uploading, setUploading] = useState(false);
  const [captchaAnswer, setCaptchaAnswer] = useState("");
  const [done, setDone] = useState<{
    registrationNumber: string;
    token: string;
    createdAt: Date;
    status: string;
  } | null>(null);

  const captcha = trpc.wbs.getCaptcha.useQuery(undefined, { staleTime: 0, refetchOnWindowFocus: false });
  const uploadMut = trpc.wbs.uploadEvidence.useMutation({
    onError: (e) => toast.error(e.message),
  });
  const submitMut = trpc.wbs.submit.useMutation({
    onSuccess: (d) => {
      setDone(d);
      window.scrollTo({ top: 0, behavior: "smooth" });
    },
    onError: (e) => {
      toast.error(e.message);
      captcha.refetch();
      setCaptchaAnswer("");
    },
  });

  useEffect(() => {
    if (anonymous) setReporter({ name: "", nik: "", email: "", phone: "", address: "" });
  }, [anonymous]);

  const onPickFiles = async (list: FileList | null) => {
    if (!list) return;
    const arr = Array.from(list).slice(0, EVIDENCE_MAX_FILES - files.length);
    setUploading(true);
    for (const f of arr) {
      if (f.size > 5 * 1024 * 1024) {
        toast.error(`Berkas ${f.name} melebihi 5 MB`);
        continue;
      }
      try {
        const b64 = await fileToBase64(f);
        const res = await uploadMut.mutateAsync({ name: f.name, contentBase64: b64, contentType: f.type || undefined });
        setFiles((prev) => [...prev, { key: res.key, fileName: res.fileName, size: res.size, fileType: res.fileType }]);
      } catch {
        /* error sudah di-toast */
      }
    }
    setUploading(false);
  };

  const canNext =
    step === 0
      ? anonymous || reporter.name.trim().length >= 2
      : step === 1
        ? reported.person.trim().length >= 2
        : step === 2
          ? detail.violationType !== "" && detail.chronology.trim().length >= 30
          : true;

  if (done) {
    return (
      <div>
        <PageHero title="Laporan Terkirim" crumb={[{ label: "WBS", to: "/wbs" }]} />
        <section className="py-12 lg:py-20">
          <div className="container-site max-w-xl">
            <div className="rounded-2xl border-2 border-green-500/50 bg-white p-8 text-center shadow-lg">
              <CheckCircle2 className="mx-auto h-16 w-16 text-green-600" />
              <h2 className="mt-4 font-display text-2xl font-extrabold uppercase text-brand">
                Terima kasih. Laporan Anda telah diterima.
              </h2>
              <div className="mt-6 space-y-3 rounded-xl bg-paper p-5 text-left">
                <div>
                  <div className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Nomor Registrasi</div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-lg font-bold text-brand">{done.registrationNumber}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        navigator.clipboard.writeText(done.registrationNumber);
                        toast.success("Nomor registrasi disalin");
                      }}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div>
                  <div className="text-xs font-bold uppercase tracking-wide text-muted-foreground">Kode Pelapor (rahasia)</div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-lg font-bold text-gold">{done.token}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        navigator.clipboard.writeText(done.token);
                        toast.success("Kode pelapor disalin");
                      }}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Tanggal Laporan</span>
                  <span className="font-medium">{formatDateTime(done.createdAt)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Status</span>
                  <span className="rounded-full bg-gold/15 px-3 py-0.5 text-xs font-bold uppercase text-gold">Laporan Diterima</span>
                </div>
              </div>
              <p className="mt-5 rounded-lg border border-amber-300 bg-amber-50 p-4 text-left text-xs leading-relaxed text-amber-800">
                <strong>Penting:</strong> Simpan nomor registrasi dan kode pelapor dengan baik. Kode pelapor hanya
                ditampilkan sekali dan diperlukan untuk mengecek status laporan Anda.
              </p>
              <div className="mt-6 flex flex-wrap justify-center gap-3">
                <Button asChild className="bg-brand text-white hover:bg-brand-ink">
                  <Link to="/wbs/status">Cek Status Laporan</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link to="/">Kembali ke Beranda</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div>
      <PageHero
        title="Buat Laporan WBS"
        crumb={[{ label: "WBS", to: "/wbs" }]}
        subtitle="Laporkan dugaan pelanggaran secara aman. Identitas Anda dapat dirahasiakan."
      />
      <section className="py-12 lg:py-16">
        <div className="container-site max-w-3xl">
          {/* Stepper */}
          <ol className="mb-10 flex items-center" aria-label="Tahapan pengisian laporan">
            {STEPS.map((s, i) => (
              <li key={s} className="flex flex-1 items-center last:flex-none">
                <div className="flex flex-col items-center">
                  <span
                    className={`flex h-10 w-10 items-center justify-center rounded-full border-2 font-display text-sm font-bold ${
                      i < step
                        ? "border-gold bg-gold text-white"
                        : i === step
                          ? "border-brand bg-brand text-white"
                          : "border-border bg-white text-muted-foreground"
                    }`}
                  >
                    {i + 1}
                  </span>
                  <span className={`mt-2 hidden text-[11px] font-semibold uppercase tracking-wide sm:block ${i === step ? "text-brand" : "text-muted-foreground"}`}>
                    {s}
                  </span>
                </div>
                {i < STEPS.length - 1 && <div className={`mx-2 h-0.5 flex-1 ${i < step ? "bg-gold" : "bg-border"}`} />}
              </li>
            ))}
          </ol>

          <div className="rounded-2xl border bg-white p-6 shadow-sm lg:p-8">
            {step === 0 && (
              <div className="space-y-5">
                <h2 className="flex items-center gap-2 font-display text-lg font-extrabold uppercase tracking-wide text-brand">
                  <ShieldAlert className="h-5 w-5 text-gold" /> Identitas Pelapor
                </h2>
                <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-gold/50 bg-gold/10 p-4">
                  <Checkbox
                    checked={anonymous}
                    onCheckedChange={(v) => setAnonymous(v === true)}
                    className="mt-1"
                    aria-label="Saya ingin melaporkan secara anonim"
                  />
                  <span>
                    <span className="block text-sm font-bold text-brand">Saya ingin melaporkan secara anonim</span>
                    <span className="text-xs text-muted-foreground">
                      Jika dipilih, identitas pelapor tidak wajib diisi dan tidak disimpan oleh sistem.
                    </span>
                  </span>
                </label>
                {!anonymous && (
                  <>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-1.5">
                        <Label htmlFor="r-nama">Nama Lengkap *</Label>
                        <Input id="r-nama" value={reporter.name} onChange={(e) => setReporter({ ...reporter, name: e.target.value })} className="h-11" />
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="r-nik">NIK</Label>
                        <Input id="r-nik" inputMode="numeric" value={reporter.nik} onChange={(e) => setReporter({ ...reporter, nik: e.target.value })} className="h-11" />
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="r-email">Email</Label>
                        <Input id="r-email" type="email" value={reporter.email} onChange={(e) => setReporter({ ...reporter, email: e.target.value })} className="h-11" />
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="r-hp">Nomor HP</Label>
                        <Input id="r-hp" inputMode="tel" value={reporter.phone} onChange={(e) => setReporter({ ...reporter, phone: e.target.value })} className="h-11" />
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="r-alamat">Alamat</Label>
                      <Textarea id="r-alamat" rows={2} value={reporter.address} onChange={(e) => setReporter({ ...reporter, address: e.target.value })} />
                    </div>
                    <label className="flex cursor-pointer items-start gap-3 rounded-xl border p-4">
                      <Checkbox
                        checked={confidential}
                        onCheckedChange={(v) => setConfidential(v === true)}
                        className="mt-1"
                        aria-label="Pelapor ingin identitasnya dirahasiakan"
                      />
                      <span>
                        <span className="block text-sm font-bold text-brand">Saya ingin identitas saya dirahasiakan</span>
                        <span className="text-xs text-muted-foreground">
                          Identitas hanya dapat diakses oleh pejabat berwenang dan tidak ditampilkan kepada publik.
                        </span>
                      </span>
                    </label>
                  </>
                )}
              </div>
            )}

            {step === 1 && (
              <div className="space-y-5">
                <h2 className="font-display text-lg font-extrabold uppercase tracking-wide text-brand">Informasi Terlapor</h2>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="t-nama">Nama Terlapor *</Label>
                    <Input id="t-nama" required value={reported.person} onChange={(e) => setReported({ ...reported, person: e.target.value })} className="h-11" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="t-jabatan">Jabatan</Label>
                    <Input id="t-jabatan" value={reported.position} onChange={(e) => setReported({ ...reported, position: e.target.value })} className="h-11" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="t-opd">Instansi / OPD</Label>
                    <Input id="t-opd" value={reported.agency} onChange={(e) => setReported({ ...reported, agency: e.target.value })} className="h-11" placeholder="Contoh: Dinas Pendidikan dan Kebudayaan" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="t-unit">Unit Kerja</Label>
                    <Input id="t-unit" value={reported.unit} onChange={(e) => setReported({ ...reported, unit: e.target.value })} className="h-11" />
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-5">
                <h2 className="font-display text-lg font-extrabold uppercase tracking-wide text-brand">Detail Pelanggaran</h2>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label>Jenis Dugaan Pelanggaran *</Label>
                    <Select value={detail.violationType} onValueChange={(v) => setDetail({ ...detail, violationType: v })}>
                      <SelectTrigger className="h-11" aria-label="Jenis dugaan pelanggaran">
                        <SelectValue placeholder="Pilih jenis pelanggaran" />
                      </SelectTrigger>
                      <SelectContent>
                        {VIOLATION_TYPES.map((v) => (
                          <SelectItem key={v} value={v}>
                            {v}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="d-tgl">Tanggal Kejadian</Label>
                    <Input id="d-tgl" type="date" value={detail.incidentDate} onChange={(e) => setDetail({ ...detail, incidentDate: e.target.value })} className="h-11" />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-lokasi">Lokasi Kejadian</Label>
                  <Input id="d-lokasi" value={detail.incidentLocation} onChange={(e) => setDetail({ ...detail, incidentLocation: e.target.value })} className="h-11" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-kronologi">Kronologi * (minimal 30 karakter)</Label>
                  <Textarea id="d-kronologi" rows={6} value={detail.chronology} onChange={(e) => setDetail({ ...detail, chronology: e.target.value })} placeholder="Uraikan kronologi kejadian secara runtut dan jelas: apa yang terjadi, kapan, di mana, dan bagaimana." />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-pihak">Pihak yang Terlibat</Label>
                  <Textarea id="d-pihak" rows={2} value={detail.partiesInvolved} onChange={(e) => setDetail({ ...detail, partiesInvolved: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="d-rugi">Perkiraan Kerugian Negara/Daerah (jika diketahui)</Label>
                  <Input id="d-rugi" value={detail.estimatedLoss} onChange={(e) => setDetail({ ...detail, estimatedLoss: e.target.value })} className="h-11" placeholder="Contoh: Rp 50.000.000" />
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-5">
                <h2 className="font-display text-lg font-extrabold uppercase tracking-wide text-brand">Unggah Bukti & Kirim</h2>
                <div>
                  <Label>Unggah Bukti (opsional, maks. {EVIDENCE_MAX_FILES} berkas, masing-masing 5 MB)</Label>
                  <p className="mb-2 text-xs text-muted-foreground">Format: PDF, JPG, PNG, DOC, DOCX, XLS, XLSX, ZIP</p>
                  <label
                    className={`flex min-h-[120px] cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-brand/30 bg-paper p-6 text-center transition-colors hover:border-gold ${uploading ? "opacity-60" : ""}`}
                  >
                    <FileUp className="h-8 w-8 text-gold" />
                    <span className="text-sm font-medium text-brand">
                      {uploading ? "Mengunggah..." : "Klik untuk memilih berkas"}
                    </span>
                    <input
                      type="file"
                      multiple
                      accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.xls,.xlsx,.zip"
                      className="hidden"
                      disabled={uploading || files.length >= EVIDENCE_MAX_FILES}
                      onChange={(e) => {
                        void onPickFiles(e.target.files);
                        e.target.value = "";
                      }}
                    />
                  </label>
                  {files.length > 0 && (
                    <ul className="mt-3 space-y-2">
                      {files.map((f) => (
                        <li key={f.key} className="flex items-center justify-between rounded-lg border bg-white px-4 py-2.5 text-sm">
                          <span className="truncate">
                            {f.fileName} <span className="text-xs text-muted-foreground">({Math.round(f.size / 1024)} KB)</span>
                          </span>
                          <button
                            type="button"
                            onClick={() => setFiles(files.filter((x) => x.key !== f.key))}
                            className="ml-3 p-2 text-destructive min-h-[44px] min-w-[44px] flex items-center justify-center"
                            aria-label={`Hapus berkas ${f.fileName}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>

                <div className="rounded-xl border bg-paper p-5">
                  <Label htmlFor="captcha">Verifikasi: {captcha.data?.question ?? "Memuat..."}</Label>
                  <Input
                    id="captcha"
                    inputMode="numeric"
                    className="mt-2 h-11 w-40"
                    value={captchaAnswer}
                    onChange={(e) => setCaptchaAnswer(e.target.value)}
                    placeholder="Jawaban"
                  />
                </div>
              </div>
            )}

            <div className="mt-8 flex items-center justify-between border-t pt-6">
              <Button variant="outline" onClick={() => setStep(step - 1)} disabled={step === 0} className="h-11">
                <ChevronLeft className="mr-1 h-4 w-4" /> Kembali
              </Button>
              {step < 3 ? (
                <Button onClick={() => setStep(step + 1)} disabled={!canNext} className="h-11 bg-brand text-white hover:bg-brand-ink">
                  Lanjut <ChevronRight className="ml-1 h-4 w-4" />
                </Button>
              ) : (
                <Button
                  disabled={submitMut.isPending || uploading || !captchaAnswer.trim()}
                  onClick={() =>
                    submitMut.mutate({
                      captchaId: captcha.data?.id ?? "",
                      captchaAnswer: Number(captchaAnswer),
                      anonymous,
                      confidential,
                      reporterName: reporter.name || undefined,
                      reporterNik: reporter.nik || undefined,
                      reporterEmail: reporter.email || undefined,
                      reporterPhone: reporter.phone || undefined,
                      reporterAddress: reporter.address || undefined,
                      reportedPerson: reported.person,
                      reportedPosition: reported.position || undefined,
                      reportedAgency: reported.agency || undefined,
                      reportedUnit: reported.unit || undefined,
                      violationType: detail.violationType as (typeof VIOLATION_TYPES)[number],
                      incidentDate: detail.incidentDate || undefined,
                      incidentLocation: detail.incidentLocation || undefined,
                      chronology: detail.chronology,
                      partiesInvolved: detail.partiesInvolved || undefined,
                      estimatedLoss: detail.estimatedLoss || undefined,
                      attachments: files.map((f) => ({ key: f.key, fileName: f.fileName, fileType: f.fileType, fileSize: f.size })),
                    })
                  }
                  className="h-11 bg-gold px-8 font-bold uppercase tracking-wide text-white hover:bg-[#a87c22]"
                >
                  {submitMut.isPending ? "Mengirim..." : "Kirim Laporan"}
                </Button>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

import PageHero from "@/components/PageHero";
import DocList from "@/components/DocList";
import { DOWNLOAD_CATEGORIES } from "@contracts/wbs";

export default function Download() {
  return (
    <div>
      <PageHero
        title="Pusat Download"
        subtitle="Unduh regulasi, peraturan, SOP, laporan, formulir, pedoman, dan dokumen publik lainnya."
      />
      <section className="py-12 lg:py-16">
        <div className="container-site">
          <DocList section="download" categories={DOWNLOAD_CATEGORIES} />
        </div>
      </section>
    </div>
  );
}

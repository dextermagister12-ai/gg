import PageHero from "@/components/PageHero";
import DocList from "@/components/DocList";
import { trpc } from "@/providers/trpc";
import { PageContent } from "@/lib/site";

export default function Pengawasan() {
  const page = trpc.cms.page.useQuery({ slug: "pengawasan" }, { staleTime: 60_000 });

  return (
    <div>
      <PageHero
        title="Pengawasan"
        subtitle="Program kerja pengawasan dan publikasi hasil pengawasan Inspektorat Kabupaten Dompu."
      />
      <section className="py-12 lg:py-16">
        <div className="container-site">
          <div className="mb-10 rounded-2xl border bg-white p-6 shadow-sm lg:p-10">
            <PageContent content={page.data?.content} />
          </div>
          <h2 className="mb-6 font-display text-xl font-extrabold uppercase tracking-wide text-brand">
            Dokumen Pengawasan
          </h2>
          <DocList section="publikasi" categories={["Dokumen Pengawasan", "Laporan", "Publikasi Kinerja"]} />
        </div>
      </section>
    </div>
  );
}

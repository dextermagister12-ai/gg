import type { ReactNode } from "react";
import { Link } from "react-router";
import { ChevronRight } from "lucide-react";

export default function PageHero({
  title,
  subtitle,
  crumb,
}: {
  title: string;
  subtitle?: string;
  crumb?: { label: string; to: string }[];
}) {
  return (
    <section className="bg-gradient-to-br from-brand to-brand-ink py-12 text-white lg:py-16">
      <div className="container-site">
        <nav className="mb-3 flex items-center gap-1.5 text-xs text-white/60" aria-label="Breadcrumb">
          <Link to="/" className="hover:text-gold">
            Beranda
          </Link>
          {(crumb ?? []).map((c) => (
            <span key={c.to} className="flex items-center gap-1.5">
              <ChevronRight className="h-3 w-3" />
              <Link to={c.to} className="hover:text-gold">
                {c.label}
              </Link>
            </span>
          ))}
          <ChevronRight className="h-3 w-3" />
          <span className="text-gold">{title}</span>
        </nav>
        <h1 className="font-display text-3xl font-extrabold uppercase tracking-wide lg:text-4xl">{title}</h1>
        {subtitle && <p className="mt-2 max-w-2xl text-sm text-white/75">{subtitle}</p>}
      </div>
    </section>
  );
}

export function Section({ children }: { children: ReactNode }) {
  return <section className="py-12 lg:py-16">{children}</section>;
}

import { useEffect, useState } from "react";
import { Link, NavLink, Outlet, useNavigate } from "react-router";
import {
  Menu,
  Search,
  ShieldAlert,
  Lock,
  Phone,
  Mail,
  MapPin,
  Facebook,
  Instagram,
  Youtube,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Emblem, usePublicSettings } from "@/lib/site";

const NAV = [
  { to: "/", label: "Beranda" },
  { to: "/profil", label: "Profil" },
  { to: "/informasi-publik", label: "Informasi Publik" },
  { to: "/pengawasan", label: "Pengawasan" },
  { to: "/pengaduan", label: "Pengaduan & WBS" },
  { to: "/berita", label: "Berita" },
  { to: "/publikasi", label: "Publikasi" },
  { to: "/kontak", label: "Kontak" },
];

function SearchDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [q, setQ] = useState("");
  const navigate = useNavigate();
  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display uppercase tracking-wide text-brand">
            Pencarian
          </DialogTitle>
        </DialogHeader>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (q.trim().length >= 2) {
              onClose();
              navigate(`/cari?q=${encodeURIComponent(q.trim())}`);
            }
          }}
          className="flex gap-2"
        >
          <Input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Cari berita, dokumen, regulasi, halaman..."
            className="h-11"
            aria-label="Kata kunci pencarian"
          />
          <Button type="submit" className="h-11 bg-brand hover:bg-brand-ink text-white">
            <Search className="h-4 w-4" />
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function PublicLayout() {
  const { site, kontak, footer } = usePublicSettings();
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0 });
    setMobileOpen(false);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Top bar */}
      <div className="bg-brand-ink text-white/90 text-xs sm:text-sm">
        <div className="container-site flex h-9 items-center justify-between gap-4">
          <span className="truncate">
            {site.tagline ?? "Profesional, Integritas, Akuntabilitas"}
          </span>
          <span className="hidden sm:flex items-center gap-4">
            {kontak.phone && (
              <span className="flex items-center gap-1.5">
                <Phone className="h-3.5 w-3.5" /> {kontak.phone}
              </span>
            )}
            {kontak.email && (
              <span className="flex items-center gap-1.5">
                <Mail className="h-3.5 w-3.5" /> {kontak.email}
              </span>
            )}
          </span>
        </div>
      </div>

      {/* Header sticky */}
      <header
        className={`sticky top-0 z-50 border-b transition-shadow ${
          scrolled ? "bg-white/90 backdrop-blur-md shadow-md" : "bg-white"
        }`}
      >
        <div className="container-site flex h-16 lg:h-[76px] items-center justify-between gap-3">
          <Link to="/" className="flex items-center gap-3 min-w-0" aria-label="Beranda Inspektorat Kabupaten Dompu">
            {site.logoUrl ? (
              <img src={site.logoUrl} alt="Logo Inspektorat Kabupaten Dompu" className="h-10 w-10 lg:h-12 lg:w-12 object-contain" />
            ) : (
              <Emblem className="h-10 w-10 lg:h-12 lg:w-12 shrink-0" />
            )}
            <span className="min-w-0">
              <span className="block font-display font-extrabold uppercase tracking-wide text-brand text-sm lg:text-base leading-tight truncate">
                {site.name ?? "Inspektorat Kabupaten Dompu"}
              </span>
              <span className="block text-[11px] lg:text-xs text-muted-foreground truncate">
                Pemerintah Kabupaten Dompu — Nusa Tenggara Barat
              </span>
            </span>
          </Link>

          {/* Nav desktop */}
          <nav className="hidden xl:flex items-center gap-1" aria-label="Navigasi utama">
            {NAV.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                className={({ isActive }) =>
                  `px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                    isActive ? "text-gold" : "text-brand hover:text-gold"
                  }`
                }
              >
                {n.label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="h-11 w-11"
              onClick={() => setSearchOpen(true)}
              aria-label="Buka pencarian"
            >
              <Search className="h-5 w-5" />
            </Button>
            <Button asChild className="hidden sm:inline-flex h-11 bg-gold hover:bg-[#a87c22] text-white font-semibold">
              <Link to="/wbs">
                <ShieldAlert className="h-4 w-4 mr-2" /> WBS
              </Link>
            </Button>
            <Button asChild variant="outline" className="hidden md:inline-flex h-11 border-brand text-brand hover:bg-brand hover:text-white">
              <Link to="/login">
                <Lock className="h-4 w-4 mr-2" /> Login
              </Link>
            </Button>
            <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="xl:hidden h-11 w-11" aria-label="Buka menu">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80 bg-brand text-white border-l-0 p-0">
                <div className="flex items-center gap-3 p-5 border-b border-white/15">
                  <Emblem className="h-10 w-10" />
                  <div className="font-display font-bold uppercase text-sm leading-tight">
                    {site.name ?? "Inspektorat Kabupaten Dompu"}
                  </div>
                </div>
                <nav className="flex flex-col p-3" aria-label="Navigasi mobile">
                  {[...NAV, { to: "/wbs", label: "Whistleblowing System" }, { to: "/login", label: "Login Admin" }].map((n) => (
                    <NavLink
                      key={n.to}
                      to={n.to}
                      onClick={() => setMobileOpen(false)}
                      className={({ isActive }) =>
                        `flex items-center justify-between px-4 py-3.5 rounded-md text-sm font-medium min-h-[44px] ${
                          isActive ? "bg-white/10 text-gold" : "text-white/90 hover:bg-white/10"
                        }`
                      }
                    >
                      {n.label}
                      <ChevronRight className="h-4 w-4 opacity-60" />
                    </NavLink>
                  ))}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      <main className="flex-1">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-brand-ink text-white">
        <div className="container-site grid gap-10 py-14 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <Emblem className="h-12 w-12" />
              <div className="font-display font-extrabold uppercase leading-tight text-sm">
                {site.name ?? "Inspektorat Kabupaten Dompu"}
              </div>
            </div>
            <p className="text-sm text-white/70 leading-relaxed">
              {footer.text ??
                "Inspektorat Kabupaten Dompu merupakan Aparat Pengawasan Intern Pemerintah (APIP) yang bertugas melakukan pengawasan intern atas penyelenggaraan pemerintahan daerah."}
            </p>
          </div>
          <div>
            <h4 className="font-display font-bold uppercase tracking-wider text-gold mb-4 text-sm">Tautan</h4>
            <ul className="space-y-2.5 text-sm text-white/80">
              {[
                { to: "/wbs", label: "Whistleblowing System" },
                { to: "/pengaduan", label: "Pengaduan Masyarakat" },
                { to: "/informasi-publik", label: "Informasi Publik (PPID)" },
                { to: "/publikasi", label: "Regulasi & Publikasi" },
                { to: "/galeri", label: "Galeri" },
                { to: "/kontak", label: "Kontak" },
              ].map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="hover:text-gold transition-colors">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-display font-bold uppercase tracking-wider text-gold mb-4 text-sm">Kontak</h4>
            <ul className="space-y-3 text-sm text-white/80">
              {kontak.address && (
                <li className="flex gap-2.5">
                  <MapPin className="h-4 w-4 mt-0.5 shrink-0 text-gold" />
                  <span>{kontak.address}</span>
                </li>
              )}
              {kontak.phone && (
                <li className="flex gap-2.5 items-center">
                  <Phone className="h-4 w-4 shrink-0 text-gold" /> {kontak.phone}
                </li>
              )}
              {kontak.email && (
                <li className="flex gap-2.5 items-center">
                  <Mail className="h-4 w-4 shrink-0 text-gold" /> {kontak.email}
                </li>
              )}
            </ul>
          </div>
          <div>
            <h4 className="font-display font-bold uppercase tracking-wider text-gold mb-4 text-sm">Media Sosial</h4>
            <div className="flex gap-3">
              {kontak.facebook && (
                <a href={kontak.facebook} target="_blank" rel="noreferrer" aria-label="Facebook" className="h-11 w-11 rounded-full bg-white/10 flex items-center justify-center hover:bg-gold transition-colors">
                  <Facebook className="h-5 w-5" />
                </a>
              )}
              {kontak.instagram && (
                <a href={kontak.instagram} target="_blank" rel="noreferrer" aria-label="Instagram" className="h-11 w-11 rounded-full bg-white/10 flex items-center justify-center hover:bg-gold transition-colors">
                  <Instagram className="h-5 w-5" />
                </a>
              )}
              {kontak.youtube && (
                <a href={kontak.youtube} target="_blank" rel="noreferrer" aria-label="YouTube" className="h-11 w-11 rounded-full bg-white/10 flex items-center justify-center hover:bg-gold transition-colors">
                  <Youtube className="h-5 w-5" />
                </a>
              )}
            </div>
            <div className="mt-6">
              <Button asChild className="bg-gold hover:bg-[#a87c22] text-white w-full sm:w-auto">
                <Link to="/wbs/lapor">
                  <ShieldAlert className="h-4 w-4 mr-2" /> Laporkan Pelanggaran
                </Link>
              </Button>
            </div>
          </div>
        </div>
        <div className="border-t border-white/10">
          <div className="container-site py-5 text-center text-xs text-white/60">
            © {new Date().getFullYear()} Inspektorat Kabupaten Dompu. Hak cipta dilindungi undang-undang.
          </div>
        </div>
      </footer>

      <SearchDialog open={searchOpen} onClose={() => setSearchOpen(false)} />
    </div>
  );
}

import { useState } from "react";
import { Download, Eye, FileText, Search } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { formatDate } from "@/lib/site";
import { toast } from "sonner";

type Section = "publikasi" | "informasi_publik" | "download";

export default function DocList({
  section,
  categories,
}: {
  section: Section;
  categories: readonly string[];
}) {
  const [category, setCategory] = useState<string | undefined>();
  const [search, setSearch] = useState("");
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const list = trpc.cms.documentList.useQuery({ section, category, search: q || undefined, page });
  const utils = trpc.useUtils();
  const [opening, setOpening] = useState(false);
  const openDoc = async (id: number, download: boolean) => {
    setOpening(true);
    try {
      const d = await utils.client.cms.documentUrl.query({ id, download });
      window.open(d.url, "_blank", "noopener");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Gagal membuka dokumen");
    } finally {
      setOpening(false);
    }
  };

  const totalPages = Math.max(1, Math.ceil((list.data?.total ?? 0) / (list.data?.pageSize ?? 10)));

  return (
    <div>
      <div className="mb-6 flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => {
              setCategory(undefined);
              setPage(1);
            }}
            className={`min-h-[40px] rounded-full border px-4 text-xs font-semibold ${!category ? "border-brand bg-brand text-white" : "bg-white text-brand hover:border-gold"}`}
          >
            Semua
          </button>
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => {
                setCategory(c);
                setPage(1);
              }}
              className={`min-h-[40px] rounded-full border px-4 text-xs font-semibold ${
                category === c ? "border-brand bg-brand text-white" : "bg-white text-brand hover:border-gold"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setQ(search);
            setPage(1);
          }}
          className="flex gap-2"
        >
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Cari dokumen..." className="h-11 w-full lg:w-64" aria-label="Cari dokumen" />
          <Button type="submit" className="h-11 bg-brand text-white hover:bg-brand-ink" aria-label="Cari">
            <Search className="h-4 w-4" />
          </Button>
        </form>
      </div>

      <div className="overflow-hidden rounded-xl border bg-white shadow-sm">
        {list.isLoading ? (
          <div className="space-y-3 p-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-14 animate-pulse rounded bg-muted" />
            ))}
          </div>
        ) : (list.data?.data.length ?? 0) === 0 ? (
          <div className="flex flex-col items-center gap-2 p-12 text-center text-muted-foreground">
            <FileText className="h-10 w-10 opacity-40" />
            <p className="text-sm">Belum ada dokumen pada kategori ini.</p>
          </div>
        ) : (
          <ul className="divide-y">
            {list.data?.data.map((d) => (
              <li key={d.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between lg:px-6">
                <div className="flex min-w-0 items-start gap-3">
                  <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-brand/10">
                    <FileText className="h-5 w-5 text-brand" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-semibold leading-snug text-brand">{d.title}</div>
                    <div className="mt-1 flex flex-wrap gap-x-3 text-xs text-muted-foreground">
                      <span className="rounded-full bg-gold/15 px-2 py-0.5 font-medium text-gold">{d.category}</span>
                      <span>{formatDate(d.publishedAt)}</span>
                      <span>{d.downloads} unduhan</span>
                    </div>
                  </div>
                </div>
                <div className="flex shrink-0 gap-2 pl-14 sm:pl-0">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-10 border-brand text-brand hover:bg-brand hover:text-white"
                    disabled={opening}
                    onClick={() => openDoc(d.id, false)}
                  >
                    <Eye className="mr-1.5 h-4 w-4" /> Lihat
                  </Button>
                  <Button
                    size="sm"
                    className="h-10 bg-gold text-white hover:bg-[#a87c22]"
                    disabled={opening}
                    onClick={() => openDoc(d.id, true)}
                  >
                    <Download className="mr-1.5 h-4 w-4" /> Unduh
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      {totalPages > 1 && (
        <div className="mt-6 flex items-center justify-center gap-2">
          <Button variant="outline" disabled={page <= 1} onClick={() => setPage(page - 1)} className="h-10">
            Sebelumnya
          </Button>
          <span className="text-sm text-muted-foreground">
            Halaman {page} dari {totalPages}
          </span>
          <Button variant="outline" disabled={page >= totalPages} onClick={() => setPage(page + 1)} className="h-10">
            Berikutnya
          </Button>
        </div>
      )}
    </div>
  );
}

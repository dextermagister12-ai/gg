import { useEffect } from "react";
import { trpc } from "@/providers/trpc";

export type SiteSettings = {
  name?: string;
  tagline?: string;
  primaryColor?: string;
  accentColor?: string;
  surfaceColor?: string;
  logoUrl?: string | null;
  theme?: string;
};

export type Sambutan = {
  name?: string;
  position?: string;
  photoKey?: string;
  photoUrl?: string | null;
  text?: string;
};

export type Kontak = {
  address?: string;
  phone?: string;
  email?: string;
  mapsQuery?: string;
  facebook?: string;
  instagram?: string;
  youtube?: string;
};

export function usePublicSettings() {
  const q = trpc.cms.publicSettings.useQuery(undefined, { staleTime: 60_000 });

  useEffect(() => {
    const site = (q.data?.site ?? {}) as SiteSettings;
    const root = document.documentElement;
    if (site.primaryColor) {
      root.style.setProperty("--brand", site.primaryColor);
      root.style.setProperty("--brand-ink", shade(site.primaryColor, -18));
      root.style.setProperty("--brand-rgb", rgbTriplet(site.primaryColor));
      root.style.setProperty("--brand-ink-rgb", rgbTriplet(shade(site.primaryColor, -18)));
    }
    if (site.accentColor) {
      root.style.setProperty("--gold", site.accentColor);
      root.style.setProperty("--gold-rgb", rgbTriplet(site.accentColor));
    }
    if (site.surfaceColor) {
      root.style.setProperty("--paper", site.surfaceColor);
      root.style.setProperty("--paper-rgb", rgbTriplet(site.surfaceColor));
    }
    if (site.theme === "dark") root.classList.add("dark");
    else root.classList.remove("dark");
  }, [q.data]);

  return {
    site: ((q.data?.site ?? {}) as SiteSettings) ?? {},
    sambutan: ((q.data?.sambutan ?? {}) as Sambutan) ?? {},
    kontak: ((q.data?.kontak ?? {}) as Kontak) ?? {},
    footer: ((q.data?.footer ?? {}) as { text?: string }) ?? {},
    isLoading: q.isLoading,
  };
}

function rgbTriplet(hex: string) {
  const n = parseInt(hex.replace("#", ""), 16);
  return `${(n >> 16) & 0xff} ${(n >> 8) & 0xff} ${n & 0xff}`;
}

function shade(hex: string, pct: number) {
  const n = hex.replace("#", "");
  const num = parseInt(n, 16);
  const amt = Math.round(2.55 * pct);
  const r = Math.min(255, Math.max(0, (num >> 16) + amt));
  const g = Math.min(255, Math.max(0, ((num >> 8) & 0xff) + amt));
  const b = Math.min(255, Math.max(0, (num & 0xff) + amt));
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

export function formatDate(d?: Date | string | null) {
  if (!d) return "-";
  return new Date(d).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

export function formatDateTime(d?: Date | string | null) {
  if (!d) return "-";
  return new Date(d).toLocaleString("id-ID", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/** Hook: tambahkan class is-visible saat elemen masuk viewport */
export function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            e.target.classList.add("is-visible");
            io.unobserve(e.target);
          }
        }
      },
      { threshold: 0.12 },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  });
}

/** Renderer konten halaman sederhana: "## " = heading, "- " = bullet, sisanya paragraf */
export function PageContent({ content }: { content?: string | null }) {
  if (!content) return null;
  // Parse per baris: "## " → judul, "- " → daftar, lainnya → paragraf.
  type Block = { kind: "h3" | "ul" | "p"; lines: string[] };
  const blocks: Block[] = [];
  for (const raw of content.split("\n")) {
    const line = raw.trimEnd();
    if (!line.trim()) continue;
    const kind: Block["kind"] = line.startsWith("## ") ? "h3" : line.trimStart().startsWith("- ") ? "ul" : "p";
    const text = kind === "h3" ? line.slice(3).trim() : kind === "ul" ? line.trimStart().slice(2).trim() : line;
    const last = blocks[blocks.length - 1];
    if (last && last.kind === kind && kind !== "h3") last.lines.push(text);
    else blocks.push({ kind, lines: [text] });
  }
  return (
    <div className="space-y-4 leading-relaxed text-foreground/90">
      {blocks.map((b, i) => {
        if (b.kind === "h3") {
          return (
            <h3 key={i} className="font-display text-xl font-bold text-brand pt-4 border-t-2 border-gold/60 mt-6 first:mt-0 first:border-t-0 first:pt-0 uppercase tracking-wide">
              {b.lines[0]}
            </h3>
          );
        }
        if (b.kind === "ul") {
          return (
            <ul key={i} className="list-disc pl-6 space-y-1.5">
              {b.lines.map((l, j) => (
                <li key={j}>{l}</li>
              ))}
            </ul>
          );
        }
        return (
          <p key={i} className="whitespace-pre-line">
            {b.lines.join("\n")}
          </p>
        );
      })}
    </div>
  );
}

/** Emblem perisai Inspektorat (SVG) */
export function Emblem({ className = "h-10 w-10" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} role="img" aria-label="Logo Inspektorat Kabupaten Dompu">
      <defs>
        <linearGradient id="emg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--gold)" />
          <stop offset="100%" stopColor="#8a6a1d" />
        </linearGradient>
      </defs>
      <path
        d="M32 3 58 11v20c0 16.5-11.6 27-26 32C17.6 58 6 47.5 6 31V11L32 3z"
        fill="var(--brand)"
        stroke="url(#emg)"
        strokeWidth="2.5"
      />
      {/* Timbangan keadilan */}
      <g stroke="var(--gold)" strokeWidth="2" strokeLinecap="round" fill="none">
        <line x1="32" y1="16" x2="32" y2="40" />
        <line x1="20" y1="22" x2="44" y2="22" />
        <line x1="20" y1="22" x2="15" y2="31" />
        <line x1="20" y1="22" x2="25" y2="31" />
        <line x1="44" y1="22" x2="39" y2="31" />
        <line x1="44" y1="22" x2="49" y2="31" />
      </g>
      <path d="M13 31a7 4.5 0 0 0 14 0z" fill="var(--gold)" />
      <path d="M37 31a7 4.5 0 0 0 14 0z" fill="var(--gold)" />
      <line x1="25" y1="46" x2="39" y2="46" stroke="var(--gold)" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

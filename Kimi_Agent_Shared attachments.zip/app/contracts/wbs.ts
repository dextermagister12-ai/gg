// Konstanta bersama frontend & backend untuk WBS dan konten

export const VIOLATION_TYPES = [
  "Korupsi",
  "Gratifikasi",
  "Suap",
  "Penyalahgunaan Wewenang",
  "Konflik Kepentingan",
  "Pengadaan Barang/Jasa",
  "Pungutan Liar",
  "Pelanggaran Disiplin",
  "Penyalahgunaan Aset",
  "Pelanggaran Prosedur",
  "Pelanggaran Lainnya",
] as const;

export const REPORT_STATUSES = [
  { value: "diterima", label: "Laporan Diterima" },
  { value: "verifikasi", label: "Verifikasi Administratif" },
  { value: "telaah", label: "Telaah" },
  { value: "penanganan", label: "Dalam Penanganan" },
  { value: "info_tambahan", label: "Memerlukan Informasi Tambahan" },
  { value: "selesai", label: "Selesai" },
  { value: "ditutup", label: "Ditutup" },
] as const;

export type ReportStatus = (typeof REPORT_STATUSES)[number]["value"];

export function reportStatusLabel(s: string) {
  return REPORT_STATUSES.find((x) => x.value === s)?.label ?? s;
}

export const EVIDENCE_MAX_SIZE = 5 * 1024 * 1024; // 5 MB per berkas
export const EVIDENCE_MAX_FILES = 5;
export const EVIDENCE_EXTENSIONS = [
  "pdf",
  "jpg",
  "jpeg",
  "png",
  "doc",
  "docx",
  "xls",
  "xlsx",
  "zip",
];

export const DOC_SECTIONS = [
  { value: "publikasi", label: "Publikasi" },
  { value: "informasi_publik", label: "Informasi Publik" },
  { value: "download", label: "Pusat Download" },
] as const;

export const INFO_PUBLIK_CATEGORIES = [
  "Informasi Berkala",
  "Informasi Setiap Saat",
  "Informasi Serta Merta",
  "Informasi Dikecualikan",
  "Daftar Informasi Publik",
  "PPID",
  "Standar Pelayanan Informasi",
] as const;

export const PUBLIKASI_CATEGORIES = [
  "Laporan",
  "Regulasi",
  "Pedoman",
  "SOP",
  "Surat Edaran",
  "Peraturan",
  "Dokumen Pengawasan",
  "Publikasi Kinerja",
] as const;

export const DOWNLOAD_CATEGORIES = [
  "Regulasi",
  "Peraturan",
  "SOP",
  "Laporan",
  "Formulir",
  "Pedoman",
  "Dokumen Publik",
  "Materi Pengawasan",
] as const;

export const NEWS_CATEGORIES = [
  "Kegiatan",
  "Pengawasan",
  "Pengumuman",
  "Siaran Pers",
  "Pelatihan",
] as const;

export const USER_ROLES = [
  { value: "admin", label: "Super Admin" },
  { value: "admin_wbs", label: "Admin WBS" },
  { value: "editor", label: "Editor" },
  { value: "viewer", label: "Viewer" },
  { value: "user", label: "Pengguna Biasa" },
] as const;

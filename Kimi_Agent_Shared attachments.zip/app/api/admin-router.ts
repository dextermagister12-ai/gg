import { z } from "zod";
import { desc, eq } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  agendas,
  auditLogs,
  banners,
  complaints,
  documents,
  galleryItems,
  news,
  pages,
  reportAttachments,
  reportUpdates,
  reports,
  settings,
  users,
} from "@db/schema";
import { assertRole, logAudit, ROLES } from "./lib/rbac";
import { storage } from "./lib/storage";

export const adminRouter = createRouter({
  // ---------- USERS ----------
  userList: authedQuery.query(async ({ ctx }) => {
    assertRole(ctx.user, ROLES.full);
    return getDb().select().from(users).orderBy(desc(users.createdAt)).limit(500);
  }),

  userSetRole: authedQuery
    .input(
      z.object({
        id: z.number(),
        role: z.enum(["user", "admin", "admin_wbs", "editor", "viewer"]),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.full);
      if (input.id === ctx.user.id && input.role !== "admin") {
        // Jangan turunkan role diri sendiri
        return { ok: false, message: "Tidak dapat mengubah role akun sendiri" };
      }
      await getDb().update(users).set({ role: input.role }).where(eq(users.id, input.id));
      await logAudit({ user: ctx.user, action: `Mengubah role pengguna #${input.id} -> ${input.role}`, req: ctx.req });
      return { ok: true };
    }),

  // ---------- AUDIT LOG ----------
  auditList: authedQuery
    .input(z.object({ page: z.number().min(1).default(1), pageSize: z.number().min(10).max(100).default(30) }))
    .query(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.full);
      return getDb()
        .select()
        .from(auditLogs)
        .orderBy(desc(auditLogs.createdAt))
        .limit(input.pageSize)
        .offset((input.page - 1) * input.pageSize);
    }),

  // ---------- BACKUP ----------
  backup: authedQuery.mutation(async ({ ctx }) => {
    assertRole(ctx.user, ROLES.full);
    const db = getDb();
    const dump = {
      createdAt: new Date().toISOString(),
      tables: {
        users: await db.select().from(users),
        banners: await db.select().from(banners),
        news: await db.select().from(news),
        agendas: await db.select().from(agendas),
        documents: await db.select().from(documents),
        galleryItems: await db.select().from(galleryItems),
        pages: await db.select().from(pages),
        settings: await db.select().from(settings),
        complaints: await db.select().from(complaints),
        reports: await db.select().from(reports),
        reportAttachments: await db.select().from(reportAttachments),
        reportUpdates: await db.select().from(reportUpdates),
        auditLogs: await db.select().from(auditLogs),
      },
    };
    await logAudit({ user: ctx.user, action: "Backup database (unduh JSON)", req: ctx.req });
    return dump;
  }),

  // ---------- STORAGE STATS ----------
  storageFiles: authedQuery.query(async ({ ctx }) => {
    assertRole(ctx.user, ROLES.full);
    return storage.listFiles({ prefix: "", delimiter: "", maxKeys: 200 });
  }),
});

import { TRPCError } from "@trpc/server";
import type { User } from "@db/schema";
import { getDb } from "../queries/connection";
import { auditLogs } from "@db/schema";

export type StaffRole = "admin" | "admin_wbs" | "editor" | "viewer";

export const ROLES = {
  full: ["admin"] as StaffRole[],
  wbs: ["admin", "admin_wbs"] as StaffRole[],
  wbsRead: ["admin", "admin_wbs", "viewer"] as StaffRole[],
  content: ["admin", "editor"] as StaffRole[],
  contentRead: ["admin", "editor", "viewer"] as StaffRole[],
  staff: ["admin", "admin_wbs", "editor", "viewer"] as StaffRole[],
};

export function assertRole(user: User | undefined, allowed: StaffRole[]) {
  if (!user) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "Login diperlukan" });
  }
  if (!allowed.includes(user.role as StaffRole)) {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Anda tidak memiliki hak akses untuk fitur ini",
    });
  }
}

export async function logAudit(opts: {
  user?: User;
  action: string;
  reportId?: number;
  req?: Request;
}) {
  try {
    const ip =
      opts.req?.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? null;
    await getDb().insert(auditLogs).values({
      userId: opts.user?.id ?? null,
      userName: opts.user?.name ?? null,
      action: opts.action,
      reportId: opts.reportId ?? null,
      ipAddress: ip,
    });
  } catch (e) {
    console.error("audit log failed", e);
  }
}

// Rate limiter sederhana di memori (per key)
const buckets = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return;
  }
  b.count += 1;
  if (b.count > limit) {
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: "Terlalu banyak permintaan. Silakan coba beberapa saat lagi.",
    });
  }
}

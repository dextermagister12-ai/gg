import { authRouter } from "./auth-router";
import { createRouter, publicQuery } from "./middleware";
import { wbsRouter } from "./wbs-router";
import { cmsRouter } from "./cms-router";
import { adminRouter } from "./admin-router";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  wbs: wbsRouter,
  cms: cmsRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;

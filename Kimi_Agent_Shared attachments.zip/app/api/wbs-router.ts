import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { createHash, randomBytes } from "crypto";
import { and, count, desc, eq, gte, like, lte, sql } from "drizzle-orm";
import { nanoid } from "nanoid";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { reports, reportAttachments, reportUpdates, type Report } from "@db/schema";
import { storage } from "./lib/storage";
import { assertRole, logAudit, rateLimit, ROLES } from "./lib/rbac";
import {
  EVIDENCE_EXTENSIONS,
  EVIDENCE_MAX_FILES,
  EVIDENCE_MAX_SIZE,
  VIOLATION_TYPES,
} from "@contracts/wbs";

// ---------- CAPTCHA sederhana (soal matematika) ----------
const captchas = new Map<string, { answer: number; expiresAt: number }>();

function makeCaptcha() {
  const a = Math.floor(Math.random() * 9) + 1;
  const b = Math.floor(Math.random() * 9) + 1;
  const id = nanoid(16);
  captchas.set(id, { answer: a + b, expiresAt: Date.now() + 10 * 60 * 1000 });
  // bersih-bersih
  for (const [k, v] of captchas) if (v.expiresAt < Date.now()) captchas.delete(k);
  return { id, question: `Berapa hasil dari ${a} + ${b}?` };
}

function verifyCaptcha(id: string, answer: number) {
  const c = captchas.get(id);
  captchas.delete(id);
  if (!c || c.expiresAt < Date.now() || c.answer !== answer) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Verifikasi captcha salah. Silakan coba lagi.",
    });
  }
}

function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

async function nextRegistrationNumber() {
  const year = new Date().getFullYear();
  const prefix = `WBS-DMP-${year}-`;
  const db = getDb();
  const [row] = await db
    .select({ n: count() })
    .from(reports)
    .where(like(reports.registrationNumber, `${prefix}%`));
  const seq = (row?.n ?? 0) + 1;
  return `${prefix}${String(seq).padStart(6, "0")}`;
}

const submitInput = z.object({
  captchaId: z.string().min(1),
  captchaAnswer: z.number(),
  anonymous: z.boolean(),
  confidential: z.boolean(),
  reporterName: z.string().max(255).optional(),
  reporterNik: z.string().max(40).optional(),
  reporterEmail: z.string().email().max(320).optional().or(z.literal("")),
  reporterPhone: z.string().max(40).optional(),
  reporterAddress: z.string().max(2000).optional(),
  reportedPerson: z.string().min(2).max(255),
  reportedPosition: z.string().max(255).optional(),
  reportedAgency: z.string().max(255).optional(),
  reportedUnit: z.string().max(255).optional(),
  violationType: z.enum(VIOLATION_TYPES),
  incidentDate: z.string().max(20).optional(),
  incidentLocation: z.string().max(500).optional(),
  chronology: z.string().min(30, "Kronologi minimal 30 karakter").max(20000),
  partiesInvolved: z.string().max(5000).optional(),
  estimatedLoss: z.string().max(255).optional(),
  attachments: z
    .array(
      z.object({
        key: z.string().max(512),
        fileName: z.string().max(500),
        fileType: z.string().max(120).optional(),
        fileSize: z.number().optional(),
      }),
    )
    .max(EVIDENCE_MAX_FILES)
    .optional(),
});

// Samarkan identitas pelapor untuk role yang tidak berhak
function maskReport(r: Report): Report {
  return {
    ...r,
    reporterName: r.anonymous ? "Anonim" : "Dirahasiakan",
    reporterNik: null,
    reporterEmail: null,
    reporterPhone: null,
    reporterAddress: null,
    reporterTokenHash: null,
  };
}

export const wbsRouter = createRouter({
  getCaptcha: publicQuery.query(({ ctx }) => {
    const ip = ctx.req.headers.get("x-forwarded-for") ?? "anon";
    rateLimit(`captcha:${ip}`, 30, 10 * 60 * 1000);
    return makeCaptcha();
  }),

  uploadEvidence: publicQuery
    .input(
      z.object({
        name: z.string().min(1).max(300),
        contentBase64: z.string().max(8_000_000), // ~5MB binary
        contentType: z.string().max(120).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const ip = ctx.req.headers.get("x-forwarded-for") ?? "anon";
      rateLimit(`upload:${ip}`, 30, 60 * 60 * 1000);

      const safeName = input.name.replace(/[^\w.\- ]/g, "_");
      const ext = safeName.split(".").pop()?.toLowerCase() ?? "";
      if (!EVIDENCE_EXTENSIONS.includes(ext)) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `Format berkas tidak didukung. Diperbolehkan: ${EVIDENCE_EXTENSIONS.join(", ")}`,
        });
      }
      const bytes = Uint8Array.from(Buffer.from(input.contentBase64, "base64"));
      if (bytes.length > EVIDENCE_MAX_SIZE) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Ukuran berkas maksimal 5 MB",
        });
      }
      const saved = await storage.uploadFile({
        fileContent: bytes,
        fileName: `wbs-evidence/${Date.now()}-${safeName}`,
        contentType: input.contentType,
      });
      return {
        key: saved.key,
        fileName: safeName,
        size: saved.size,
        fileType: input.contentType ?? ext,
      };
    }),

  submit: publicQuery.input(submitInput).mutation(async ({ ctx, input }) => {
    const ip = ctx.req.headers.get("x-forwarded-for") ?? "anon";
    rateLimit(`submit:${ip}`, 10, 60 * 60 * 1000);
    verifyCaptcha(input.captchaId, input.captchaAnswer);

    if (!input.anonymous) {
      if (!input.reporterName || input.reporterName.length < 2) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "Nama pelapor wajib diisi kecuali melapor secara anonim",
        });
      }
    }

    const db = getDb();
    const reg = await nextRegistrationNumber();
    const token = randomBytes(8).toString("hex"); // 16 char hex

    const inserted = await db
      .insert(reports)
      .values({
        registrationNumber: reg,
        reporterTokenHash: hashToken(token),
        anonymous: input.anonymous,
        confidential: input.confidential,
        reporterName: input.anonymous ? null : input.reporterName,
        reporterNik: input.anonymous ? null : input.reporterNik,
        reporterEmail: input.anonymous ? null : input.reporterEmail || null,
        reporterPhone: input.anonymous ? null : input.reporterPhone,
        reporterAddress: input.anonymous ? null : input.reporterAddress,
        reportedPerson: input.reportedPerson,
        reportedPosition: input.reportedPosition,
        reportedAgency: input.reportedAgency,
        reportedUnit: input.reportedUnit,
        violationType: input.violationType,
        incidentDate: input.incidentDate,
        incidentLocation: input.incidentLocation,
        chronology: input.chronology,
        partiesInvolved: input.partiesInvolved,
        estimatedLoss: input.estimatedLoss,
        status: "diterima",
      })
      .$returningId();

    const reportId = inserted[0]?.id;
    if (reportId && input.attachments?.length) {
      await db.insert(reportAttachments).values(
        input.attachments.map((a) => ({
          reportId,
          fileKey: a.key,
          fileName: a.fileName,
          fileType: a.fileType ?? null,
          fileSize: a.fileSize ?? null,
        })),
      );
    }
    if (reportId) {
      await db.insert(reportUpdates).values({
        reportId,
        status: "diterima",
        notes: "Laporan diterima oleh sistem WBS.",
        publicNote: "Laporan Anda telah diterima dan menunggu verifikasi administratif.",
        updatedBy: "Sistem",
      });
    }
    await logAudit({ action: `WBS: laporan baru ${reg}`, reportId, req: ctx.req });

    return {
      registrationNumber: reg,
      token,
      createdAt: new Date(),
      status: "diterima" as const,
    };
  }),

  checkStatus: publicQuery
    .input(z.object({ registrationNumber: z.string().min(5), token: z.string().min(6) }))
    .query(async ({ ctx, input }) => {
      const ip = ctx.req.headers.get("x-forwarded-for") ?? "anon";
      rateLimit(`status:${ip}`, 30, 10 * 60 * 1000);
      const db = getDb();
      const report = await db.query.reports.findFirst({
        where: eq(reports.registrationNumber, input.registrationNumber.trim()),
      });
      if (!report || report.reporterTokenHash !== hashToken(input.token.trim())) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Nomor registrasi atau kode pelapor tidak ditemukan.",
        });
      }
      const updates = await db
        .select()
        .from(reportUpdates)
        .where(eq(reportUpdates.reportId, report.id))
        .orderBy(reportUpdates.createdAt);
      return {
        registrationNumber: report.registrationNumber,
        status: report.status,
        violationType: report.violationType,
        createdAt: report.createdAt,
        timeline: updates.map((u) => ({
          status: u.status,
          note: u.publicNote ?? null,
          createdAt: u.createdAt,
        })),
      };
    }),

  // ================= STAFF =================

  stats: authedQuery.query(async ({ ctx }) => {
    assertRole(ctx.user, ROLES.wbsRead);
    const db = getDb();
    const [total] = await db.select({ n: count() }).from(reports);
    const byStatus = await db
      .select({ status: reports.status, n: count() })
      .from(reports)
      .groupBy(reports.status);
    const byType = await db
      .select({ type: reports.violationType, n: count() })
      .from(reports)
      .groupBy(reports.violationType);
    const byOpd = await db
      .select({ opd: reports.reportedAgency, n: count() })
      .from(reports)
      .groupBy(reports.reportedAgency);
    const byMonth = await db
      .select({
        month: sql<string>`DATE_FORMAT(${reports.createdAt}, '%Y-%m')`,
        n: count(),
      })
      .from(reports)
      .groupBy(sql`DATE_FORMAT(${reports.createdAt}, '%Y-%m')`)
      .orderBy(sql`DATE_FORMAT(${reports.createdAt}, '%Y-%m')`);
    const byYear = await db
      .select({
        year: sql<string>`YEAR(${reports.createdAt})`,
        n: count(),
      })
      .from(reports)
      .groupBy(sql`YEAR(${reports.createdAt})`);
    return {
      total: total?.n ?? 0,
      byStatus,
      byType,
      byOpd: byOpd.filter((o) => o.opd),
      byMonth,
      byYear,
    };
  }),

  list: authedQuery
    .input(
      z.object({
        search: z.string().optional(),
        status: z.string().optional(),
        violationType: z.string().optional(),
        opd: z.string().optional(),
        dateFrom: z.string().optional(),
        dateTo: z.string().optional(),
        page: z.number().min(1).default(1),
        pageSize: z.number().min(5).max(100).default(10),
      }),
    )
    .query(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.wbsRead);
      const db = getDb();
      const conds = [];
      if (input.search) {
        const q = `%${input.search}%`;
        conds.push(
          sql`(${reports.registrationNumber} LIKE ${q} OR ${reports.reportedPerson} LIKE ${q} OR ${reports.reportedAgency} LIKE ${q})`,
        );
      }
      if (input.status) conds.push(eq(reports.status, input.status as typeof reports.status.enumValues[number]));
      if (input.violationType) conds.push(eq(reports.violationType, input.violationType));
      if (input.opd) conds.push(like(reports.reportedAgency, `%${input.opd}%`));
      if (input.dateFrom) conds.push(gte(reports.createdAt, new Date(input.dateFrom)));
      if (input.dateTo) conds.push(lte(reports.createdAt, new Date(input.dateTo + "T23:59:59")));
      const where = conds.length ? and(...conds) : undefined;

      const [total] = await db.select({ n: count() }).from(reports).where(where);
      const rows = await db
        .select()
        .from(reports)
        .where(where)
        .orderBy(desc(reports.createdAt))
        .limit(input.pageSize)
        .offset((input.page - 1) * input.pageSize);

      const canSeeIdentity =
        ctx.user.role === "admin" || ctx.user.role === "admin_wbs";
      const data = rows.map((r) =>
        canSeeIdentity
          ? { ...r, reporterTokenHash: null }
          : maskReport(r),
      );
      return { data, total: total?.n ?? 0, page: input.page, pageSize: input.pageSize };
    }),

  detail: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.wbsRead);
      const db = getDb();
      const report = await db.query.reports.findFirst({
        where: eq(reports.id, input.id),
      });
      if (!report) throw new TRPCError({ code: "NOT_FOUND", message: "Laporan tidak ditemukan" });
      await logAudit({
        user: ctx.user,
        action: `WBS: membuka laporan ${report.registrationNumber}`,
        reportId: report.id,
        req: ctx.req,
      });
      const attachments = await db
        .select()
        .from(reportAttachments)
        .where(eq(reportAttachments.reportId, report.id));
      const updates = await db
        .select()
        .from(reportUpdates)
        .where(eq(reportUpdates.reportId, report.id))
        .orderBy(desc(reportUpdates.createdAt));
      const canSeeIdentity =
        ctx.user.role === "admin" || ctx.user.role === "admin_wbs";
      return {
        report: canSeeIdentity
          ? { ...report, reporterTokenHash: null }
          : maskReport(report),
        attachments,
        updates,
      };
    }),

  updateStatus: authedQuery
    .input(
      z.object({
        id: z.number(),
        status: z.enum([
          "diterima",
          "verifikasi",
          "telaah",
          "penanganan",
          "info_tambahan",
          "selesai",
          "ditutup",
        ]),
        notes: z.string().max(5000).optional(),
        publicNote: z.string().max(2000).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.wbs);
      const db = getDb();
      const report = await db.query.reports.findFirst({
        where: eq(reports.id, input.id),
      });
      if (!report) throw new TRPCError({ code: "NOT_FOUND" });
      await db.update(reports).set({ status: input.status }).where(eq(reports.id, input.id));
      await db.insert(reportUpdates).values({
        reportId: input.id,
        status: input.status,
        notes: input.notes ?? null,
        publicNote: input.publicNote ?? null,
        updatedBy: ctx.user.name ?? ctx.user.email ?? "Admin",
      });
      await logAudit({
        user: ctx.user,
        action: `WBS: ubah status ${report.registrationNumber} -> ${input.status}`,
        reportId: input.id,
        req: ctx.req,
      });
      return { ok: true };
    }),

  addNote: authedQuery
    .input(z.object({ id: z.number(), notes: z.string().min(1).max(5000) }))
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.wbs);
      const db = getDb();
      const report = await db.query.reports.findFirst({
        where: eq(reports.id, input.id),
      });
      if (!report) throw new TRPCError({ code: "NOT_FOUND" });
      await db.insert(reportUpdates).values({
        reportId: input.id,
        status: report.status,
        notes: input.notes,
        publicNote: null,
        updatedBy: ctx.user.name ?? ctx.user.email ?? "Admin",
      });
      await logAudit({
        user: ctx.user,
        action: `WBS: tambah catatan ${report.registrationNumber}`,
        reportId: input.id,
        req: ctx.req,
      });
      return { ok: true };
    }),

  setPriority: authedQuery
    .input(z.object({ id: z.number(), priority: z.enum(["rendah", "normal", "tinggi"]) }))
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.wbs);
      await getDb().update(reports).set({ priority: input.priority }).where(eq(reports.id, input.id));
      return { ok: true };
    }),

  attachmentUrl: authedQuery
    .input(z.object({ reportId: z.number(), attachmentId: z.number() }))
    .query(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.wbs);
      const db = getDb();
      const att = await db.query.reportAttachments.findFirst({
        where: eq(reportAttachments.id, input.attachmentId),
      });
      if (!att || att.reportId !== input.reportId)
        throw new TRPCError({ code: "NOT_FOUND" });
      await logAudit({
        user: ctx.user,
        action: `WBS: mengunduh bukti ${att.fileName}`,
        reportId: input.reportId,
        req: ctx.req,
      });
      const { url } = await storage.getPresignedUrl({ key: att.fileKey, download: true });
      return { url, fileName: att.fileName };
    }),

  exportData: authedQuery
    .input(
      z.object({
        status: z.string().optional(),
        violationType: z.string().optional(),
        dateFrom: z.string().optional(),
        dateTo: z.string().optional(),
      }),
    )
    .query(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.wbs);
      const db = getDb();
      const conds = [];
      if (input.status) conds.push(eq(reports.status, input.status as typeof reports.status.enumValues[number]));
      if (input.violationType) conds.push(eq(reports.violationType, input.violationType));
      if (input.dateFrom) conds.push(gte(reports.createdAt, new Date(input.dateFrom)));
      if (input.dateTo) conds.push(lte(reports.createdAt, new Date(input.dateTo + "T23:59:59")));
      const where = conds.length ? and(...conds) : undefined;
      const rows = await db
        .select()
        .from(reports)
        .where(where)
        .orderBy(desc(reports.createdAt))
        .limit(5000);
      await logAudit({ user: ctx.user, action: "WBS: export data laporan", req: ctx.req });
      return rows.map((r) => ({
        ...r,
        reporterTokenHash: null,
        reporterName: r.anonymous ? "Anonim" : r.reporterName,
      }));
    }),
});

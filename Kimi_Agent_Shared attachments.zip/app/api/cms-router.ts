import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { and, count, desc, eq, like, or, sql } from "drizzle-orm";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import {
  agendas,
  banners,
  complaints,
  documents,
  galleryItems,
  news,
  pages,
  reports,
  settings,
} from "@db/schema";
import { storage } from "./lib/storage";
import { assertRole, logAudit, rateLimit, ROLES } from "./lib/rbac";

const DOC_EXT = ["pdf", "doc", "docx", "xls", "xlsx", "jpg", "jpeg", "png"];
const IMG_EXT = ["jpg", "jpeg", "png", "webp"];
const MAX_DOC = 15 * 1024 * 1024;
const MAX_IMG = 8 * 1024 * 1024;

function slugify(s: string) {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .slice(0, 200);
}

async function getSetting(key: string) {
  const row = await getDb().query.settings.findFirst({
    where: eq(settings.key, key),
  });
  if (!row?.value) return null;
  try {
    return JSON.parse(row.value);
  } catch {
    return row.value;
  }
}

async function setSetting(key: string, value: unknown) {
  const v = JSON.stringify(value ?? null);
  await getDb()
    .insert(settings)
    .values({ key, value: v })
    .onDuplicateKeyUpdate({ set: { value: v } });
}

async function attachUrl<T extends { imageKey?: string | null }>(item: T) {
  if (!item.imageKey) return { ...item, imageUrl: null as string | null };
  try {
    const { url } = await storage.getPresignedUrl({ key: item.imageKey });
    return { ...item, imageUrl: url };
  } catch {
    return { ...item, imageUrl: null as string | null };
  }
}

async function fileUrl(fileKey?: string | null, download = false) {
  if (!fileKey) return null;
  try {
    const { url } = await storage.getPresignedUrl({ key: fileKey, download });
    return url;
  } catch {
    return null;
  }
}

const uploadFileInput = z.object({
  name: z.string().min(1).max(300),
  contentBase64: z.string().max(22_000_000),
  contentType: z.string().max(120).optional(),
  folder: z.string().max(80).default("uploads"),
});

async function uploadToStorage(input: z.infer<typeof uploadFileInput>, allowedExt: string[], maxSize: number) {
  const safeName = input.name.replace(/[^\w.\- ]/g, "_");
  const ext = safeName.split(".").pop()?.toLowerCase() ?? "";
  if (!allowedExt.includes(ext)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Format tidak didukung. Diperbolehkan: ${allowedExt.join(", ")}`,
    });
  }
  const bytes = Uint8Array.from(Buffer.from(input.contentBase64, "base64"));
  if (bytes.length > maxSize) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Ukuran berkas terlalu besar" });
  }
  return storage.uploadFile({
    fileContent: bytes,
    fileName: `${input.folder}/${Date.now()}-${safeName}`,
    contentType: input.contentType,
  });
}

export const cmsRouter = createRouter({
  // ---------- PUBLIC: SETTINGS ----------
  publicSettings: publicQuery.query(async () => {
    const keys = ["site", "sambutan", "kontak", "footer", "struktur"];
    const out: Record<string, unknown> = {};
    for (const k of keys) out[k] = await getSetting(k);
    // URL untuk gambar di settings
    const site = out.site as { logoKey?: string } | null;
    if (site?.logoKey) {
      (out.site as Record<string, unknown>).logoUrl = await fileUrl(site.logoKey);
    }
    const sambutan = out.sambutan as { photoKey?: string } | null;
    if (sambutan?.photoKey) {
      (out.sambutan as Record<string, unknown>).photoUrl = await fileUrl(sambutan.photoKey);
    }
    return out;
  }),

  // ---------- PUBLIC: BANNERS ----------
  banners: publicQuery.query(async () => {
    const rows = await getDb()
      .select()
      .from(banners)
      .where(eq(banners.active, true))
      .orderBy(banners.sortOrder);
    return Promise.all(rows.map(attachUrl));
  }),

  // ---------- PUBLIC: NEWS ----------
  newsList: publicQuery
    .input(
      z.object({
        search: z.string().optional(),
        category: z.string().optional(),
        page: z.number().min(1).default(1),
        pageSize: z.number().min(1).max(50).default(9),
      }),
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conds = [];
      if (input.search) conds.push(like(news.title, `%${input.search}%`));
      if (input.category) conds.push(eq(news.category, input.category));
      const where = conds.length ? and(...conds) : undefined;
      const [total] = await db.select({ n: count() }).from(news).where(where);
      const rows = await db
        .select()
        .from(news)
        .where(where)
        .orderBy(desc(news.publishedAt))
        .limit(input.pageSize)
        .offset((input.page - 1) * input.pageSize);
      return {
        data: await Promise.all(rows.map(attachUrl)),
        total: total?.n ?? 0,
        page: input.page,
        pageSize: input.pageSize,
      };
    }),

  newsPopular: publicQuery.query(async () => {
    const rows = await getDb()
      .select()
      .from(news)
      .orderBy(desc(news.views))
      .limit(5);
    return Promise.all(rows.map(attachUrl));
  }),

  newsLatest: publicQuery
    .input(z.object({ limit: z.number().min(1).max(12).default(4) }))
    .query(async ({ input }) => {
      const rows = await getDb()
        .select()
        .from(news)
        .orderBy(desc(news.publishedAt))
        .limit(input.limit);
      return Promise.all(rows.map(attachUrl));
    }),

  newsDetail: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const row = await db.query.news.findFirst({ where: eq(news.slug, input.slug) });
      if (!row) throw new TRPCError({ code: "NOT_FOUND", message: "Berita tidak ditemukan" });
      await db.update(news).set({ views: row.views + 1 }).where(eq(news.id, row.id));
      return attachUrl(row);
    }),

  // ---------- PUBLIC: AGENDA ----------
  agendaList: publicQuery
    .input(z.object({ upcoming: z.boolean().default(false) }))
    .query(async ({ input }) => {
      const db = getDb();
      const today = new Date().toISOString().slice(0, 10);
      const rows = input.upcoming
        ? await db
            .select()
            .from(agendas)
            .where(sql`${agendas.eventDate} >= ${today}`)
            .orderBy(agendas.eventDate)
            .limit(6)
        : await db.select().from(agendas).orderBy(desc(agendas.eventDate)).limit(100);
      return rows;
    }),

  // ---------- PUBLIC: DOCUMENTS ----------
  documentList: publicQuery
    .input(
      z.object({
        section: z.enum(["publikasi", "informasi_publik", "download"]),
        category: z.string().optional(),
        search: z.string().optional(),
        page: z.number().min(1).default(1),
        pageSize: z.number().min(1).max(50).default(10),
      }),
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conds = [eq(documents.section, input.section)];
      if (input.category) conds.push(eq(documents.category, input.category));
      if (input.search) conds.push(like(documents.title, `%${input.search}%`));
      const where = and(...conds);
      const [total] = await db.select({ n: count() }).from(documents).where(where);
      const rows = await db
        .select()
        .from(documents)
        .where(where)
        .orderBy(desc(documents.publishedAt))
        .limit(input.pageSize)
        .offset((input.page - 1) * input.pageSize);
      return {
        data: rows,
        total: total?.n ?? 0,
        page: input.page,
        pageSize: input.pageSize,
      };
    }),

  documentUrl: publicQuery
    .input(z.object({ id: z.number(), download: z.boolean().default(false) }))
    .query(async ({ input }) => {
      const db = getDb();
      const doc = await db.query.documents.findFirst({ where: eq(documents.id, input.id) });
      if (!doc?.fileKey) throw new TRPCError({ code: "NOT_FOUND", message: "Dokumen tidak ditemukan" });
      if (input.download) {
        await db.update(documents).set({ downloads: doc.downloads + 1 }).where(eq(documents.id, doc.id));
      }
      const url = await fileUrl(doc.fileKey, input.download);
      if (!url) throw new TRPCError({ code: "NOT_FOUND", message: "Berkas tidak tersedia" });
      return { url, fileName: doc.fileName };
    }),

  // ---------- PUBLIC: GALLERY ----------
  gallery: publicQuery
    .input(z.object({ type: z.enum(["photo", "video"]).optional() }))
    .query(async ({ input }) => {
      const db = getDb();
      const rows = input.type
        ? await db.select().from(galleryItems).where(eq(galleryItems.type, input.type)).orderBy(desc(galleryItems.createdAt))
        : await db.select().from(galleryItems).orderBy(desc(galleryItems.createdAt));
      return Promise.all(
        rows.map(async (g) => ({ ...g, fileUrl: await fileUrl(g.fileKey) })),
      );
    }),

  // ---------- PUBLIC: PAGES ----------
  page: publicQuery
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      const row = await getDb().query.pages.findFirst({ where: eq(pages.slug, input.slug) });
      if (!row) throw new TRPCError({ code: "NOT_FOUND", message: "Halaman tidak ditemukan" });
      return row;
    }),

  // ---------- PUBLIC: SEARCH ----------
  search: publicQuery
    .input(z.object({ q: z.string().min(2).max(200) }))
    .query(async ({ input }) => {
      const q = `%${input.q}%`;
      const db = getDb();
      const [newsRows, docRows, pageRows] = await Promise.all([
        db.select().from(news).where(or(like(news.title, q), like(news.excerpt, q))).orderBy(desc(news.publishedAt)).limit(10),
        db.select().from(documents).where(like(documents.title, q)).orderBy(desc(documents.publishedAt)).limit(10),
        db.select().from(pages).where(or(like(pages.title, q), like(pages.content, q))).limit(10),
      ]);
      return {
        news: await Promise.all(newsRows.map(attachUrl)),
        documents: docRows,
        pages: pageRows,
      };
    }),

  // ---------- PUBLIC: COMPLAINT (Pengaduan Masyarakat) ----------
  submitComplaint: publicQuery
    .input(
      z.object({
        name: z.string().min(2).max(255),
        email: z.string().email().max(320).optional().or(z.literal("")),
        phone: z.string().max(40).optional(),
        subject: z.string().min(4).max(500),
        message: z.string().min(10).max(10000),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      const ip = ctx.req.headers.get("x-forwarded-for") ?? "anon";
      rateLimit(`complaint:${ip}`, 10, 60 * 60 * 1000);
      const year = new Date().getFullYear();
      const [row] = await getDb().select({ n: count() }).from(complaints);
      const ticket = `ADU-DMP-${year}-${String((row?.n ?? 0) + 1).padStart(5, "0")}`;
      await getDb().insert(complaints).values({
        ticket,
        name: input.name,
        email: input.email || null,
        phone: input.phone ?? null,
        subject: input.subject,
        message: input.message,
      });
      await logAudit({ action: `Pengaduan baru ${ticket}`, req: ctx.req });
      return { ticket };
    }),

  // ---------- PUBLIC: HOMEPAGE STATS ----------
  publicStats: publicQuery.query(async () => {
    const db = getDb();
    const [[n], [d], [g], [a], [r]] = await Promise.all([
      db.select({ n: count() }).from(news),
      db.select({ n: count() }).from(documents),
      db.select({ n: count() }).from(galleryItems),
      db.select({ n: count() }).from(agendas),
      db.select({ n: count() }).from(reports),
    ]);
    return {
      news: n?.n ?? 0,
      documents: d?.n ?? 0,
      gallery: g?.n ?? 0,
      agendas: a?.n ?? 0,
      reports: r?.n ?? 0,
    };
  }),

  // ================= ADMIN =================

  adminUpload: authedQuery
    .input(uploadFileInput.extend({ kind: z.enum(["image", "document"]) }))
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.content);
      const allowed = input.kind === "image" ? IMG_EXT : DOC_EXT;
      const max = input.kind === "image" ? MAX_IMG : MAX_DOC;
      const saved = await uploadToStorage(input, allowed, max);
      await logAudit({ user: ctx.user, action: `Upload berkas ${input.name}`, req: ctx.req });
      return { key: saved.key, fileName: saved.fileName, size: saved.size, fileType: input.contentType ?? "" };
    }),

  // ---- Settings ----
  getSettings: authedQuery.query(async ({ ctx }) => {
    assertRole(ctx.user, ROLES.content);
    const keys = ["site", "sambutan", "kontak", "footer", "struktur"];
    const out: Record<string, unknown> = {};
    for (const k of keys) out[k] = await getSetting(k);
    return out;
  }),

  saveSettings: authedQuery
    .input(z.object({ key: z.enum(["site", "sambutan", "kontak", "footer", "struktur"]), value: z.unknown() }))
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.content);
      await setSetting(input.key, input.value);
      await logAudit({ user: ctx.user, action: `Mengubah pengaturan ${input.key}`, req: ctx.req });
      return { ok: true };
    }),

  // ---- Banners ----
  bannerList: authedQuery.query(async ({ ctx }) => {
    assertRole(ctx.user, ROLES.contentRead);
    const rows = await getDb().select().from(banners).orderBy(banners.sortOrder);
    return Promise.all(rows.map(attachUrl));
  }),

  bannerSave: authedQuery
    .input(
      z.object({
        id: z.number().optional(),
        title: z.string().min(1).max(500),
        description: z.string().max(2000).optional(),
        imageKey: z.string().max(512).optional().nullable(),
        ctaText: z.string().max(120).optional(),
        ctaLink: z.string().max(500).optional(),
        sortOrder: z.number().default(0),
        active: z.boolean().default(true),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.content);
      const db = getDb();
      if (input.id) {
        await db.update(banners).set(input).where(eq(banners.id, input.id));
      } else {
        const { id: _omit, ...data } = input;
        await db.insert(banners).values(data);
      }
      await logAudit({ user: ctx.user, action: "Menyimpan banner", req: ctx.req });
      return { ok: true };
    }),

  bannerDelete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.content);
      await getDb().delete(banners).where(eq(banners.id, input.id));
      return { ok: true };
    }),

  // ---- News ----
  newsAdminList: authedQuery
    .input(z.object({ search: z.string().optional() }))
    .query(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.contentRead);
      const db = getDb();
      const where = input.search ? like(news.title, `%${input.search}%`) : undefined;
      const rows = await db.select().from(news).where(where).orderBy(desc(news.publishedAt)).limit(200);
      return Promise.all(rows.map(attachUrl));
    }),

  newsSave: authedQuery
    .input(
      z.object({
        id: z.number().optional(),
        title: z.string().min(3).max(500),
        excerpt: z.string().max(2000).optional(),
        content: z.string().max(100000).optional(),
        category: z.string().max(120).default("Kegiatan"),
        imageKey: z.string().max(512).optional().nullable(),
        author: z.string().max(255).optional(),
        featured: z.boolean().default(false),
        publishedAt: z.string().optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.content);
      const db = getDb();
      const slug = slugify(input.title) + "-" + Date.now().toString(36);
      if (input.id) {
        const { id, ...data } = input;
        await db
          .update(news)
          .set({ ...data, publishedAt: input.publishedAt ? new Date(input.publishedAt) : undefined })
          .where(eq(news.id, id));
      } else {
        const { id: _omit, ...data } = input;
        await db.insert(news).values({
          ...data,
          slug,
          publishedAt: input.publishedAt ? new Date(input.publishedAt) : new Date(),
          author: data.author ?? ctx.user.name ?? "Admin",
        });
      }
      await logAudit({ user: ctx.user, action: `Menyimpan berita "${input.title}"`, req: ctx.req });
      return { ok: true };
    }),

  newsDelete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.content);
      await getDb().delete(news).where(eq(news.id, input.id));
      await logAudit({ user: ctx.user, action: `Menghapus berita #${input.id}`, req: ctx.req });
      return { ok: true };
    }),

  // ---- Agenda ----
  agendaSave: authedQuery
    .input(
      z.object({
        id: z.number().optional(),
        title: z.string().min(3).max(500),
        eventDate: z.string().min(8).max(10),
        eventTime: z.string().max(20).optional(),
        location: z.string().max(500).optional(),
        description: z.string().max(5000).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.content);
      const db = getDb();
      if (input.id) {
        const { id, ...data } = input;
        await db.update(agendas).set(data).where(eq(agendas.id, id));
      } else {
        const { id: _omit, ...data } = input;
        await db.insert(agendas).values(data);
      }
      return { ok: true };
    }),

  agendaDelete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.content);
      await getDb().delete(agendas).where(eq(agendas.id, input.id));
      return { ok: true };
    }),

  // ---- Documents ----
  documentAdminList: authedQuery
    .input(z.object({ section: z.string().optional(), search: z.string().optional() }))
    .query(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.contentRead);
      const db = getDb();
      const conds = [];
      if (input.section) conds.push(eq(documents.section, input.section as typeof documents.section.enumValues[number]));
      if (input.search) conds.push(like(documents.title, `%${input.search}%`));
      const where = conds.length ? and(...conds) : undefined;
      return db.select().from(documents).where(where).orderBy(desc(documents.publishedAt)).limit(300);
    }),

  documentSave: authedQuery
    .input(
      z.object({
        id: z.number().optional(),
        title: z.string().min(3).max(500),
        description: z.string().max(5000).optional(),
        section: z.enum(["publikasi", "informasi_publik", "download"]),
        category: z.string().max(120),
        fileKey: z.string().max(512).optional().nullable(),
        fileName: z.string().max(500).optional().nullable(),
        fileType: z.string().max(120).optional().nullable(),
        fileSize: z.number().optional().nullable(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.content);
      const db = getDb();
      if (input.id) {
        const { id, ...data } = input;
        await db.update(documents).set(data).where(eq(documents.id, id));
      } else {
        const { id: _omit, ...data } = input;
        await db.insert(documents).values(data);
      }
      await logAudit({ user: ctx.user, action: `Menyimpan dokumen "${input.title}"`, req: ctx.req });
      return { ok: true };
    }),

  documentDelete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.content);
      await getDb().delete(documents).where(eq(documents.id, input.id));
      return { ok: true };
    }),

  // ---- Gallery ----
  gallerySave: authedQuery
    .input(
      z.object({
        id: z.number().optional(),
        type: z.enum(["photo", "video"]),
        title: z.string().min(2).max(500),
        album: z.string().max(255).default("Umum"),
        fileKey: z.string().max(512).optional().nullable(),
        videoUrl: z.string().max(1000).optional().nullable(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.content);
      const db = getDb();
      if (input.id) {
        const { id, ...data } = input;
        await db.update(galleryItems).set(data).where(eq(galleryItems.id, id));
      } else {
        const { id: _omit, ...data } = input;
        await db.insert(galleryItems).values(data);
      }
      return { ok: true };
    }),

  galleryDelete: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.content);
      await getDb().delete(galleryItems).where(eq(galleryItems.id, input.id));
      return { ok: true };
    }),

  // ---- Pages ----
  pageList: authedQuery.query(async ({ ctx }) => {
    assertRole(ctx.user, ROLES.contentRead);
    return getDb().select().from(pages).orderBy(pages.slug);
  }),

  pageSave: authedQuery
    .input(
      z.object({
        slug: z.string().min(2).max(255),
        title: z.string().min(2).max(500),
        content: z.string().max(200000).optional(),
      }),
    )
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.content);
      await getDb()
        .insert(pages)
        .values(input)
        .onDuplicateKeyUpdate({ set: { title: input.title, content: input.content } });
      await logAudit({ user: ctx.user, action: `Menyimpan halaman ${input.slug}`, req: ctx.req });
      return { ok: true };
    }),

  // ---- Complaints ----
  complaintList: authedQuery.query(async ({ ctx }) => {
    assertRole(ctx.user, ROLES.staff);
    return getDb().select().from(complaints).orderBy(desc(complaints.createdAt)).limit(300);
  }),

  complaintSetStatus: authedQuery
    .input(z.object({ id: z.number(), status: z.enum(["baru", "diproses", "selesai"]) }))
    .mutation(async ({ ctx, input }) => {
      assertRole(ctx.user, ROLES.staff);
      await getDb().update(complaints).set({ status: input.status }).where(eq(complaints.id, input.id));
      return { ok: true };
    }),
});
